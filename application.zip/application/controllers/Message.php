<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Message extends FrontendController {

    protected $domain;

    function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->template->write_view('content', 'messages/list_message', $this->data, true);
        $this->template->write_view('css', 'categories/courcecss', $this->data, true);
        $this->template->write_view('js', 'categories/coursejs', $this->data, true);
        $this->template->render();
    }

}
