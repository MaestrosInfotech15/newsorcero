<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Categories extends FrontendController {

    protected $domain_id;

    function __construct() 
	{
        parent::__construct(array());
        $this->load->model(array("Category_model"));
    }

    function index() 
	{
        $this->load->library('pagination');
        $params = array();
        $limit_per_page = 10;
        $page = ($this->uri->segment(4)) ? ($this->uri->segment(4) - 1) : 0;
        #echo $this->uri->segment(3);exit();
        $total_records = $this->Category_model->get_total_category();
        //echo $total_records;exit;
        if($total_records > 0)
        {
            $this->data['arrCategory'] = $this->Category_model->get_list_category($limit_per_page, $page*$limit_per_page);
                 
            $config['base_url'] = base_url() . 'categories/index/page';
            $config['total_rows'] = $total_records;
            $config['per_page'] = $limit_per_page;
            $config["uri_segment"] = 4;
             
            // custom paging configuration
            $config['num_links'] =2;
            $config['use_page_numbers'] = TRUE;
            $config['reuse_query_string'] = TRUE;
             
            $config['full_tag_open'] = '<div class="pagination">';
            $config['full_tag_close'] = '</div>';
             
            $config['first_link'] = 'First Page';
            $config['first_tag_open'] = '<span class="firstlink">';
            $config['first_tag_close'] = '</span>';
             
            $config['last_link'] = 'Last Page';
            $config['last_tag_open'] = '<span class="lastlink">';
            $config['last_tag_close'] = '</span>';
             
            $config['next_link'] = 'Next Page';
            $config['next_tag_open'] = '<span class="nextlink">';
            $config['next_tag_close'] = '</span>';
 
            $config['prev_link'] = 'Prev Page';
            $config['prev_tag_open'] = '<span class="prevlink">';
            $config['prev_tag_close'] = '</span>';
 
            $config['cur_tag_open'] = '<span class="curlink">';
            $config['cur_tag_close'] = '</span>';
 
            $config['num_tag_open'] = '<span class="numlink">';
            $config['num_tag_close'] = '</span>';
             
            $this->pagination->initialize($config);
                 
            // build paging links
            $this->data["links"] = $this->pagination->create_links();
            $this->data['page_no'] = $page*$limit_per_page;
        }
        $this->template->write_view('content', 'categories/list', $this->data, true);
        $this->template->write_view('css', 'categories/list_css', $this->data, true);
        $this->template->write_view('js', 'categories/list_js', $this->data, true);
        $this->template->render();
    }

    function add() 
	{
        //echo "<pre>";print_r($this->Student_model->check_domain_user($this->input->post()));exit;
        if ($this->input->post()) 
		{
            $config = array(
                array(
                    'field' => 'category_name',
                    'label' => 'Category Name',
                    'rules' => 'required'
                ),
            );
            $this->form_validation->set_rules($config);
            if ($this->form_validation->run() == TRUE) 
			{
                $arrCheckUser =array();
                if (empty($arrCheckUser)) 
				{
                    
                    $arrStudent = array(
                        'name'=>$this->input->post('category_name'),
                        'status' => 1,
                        'domain_id' => $this->session->userdata('current_user')[0]['domain_id']
                    );
                    $intStudentId = $this->Category_model->insertData('tbl_course_category',$arrStudent);
                    //echo "<pre>";print_r($this->db->last_query());exit;
                    if(!empty($intStudentId))
                    {
                        redirect("categories/index");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
                }
                else
                {
                    $this->session->set_flashdata('error','Email or username already exist');
                }
            }
            else
            {
                
            }
            
        } 

    }
    function edit($id=0) 
	{
        $arrStudent = $this->Student_model->listData('tbl_users','*',array('id'=>$id),'',true);
        $this->data['arrStudent'] = $arrStudent[0];
        //echo "<pre>";print_r($this->data['arrStudent']);exit;
        if ($this->input->post()) {
            $config = array(
                array(
                    'field' => 'fname',
                    'label' => 'First Name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'lname',
                    'label' => 'Last Name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'username',
                    'label' => 'Username',
                    'rules' => 'required|alpha'
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required',
                    'errors' => array(
                        'required' => 'You must provide a %s.',
                    ),
                ),
                array(
                    'field' => 'email',
                    'label' => 'Email',
                    'rules' => 'required|valid_email'
                )
            );
            $this->form_validation->set_rules($config);
            if ($this->form_validation->run() == TRUE) {
                $arrCheckUser = $this->Student_model->check_domain_user($this->input->post(),$id);
                
                if (empty($arrCheckUser)) {
                    //echo "<pre>";print_r($_FILES);exit;
                    if(!empty($_FILES['userfile']['name']))
                    {
                        $config['upload_path']          = './assets/uploads/student/';
                        $config['allowed_types']        = 'gif|jpg|png';
                        $config['encrypt_name'] = TRUE;
                        $this->load->library('upload', $config);
                        if (!$this->upload->do_upload('userfile'))
                        {
                            $this->session->set_flashdata('error',$this->upload->display_errors());
                        }
                        else
                        {
                            $filedata = $this->upload->data();
                            $filename = $filedata['file_name'];
                        }
                    }
                    
                    
                    $arrStudent = array(
                        'role_id'=>STUDENT_ROLE,
                        'profile_pic'=>$filename,
                        'email' => $this->input->post('email'),
                        'username' => $this->input->post('username'),
                        'password' => md5($this->input->post('password')),
                        'fname' => $this->input->post('fname'),
                        'lname' => $this->input->post('lname'),
                        'status' => $this->input->post('status'),
                        'emailsubscribe' => $this->input->post('emailsubscribe'),
                        'fburl' => $this->input->post('fburl'),
                        'linkedinurl' => $this->input->post('linkedinurl'),
                        'youtubeurl' => $this->input->post('youtubeurl'),
                        'twitterurl' => $this->input->post('twitterurl'),
                        'mediumurl' => $this->input->post('mediumurl'),
                        'weburl' => $this->input->post('weburl'),
                        'domain_id' => $this->session->userdata('current_user')[0]['domain_id']
                    );
                    $intStudentId = $this->Student_model->updateData('tbl_users',$arrStudent,array('id'=>$id));
                    //echo "<pre>";print_r($this->db->last_query());exit;
                    if($intStudentId==TRUE)
                    {
                        redirect("student/index");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
                }
                else
                {
                    $this->session->set_flashdata('error','Email or username already exist');
                }
            }
            $this->template->write_view('content', 'student/edit', $this->data, true);
            $this->template->write_view('css', 'student/add_css', $this->data, true);
            $this->template->write_view('js', 'student/add_js', $this->data, true);
            $this->template->render();
        } else {
            $this->template->write_view('content', 'student/edit', $this->data, true);
            $this->template->write_view('css', 'student/add_css', $this->data, true);
            $this->template->write_view('js', 'student/add_js', $this->data, true);
            $this->template->render();
        }
    }
   function delete($id=0)
	{
		if(!empty($id))
        {
            $arrSession = $this->session->userdata('current_user');
            $this->Category_model->updateData('tbl_course_category',array('deleted_by'=>isset($arrSession[0]['id']) ? $arrSession[0]['id'] : 1),array('id'=>$id),true);
            //echo $this->db->last_query();exit;
        }
        redirect('Categories/index');
	}

}

?>
