<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard extends FrontendController {

    function __construct() {
        parent::__construct(array());
		$this->load->model('Student_group_model');
        $this->load->model('Student_model');
		$this->load->model('Category_model');
		$this->load->model('User_model');
		$this->load->model('Course_model');
		$this->load->library('form_validation');
		
		
    }
    function index()
    {
        
        $this->data['total_students'] = $this->Student_model->get_total_students();
        $this->data['total_new_students'] = $this->Student_model->get_total_new_students();
        //echo $this->db->last_query();exit;
        $this->template->write_view('content', 'dashboard/index', $this->data, true);
        //$this->template->write_view('js', 'login/js', $this->data, true);
        $this->template->render();
    }
	//create course
    function create()
    {
		
		
		if ($this->input->post()) 
		{
              
			$courseData = array(
             'name' => $this->input->post('name'),
			  'users' => implode(",",$this->input->post('alluser')),
			  'usergroup' => implode(",",$this->input->post('usergroup')),
                'category' => implode(",",$this->input->post('category')),
                //'price_value' => $this->input->post('price_value'),
                'price' => strip_tags($this->input->post('price')),
               'description' => strip_tags($this->input->post('description')),
				
                //'button_type' => $this->input->post('button_type'),
				
                'level' => $this->input->post('total_level'),
                //'image' => $this->input->post('userfile'),
                'status' => $_POST['status'],
				//'date_from_available' => $_POST['date_from_available'],
				//'time_from_available' => $_POST['time_from_available'],
				//'question' => $_POST['question'],
				//'answer_type' => $_POST['answer_type'],
				//'answer_check' => $_POST['answer_check'],
				//'correct_answer' => $_POST['correct_answer'],
				//'marks' => $_POST['marks'],
				//'type_marks' => $_POST['type_marks'],
				//'currect_message' => $_POST['currect_message'],
				//'currect_message_value' => $_POST['currect_message_value'],
				//'wrong_message' => $_POST['wrong_message'],
				//'wrong_message_value' => $_POST['wrong_message_value'],
				///'limit_time' => $_POST['limit_time'],
				//'limit_time_value' => $_POST['limit_time_value']
				 'user_id' => $this->session->userdata('current_user')[0]['domain_id']
				
            );
			//print_r($courseData);
                    $intStudentId = $this->Course_model->insertData('tbl_courses',$courseData);
                //  echo "<pre>";print_r($this->db->last_query());exit;
                    if(!empty($intStudentId))
                    {
                        redirect("Course/index");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
                }
                else
                {
                    $this->session->set_flashdata('error','Email or username already exist');
			
				}
		$this->data['student_group'] = $this->Student_group_model->get_list_group();
       
		$this->data['category'] = $this->Category_model->get_list_category();
		$this->data['users'] = $this->User_model->get_list_users();
		
		
        $this->template->write_view('content', 'dashboard/course', $this->data, true);
        $this->template->write_view('css', 'dashboard/courcecss', $this->data, true);
        $this->template->write_view('js', 'dashboard/coursejs', $this->data, true);
        $this->template->render();
    }
	 function lists()
    {
		$this->load->library('pagination');
        $params = array();
        $limit_per_page = 10;
      $page = ($this->uri->segment(4)) ? ($this->uri->segment(4) - 1) : 0;
        #echo $this->uri->segment(3);exit();
         $total_records = $this->Course_model->get_total_course();
        //echo $total_records;exit;
         if($total_records > 0)
        {
            $this->data['arrCourse'] = $this->Course_model->get_list_course($limit_per_page, $page*$limit_per_page);
            // print_r( $this->data['arrCourse']);    
            $config['base_url'] = base_url() . 'Dashboard/lists/index/page';
            $config['total_rows'] = $total_records;
            $config['per_page'] = $limit_per_page;
            $config["uri_segment"] = 4;
             
            // custom paging configuration
            $config['num_links'] =2;
            $config['use_page_numbers'] = TRUE;
            $config['reuse_query_string'] = TRUE;
             
            $config['full_tag_open'] = '<div class="pagination">';
            $config['full_tag_close'] = '</div>';
             
            $config['first_link'] = 'First Page';
            $config['first_tag_open'] = '<span class="firstlink">';
            $config['first_tag_close'] = '</span>';
             
            $config['last_link'] = 'Last Page';
            $config['last_tag_open'] = '<span class="lastlink">';
            $config['last_tag_close'] = '</span>';
             
            $config['next_link'] = 'Next Page';
            $config['next_tag_open'] = '<span class="nextlink">';
            $config['next_tag_close'] = '</span>';
 
            $config['prev_link'] = 'Prev Page';
            $config['prev_tag_open'] = '<span class="prevlink">';
            $config['prev_tag_close'] = '</span>';
 
            $config['cur_tag_open'] = '<span class="curlink">';
            $config['cur_tag_close'] = '</span>';
 
            $config['num_tag_open'] = '<span class="numlink">';
            $config['num_tag_close'] = '</span>';
             
            $this->pagination->initialize($config);
                 
            // build paging links
            $this->data["links"] = $this->pagination->create_links();
            $this->data['page_no'] = $page*$limit_per_page;
        }
        
		$this->template->write_view('content', 'dashboard/course_list', $this->data, true);
        $this->template->write_view('css', 'dashboard/courcecss', $this->data, true);
        $this->template->write_view('js', 'dashboard/coursejs', $this->data, true);
        $this->template->render();
	}
}
?>

