<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * User Management class created by parthujeniya@gmail.com
 */
class Courses extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('course');
         $this->load->model('User_model');
        //$this->load->model('role');
        //$this->load->model('timeline');
         $this->load->model('Category_model');
    }
     
    /*
     * User account information
     */




////////////////////// delete_file ////////////////////////

  public function delete_file(){


$update_details = $this->db
                  ->where('id', $_POST['id'])
                  ->get('tbl_courses')
                  ->row();


unlink('images/'.$_POST['file']);

foreach(explode(',', $update_details->image) as $file_value):

if($file_value != $_POST['file']):
$file[] = $file_value;
endif;

endforeach;  

$images = implode(',', $file);

         $categoryData = array(
                'image' => $images
            );


                           $insert =   $this->db->where('id', $_POST['id']);
                                       $this->db->update('tbl_courses', $categoryData); 

                           $msg = 'Your courses was successfully updated.';

$result['result']=true;

echo json_encode($result);


  }

////////////////////// delete_file ////////////////////////


////////////////////// create ////////////////////////

    public function create(){
        $data = array();

  $uid =  $this->uri->segment(3);


  
    if($uid!=""){
         $data['edit_course'] = $this->course->all_courses($uid );
     }else{
         $data['edit_course'] = array();
     }
 
 //print_r($data['edit_course']);

     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }


if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }


        $userData = array();
        if($this->input->post('regisSubmit'))
        {
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('category', 'Category', 'required');
            $this->form_validation->set_rules('price', 'price', 'required');
            $this->form_validation->set_rules('days', 'days', 'required');
            $this->form_validation->set_rules('level', 'level', 'required');

            //multiple
          $config['upload_path']          = './images/';
               $config['allowed_types']        = 'jpg|jpeg|png|gif|mov|PNG|doc|docx|txt|pdf|rar|mp3|3gp|mpeg|mpeg|wmv|mp4|avi|mov'; 
                $config['max_size']             = 221000110;
                $config['max_width']            = 1110241;
                $config['max_height']           = 7681101;

  $this->load->library('upload');
    $dataInfo = array();
    $files = $_FILES;
   $cpt = count($_FILES['userfile']['name']);

$file_count = count(scandir('images/'));

    for($i=0; $i < $cpt; $i++)
    {    
$file_name= $file_count + $i + 1000;
 $exploding = explode(".",$files['userfile']['name'][$i]);
 $ext = end($exploding);
$file_name=$file_name.'.'.$ext;
  
        $_FILES['userfile']['name']= $file_name;

        $_FILES['userfile']['type']= $files['userfile']['type'][$i];
        $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
        $_FILES['userfile']['error']= $files['userfile']['error'][$i];
        $_FILES['userfile']['size']= $files['userfile']['size'][$i];    

        $this->upload->initialize($config);
        $this->upload->do_upload();
        $dataInfo[] = $this->upload->data();


    }


//echo '<pre>';
//print_r($dataInfo);
//echo '</pre>';
//die;

$image = "";
    if(count($dataInfo)==0){
        if($data['file_name']!=''){
            $image =$data['edit_course']['image'];
        }else{
           $image = 'sorcero_logo.png';
        }
    
    }else{
    foreach ($dataInfo as $key => $value) {
         $image .= $value['file_name'].','; // $image =  $data['file_name'];
    }

    // $image = substr($image , 0,-1);
}

if($data['edit_course']['image']!=''){
    $image.$data['edit_course']['image'];  
}

    $image = substr($image , 0,-1);   
 
$edit_id = $this->input->post('edit_id');

if($edit_id!=0){

$update_details = $this->db
                  ->where('id', $edit_id)
                  ->get('tbl_courses')
                  ->row();

//echo '<pre>';
//print_r($update_details);
//echo '</pre>';

     $images = $update_details->image.','.$image;

}
else
{
    $images = $image; 
}

//echo $images;

              

         $categoryData = array(
                'name' => strip_tags($this->input->post('name')),
                'category' => strip_tags($this->input->post('category')),
                'course_code' => $this->input->post('course_code'),
                'price' => strip_tags($this->input->post('price')),
                'description' => strip_tags($this->input->post('description')),
                'days' => $this->input->post('days'),
                'level' => $this->input->post('level'),
                'image' => $images,
                'status' => $_POST['status'],
                'user_id' => $this->session->userdata('userId')
            );
        

           



            if($this->form_validation->run() == true){

                if($edit_id!=0){
                           $insert =   $this->db->where('id', $edit_id);
                                       $this->db->update('tbl_courses', $categoryData); 

                           $msg = 'Your courses was successfully updated.';
      //////////////timeline insert/////////////
      $data_timeline = array(
          'user_id'=>$this->session->userdata('userId'),
          'event_id' => 15,
          'record_id' => $edit_id,
          'tag' => 'Update'
      );
      
      $this->timeline->insert($data_timeline);
      //////////////timeline insert/////////////

                }else{
                           $insert = $this->course->insert($categoryData);  
                           $msg = 'Your courses was successfully added Please select user by edit it.';

      //////////////timeline insert/////////////
      $data_timeline = array(
          'user_id'=>$this->session->userdata('userId'),
          'event_id' => 11,
          'record_id' => $insert,
          'tag' => 'Create'
      );
      
      $this->timeline->insert($data_timeline);
      //////////////timeline insert/////////////
                }

                 //print_r($categoryData);

           
                if($insert){
                            $this->session->set_userdata('success_msg', $msg);
                            redirect('courses/course');
                }else{
                            $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }


            $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
            $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role']));

            $data['category'] = $this->Category_model->get_list_category();
             print_r( $data['category'] );
        $this->load->view('common/header_user', $data);
        $this->load->view('course/create', $data);
        $this->load->view('common/footer', $data);
    }
    

////////////////////// create ////////////////////////



    /*
     * all  course
     */
    public function course(){
        $data = array();



     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }



            $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
            $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role']));


          $data['course'] = $this->course->courses();


        //load the view
        $this->load->view('common/header_user', $data);
        $this->load->view('courses/courses', $data);
        $this->load->view('common/footer', $data);
    }
    





 public function course_data(){
        $data = array();


      $uid =  $this->uri->segment(3);

     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }


       if($this->input->post('regisSubmit'))
        {
  $strtotime = strtotime("now");
      
         $contentData = array(
                'course_id' => $uid,
                'content' => strip_tags($this->input->post('content')),
                'title' => strip_tags($this->input->post('title')),
              
                'status' => 1,
                'strtotime'=>$strtotime
              
            );
        

    $this->db->insert('courses_contents',$contentData);
    $this->session->set_userdata('success_msg', 'Connent added successfully. ');
      redirect('courses/course_data/'.$uid);

        }





            $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
            $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role']));

           

         $data['edit_course'] = $this->course->all_courses($uid );


          $data['contents']= $this->course->all_course_contents($uid);
          $data['files']= $this->course->all_course_files($uid);


   /// print_r($data['contents']);

        //load the view
     $this->load->view('common/header_user', $data);
        $this->load->view('courses/course_data', $data);
        $this->load->view('common/footer_user', $data);
    }
    





 public function courses_file(){
        $data = array();


      $uid =  $this->uri->segment(3);

     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }


       if($this->input->post('regisSubmit'))
        {
  $strtotime = strtotime("now");


            $config['upload_path']          = './images/';
                $config['allowed_types']        = '*';
                 $config['max_size']             = 221000;
                    $config['max_width']            = 111024;
                $config['max_height']           = 7681;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                     echo $dfdf =  $this->upload->display_errors();

                       $this->session->set_userdata('error_msg', $dfdf);

                      redirect('courses/course_data/'.$uid);
                        die;
                }
                else
                {

                $data =  $this->upload->data();
                       // var_dump($data);
                $image =  $data['file_name'];
                        
                }
      
         $contentData = array(
                'course_id' => $uid,
                'file' => $image,
                'title' => strip_tags($this->input->post('title')),
              
                'status' => 1,
                'strtotime'=>$strtotime
              
            );
        

    $this->db->insert('courses_files',$contentData);

     $this->session->set_userdata('success_msg', 'Files added successfully. ');

      redirect('courses/course_data/'.$uid);

        }
}





 public function my_course(){
        $data = array();



     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }



            $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
            $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role']));

          $data['course'] = $this->course->courses();


        //load the view
        $this->load->view('common/header_user', $data);
        $this->load->view('courses/learner_course', $data);
        $this->load->view('common/footer', $data);
    }
    



  public function delete_courses(){


    $id =  strip_tags($this->input->post('id'));


    $delete =  $this->db->where('id', $id);
      $this->db->delete('courses'); 

       if($delete){
                   echo '&nbsp;<br><span class="succc">Deleted</span>';
                }else{
                   echo '&nbsp;<br><span class="errors">Error</span>';
                }



  }






  

  public function selectrt(){

    $id =  strip_tags($this->input->post('id'));

    $course =  strip_tags($this->input->post('course'));
    $type =  strip_tags($this->input->post('type'));
    $coursedata = $this->course->all_courses($course);

//print_r($coursedata);

//echo $id.$course;




  if($type=='rem'){
        $gh= 1;

            $sdgsf = explode(",", $coursedata['users']);
              foreach ($sdgsf as $key => $value) {
                   if($value==$id){
                    unset($sdgsf[$key]);
                   }
              }
            $new = implode(",", $sdgsf);

            $updateData  = array(
            'users'=> $new 
                );

              $insert =   $this->db->where('id', $course);
                        $this->db->update('courses', $updateData); 


              
            $userinfo =  $this->user->username($id);    

           $this->course->courses_users($course,$id,'rem',$userinfo[0]->username,$id);

  }else{  


                 $gh= 0;

                if($coursedata['users']!=''){

                 $new = $coursedata['users'].",".$id;   
                }else{
                    $new = $id; 
                }

                   
                $updateData  = array(
                'users'=> $new 
                    );
                  $insert =   $this->db->where('id', $course);
                            $this->db->update('courses', $updateData); 

                $userinfo =  $this->user->username($id);     

               $this->course->courses_users($course,$id,'sel',$userinfo[0]->username,$id);
  }







       if($gh==1){ ?>
       <button class="btn btn-default" style="padding:1px" onclick="selectss('<?php echo $id;?>','<?php echo $course;?>','sel')">Select</button>
                <?php }else{ ?>
          <button class="btn btn-success" style="padding:1px" onclick="selectss('<?php echo $id;?>','<?php echo $course;?>','rem')">Remove</button>
                <?php } 


  }







  public function selecttrainer(){

    $id =  strip_tags($this->input->post('id'));

    $course =  strip_tags($this->input->post('course'));
    $type =  strip_tags($this->input->post('type'));

   
         $coursedata = $this->course->all_courses($course);
//print_r($coursedata);

//echo $id.$course;




  if($type=='rem'){
      $gh= 1;

            $sdgsf = explode(",", $coursedata['users']);
              foreach ($sdgsf as $key => $value) {
                   if($value==$id){
                    unset($sdgsf[$key]);
                   }
              }
            $new = implode(",", $sdgsf);

            $updateData  = array(
            'trainers'=> $new 
                );

              $insert =   $this->db->where('id', $course);
                        $this->db->update('courses', $updateData); 
              


  }else{  

                 $gh= 0;

                if($coursedata['users']!=''){

                 $new = $coursedata['users'].",".$id;   
                }else{
                    $new = $id; 
                }

                   
                $updateData  = array(
                'trainers'=> $new 
                    );
                  $insert =   $this->db->where('id', $course);
                            $this->db->update('courses', $updateData); 
  }







       if($gh==1){ ?>
       <button class="btn btn-default" style="padding:1px" onclick="selectss('<?php echo $id;?>','<?php echo $course;?>','sel')">Select</button>
                <?php }else{ ?>
          <button class="btn btn-success" style="padding:1px" onclick="selectss('<?php echo $id;?>','<?php echo $course;?>','rem')">Remove</button>
                <?php } 


  }





  /*
     * see course
     */
    public function courseSee(){
        $data = array();


$uid =  $this->uri->segment(3);
  $data['coursedata'] = $this->course->all_courses($uid);


     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }



          $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));


          $data['course'] = $this->course->courses();

      
      //load the view
         $this->load->view('common/header_user', $data);
        $this->load->view('courses/see_course', $data);
        $this->load->view('common/footer', $data);
    }
    



  /*
     * see course
     */
    public function course_trainer(){
        $data = array();


$uid =  $this->uri->segment(3);
  $data['coursedata'] = $this->course->all_courses($uid);


     if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }



          $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
 $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role'])); 
 
          $data['course'] = $this->course->courses();

      $cid =  $data['coursedata']['id'];

     $data['course_filesss'] = $this->db->where(array('course_id'=>$cid))->get('courses_files')->result();

     $data['course_file']['file_count'] = $this->db->where(array('course_id'=>$cid))->get('courses_files')->num_rows();




       $data['courses_contentsss'] = $this->db->where(array('course_id'=>$cid))->get('courses_contents')->result();
     
     $data['courses_contents']['contents_count'] = $this->db->where(array('course_id'=>$cid))->get('courses_contents')->num_rows();



//print_r($data['courses_contents']);
    
      //load the view
         $this->load->view('common/header_user', $data);
        $this->load->view('courses/course_single_trainer', $data);
        $this->load->view('common/footer', $data);
    }
    








/*add Content*/

public function add_content(){
 $id =  strip_tags($this->input->post('id'));
$form = '<form method="post" name="" id="addcontent">



   <div class="input-group form-group-no-border input-lg">
                <span class="input-group-addon">
                <i class="fa  fa-clock-o"></i>
          </span>
        <input type="text" class="form-control" name="Name" placeholder="Name"   value="">
                        
         </div>
    <div class="input-group form-group-no-border input-lg">
        <span class="input-group-addon">
           <i class="fa  fa-quote-right"></i>
       </span>
       <textarea name="description" class="form-control" placeholder="Description"></textarea>
       </div>

 <div class="footer text-center">
                    <input type="submit" name="regisSubmit" class="btn btn-primary btn-lg btn-block" value="Submit"/>
                </div>
</form>';


return $form;

}

    

////////////////////// course_complete ////////////////////////

  public function status(){


$id= $this->uri->segment(3);
$status= $this->uri->segment(4);

         $categoryData = array(
                'status' => $status
            );


                           $insert =   $this->db->where('id', $id);
                                       $this->db->update('courses', $categoryData); 

                           $msg = 'Your courses was successfully updated.';

$result['result']=true;

//echo json_encode($result);
redirect('courses/course');

  }




  public function edit_contents(){

    $data = array();
   /* $id = strip_tags($this->input->post('id'));

       $table = strip_tags($this->input->post('table'));*/

       $id= $this->uri->segment(3);
$table= $this->uri->segment(4);

     //  $id = 25; $table ='courses_contents';
 
    $data['contents']= $this->course->courses_contents($id,$table);

         if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }

  $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
 $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role'])); 


 if($this->input->post('edit'))
        {
  $strtotime = strtotime("now");


      $id = strip_tags($this->input->post('id'));
         $contentData = array(
               
                'title' => strip_tags($this->input->post('title')),
              
                
                'content'=>strip_tags($this->input->post('content'))
              
            );
        

  

       $insert =   $this->db->where('id', $id);
            $this->db->update($table, $contentData);

     $this->session->set_userdata('success_msg', 'Content updates successfully. ');

      redirect('courses/course_data/'.$id);

        }
              $this->load->view('common/header_user', $data);
        $this->load->view('courses/course_content_edit', $data);
        $this->load->view('common/footer', $data);

   
  }



public function edit_files(){

  $data = array();
    $id = strip_tags($this->input->post('id'));

       $table = strip_tags($this->input->post('table'));




 if($this->input->post('editsbmt'))
        {
  $strtotime = strtotime("now");


      $id = strip_tags($this->input->post('id'));

      $table = strip_tags($this->input->post('table'));
      $image = strip_tags($this->input->post('image'));

                $config['upload_path']          = './images/';
                $config['allowed_types']        = 'gif|jpg|png';
                 $config['max_size']             = 221000;
                    $config['max_width']            = 111024;
                $config['max_height']           = 7681;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file'))
                {
                        $error = array('error' => $this->upload->display_errors());
                      $this->upload->display_errors();
                      //  die;
                }
                else
                {
                    $data =  $this->upload->data();
                       // var_dump($data);
                $image =  $data['file_name'];
                        
                }

         $contentData = array(
               
                'title' => strip_tags($this->input->post('title')),
                 'file' => $image
              
            );
        

  

       $insert =   $this->db->where('id', $id);
            $this->db->update($table, $contentData);

     $this->session->set_userdata('success_msg', 'Content updates successfully.');

    $contents= $this->course->courses_contents($id,$table);

      redirect('courses/course_data/'.$contents->id);

        }


    $contents= $this->course->courses_contents($id,$table);

      //modal
           echo ' <div class="modal fade" id="editmod" role="dialog">
    <div class="modal-dialog" style="  z-index: 120000000000000000000000000;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Files</h4>
        </div>
        <div class="modal-body">
       <form class="form" id="fomrconc" method="POST" action="'.base_url('index.php/').'courses/edit_files" enctype="multipart/form-data" >
         <div class="input-group form-group-no-border input-lg">
                        <span class="input-group-addon">
                            <i class="fa fa-quote-left"></i>
                        </span>
                        <input type="text" multiple class="form-control" name="title" placeholder="Title"   value="'.$contents->title.'">
                      
                    </div>


                     <div class="input-group form-group-no-border input-lg">
                        <span class="input-group-addon">
                            <i class="fa fa-quote-left"></i>
                        </span>
                        <input type="file" multiple class="form-control" name="file" placeholder="file"   value="">
                      
                    </div>
                     <input type="hidden" name="id" value="'.$id.'">
                     <input type="hidden" name="table" value="'.$table.'">

                       <input type="hidden" name="image" value="'.$contents->file.'">
                     

                <div class="">
                    <input type="submit" name="editsbmt" class="btn btn-primary btn-lg btn-block" value="Submit"/>
                </div>
               </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<script> $("#editmod").modal("show");</script>'; 

}





public  function set_status_users(){
    $id = strip_tags($this->input->post('id'));

       $val = strip_tags($this->input->post('val'));

        $contentData = array(
               
             
                 'status' => $val
              
            );
        

  

       $insert =   $this->db->where('id', $id);
            $this->db->update('courses_users', $contentData);
            if($insert){
              echo '<span style="color:green">success</span>';
            }else{
                 echo '<span style="color:red">Error</span>';
            }

}

////////////////////// course_complete ////////////////////////









//contents questions



  public function questions_contents(){

    $data = array();
 

       $id= $this->uri->segment(3);

  //$table= $this->uri->segment(4);

     //  $id = 25; $table ='courses_contents';
 
    $data['questions']=        $this->db->where('contents_id', $id)->get('questions')->result();


     $data['courses_contents'] =        $this->db->where('id', $id)->get('courses_contents')->row();

 //print_r( $data['courses_contents']);

         if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }

  $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
 $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role'])); 


 if($this->input->post('add'))
        {
  $strtotime = strtotime("now");
  $contents_id = strip_tags($this->input->post('contents_id'));
    $type=strip_tags($this->input->post('type'));

 if($type==1){
  $answere = strip_tags($this->input->post('answereop'));
 }else{
   $answere = strip_tags($this->input->post('answeret'));
 }
   

      $id = strip_tags($this->input->post('id'));
         $contentData = array(
                 'contents_id' => strip_tags($this->input->post('contents_id')),
                 'question' => strip_tags($this->input->post('question')),
                'option1' => strip_tags($this->input->post('option1')),
                'option2' => strip_tags($this->input->post('option2')),
                'option3' => strip_tags($this->input->post('option3')),
                'option4' => strip_tags($this->input->post('option4')),
                'answere' => $answere ,
                'status' => 1,
              
                
                'type'=>strip_tags($this->input->post('type'))
              
            );
        

  

       $insert =   $this->db->insert('questions', $contentData);

     $this->session->set_userdata('success_msg', 'Questions updates successfully. ');

      redirect('courses/questions_contents/'.$contents_id);

        }



              $this->load->view('common/header_user', $data);
        $this->load->view('questions/questions_contents', $data);
        $this->load->view('common/footer_user', $data);

   
  }






  public  function questions_edit(){
      $data = array();
 

       $id= $this->uri->segment(3);
            $questionsid= $this->uri->segment(4);

  //$table= $this->uri->segment(4);

     //  $id = 25; $table ='courses_contents';
 
    $data['questions']=        $this->db->where('id', $questionsid)->get('questions')->row();


     $data['courses_contents'] =        $this->db->where('id', $id)->get('courses_contents')->row();

 //print_r( $data['courses_contents']);

         if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }

  $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
 $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role'])); 


 if($this->input->post('edit'))
        {
  $strtotime = strtotime("now");
  $contents_id = strip_tags($this->input->post('contents_id'));
  $files_id = strip_tags($this->input->post('files_id'));

   $question_id = strip_tags($this->input->post('question_id'));

      $id = strip_tags($this->input->post('id'));


 if($type==1){
  $answere = strip_tags($this->input->post('answereop'));
 }else{
   $answere = strip_tags($this->input->post('answeret'));
 }
   
         $contentData = array(

               'files_id' => strip_tags($this->input->post('files_id')),
                 'contents_id' => strip_tags($this->input->post('contents_id')),
                 'question' => strip_tags($this->input->post('question')),
                'option1' => strip_tags($this->input->post('option1')),
                'option2' => strip_tags($this->input->post('option2')),
                'option3' => strip_tags($this->input->post('option3')),
                'option4' => strip_tags($this->input->post('option4')),
                'answere' => $answere ,
                'status' => 1,
              
                
                'type'=>strip_tags($this->input->post('type'))
              
            );
        

  

       $insert =   $this->db->where('id',$question_id)->update('questions', $contentData);
  if($insert){
     $this->session->set_userdata('success_msg', 'Questions updates successfully. ');
   }else{
    $this->session->set_userdata('error_msg', 'Questions updates Error. ');
       
   }
     

  if($files_id){
      redirect('courses/questions_contents/'.$files_id);
    }else{
       redirect('courses/questions_contents/'.$contents_id);
    }
    

        }



        $this->load->view('common/header_user', $data);
        $this->load->view('questions/questions_edit', $data);
        $this->load->view('common/footer_user', $data);
  }





  public  function questions_editfiles(){
      $data = array();
 

       $id= $this->uri->segment(3);
            $questionsid= $this->uri->segment(4);

  //$table= $this->uri->segment(4);

     //  $id = 25; $table ='courses_contents';
 
    $data['questions']=        $this->db->where('id', $questionsid)->get('questions')->row();


     $data['courses_contents'] =        $this->db->where('id', $id)->get('courses_files')->row();

 //print_r( $data['courses_contents']);

         if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }

  $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
 $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role'])); 


 if($this->input->post('edit'))
        {
  $strtotime = strtotime("now");
  $contents_id = strip_tags($this->input->post('contents_id'));
  $files_id = strip_tags($this->input->post('files_id'));

   $question_id = strip_tags($this->input->post('question_id'));

      $id = strip_tags($this->input->post('id'));


 if($type==1){
  $answere = strip_tags($this->input->post('answereop'));
 }else{
   $answere = strip_tags($this->input->post('answeret'));
 }
   
         $contentData = array(

               'files_id' => strip_tags($this->input->post('files_id')),
                 'contents_id' => strip_tags($this->input->post('contents_id')),
                 'question' => strip_tags($this->input->post('question')),
                'option1' => strip_tags($this->input->post('option1')),
                'option2' => strip_tags($this->input->post('option2')),
                'option3' => strip_tags($this->input->post('option3')),
                'option4' => strip_tags($this->input->post('option4')),
                'answere' => $answere ,
                'status' => 1,
              
                
                'type'=>strip_tags($this->input->post('type'))
              
            );
        

  

       $insert =   $this->db->where('id',$question_id)->update('questions', $contentData);
  if($insert){
     $this->session->set_userdata('success_msg', 'Questions updates successfully. ');
   }else{
    $this->session->set_userdata('error_msg', 'Questions updates Error. ');
       
   }
     

  if($files_id){
      redirect('courses/questions_files/'.$files_id);
    }else{
       redirect('courses/questions_contents/'.$contents_id);
    }
    

        }



              $this->load->view('common/header_user', $data);
        $this->load->view('questions/questions_editfiles', $data);
        $this->load->view('common/footer_user', $data);
  }








//Files questions



  public function questions_files(){

    $data = array();
 

        $id = $this->uri->segment(3);

     //$table= $this->uri->segment(4);

     //$id = 25; $table ='courses_contents';
 
    $data['questions']=  $this->db->where('files_id', $id)->get('questions')->result();


     $data['courses_contents'] =        $this->db->where('id', $id)->get('courses_files')->row();

// print_r( $data['courses_contents']);

         if(!$this->session->userdata('isUserLoggedIn')){
           
            redirect('users/login');
        }

        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }

  $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
 $data['user']['role'] = $this->role->getRows(array('id'=>$data['user']['role'])); 


 if($this->input->post('add'))
        {
  $strtotime = strtotime("now");
  $files_id = strip_tags($this->input->post('files_id'));
    $type=strip_tags($this->input->post('type'));

 if($type==1){
  $answere = strip_tags($this->input->post('answereop'));
 }else{
   $answere = strip_tags($this->input->post('answeret'));
 }
   

      $id = strip_tags($this->input->post('id'));
         $contentData = array(
                 'files_id' => strip_tags($this->input->post('files_id')),
                 'question' => strip_tags($this->input->post('question')),
                'option1' => strip_tags($this->input->post('option1')),
                'option2' => strip_tags($this->input->post('option2')),
                'option3' => strip_tags($this->input->post('option3')),
                'option4' => strip_tags($this->input->post('option4')),
                'answere' => $answere ,
                'status' => 1,
              
                
                'type'=>strip_tags($this->input->post('type'))
              
            );
        

  

       $insert =   $this->db->insert('questions', $contentData);

     $this->session->set_userdata('success_msg', 'Questions updates successfully. ');

      redirect('courses/questions_files/'.$files_id);

        }



        $this->load->view('common/header_user', $data);
        $this->load->view('questions/questions_files', $data);
        $this->load->view('common/footer_user', $data);

   
  }




}

