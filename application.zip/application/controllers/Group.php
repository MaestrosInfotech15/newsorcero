<?php 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Group extends FrontendController 
{

    protected $domain_id;
    function __construct() 
	{
        parent::__construct(array());
        $this->load->model('Student_group_model');
        $this->load->model('Student_model');
		$this->load->model('Category_model');
		$this->load->model('User_model');
		$this->load->model('Course_model');
		$this->load->library('form_validation');
    }
	 function index() 
	{
		$this->load->library('pagination');
        $params = array();
        $limit_per_page = 10;
        $page = ($this->uri->segment(4)) ? ($this->uri->segment(4) - 1) : 0;
        #echo $this->uri->segment(3);exit();
        $total_records = $this->Student_group_model->get_total_gorup();
         // echo $total_records;exit;
        if($total_records > 0)
        {
            $this->data['arrStudent_group'] = $this->Student_group_model->get_list_group($limit_per_page, $page*$limit_per_page);
                 
            $config['base_url'] = base_url() . 'Group';
            $config['total_rows'] = $total_records;
            $config['per_page'] = $limit_per_page;
            $config["uri_segment"] = 4;
             
            // custom paging configuration
            $config['num_links'] =2;
            $config['use_page_numbers'] = TRUE;
            $config['reuse_query_string'] = TRUE;
             
            $config['full_tag_open'] = '<div class="pagination">';
            $config['full_tag_close'] = '</div>';
             
            $config['first_link'] = 'First Page';
            $config['first_tag_open'] = '<span class="firstlink">';
            $config['first_tag_close'] = '</span>';
             
            $config['last_link'] = 'Last Page';
            $config['last_tag_open'] = '<span class="lastlink">';
            $config['last_tag_close'] = '</span>';
             
            $config['next_link'] = 'Next Page';
            $config['next_tag_open'] = '<span class="nextlink">';
            $config['next_tag_close'] = '</span>';
 
            $config['prev_link'] = 'Prev Page';
            $config['prev_tag_open'] = '<span class="prevlink">';
            $config['prev_tag_close'] = '</span>';
 
            $config['cur_tag_open'] = '<span class="curlink">';
            $config['cur_tag_close'] = '</span>';
 
            $config['num_tag_open'] = '<span class="numlink">';
            $config['num_tag_close'] = '</span>';
             
            $this->pagination->initialize($config);
                 
            // build paging links
            $this->data["links"] = $this->pagination->create_links();
            $this->data['page_no'] = $page*$limit_per_page;
        }
        $this->template->write_view('content', 'student_group/list_group', $this->data, true);
        $this->template->write_view('css', 'dashboard/courcecss', $this->data, true);
        $this->template->write_view('js', 'dashboard/coursejs', $this->data, true);
        $this->template->render();
	}
	function create_group() 
	{
        //echo "<pre>";print_r($this->Student_model->check_domain_user($this->input->post()));exit;
       if ($this->input->post()) 
		{
			 $config = array
				 (
					array(
						'field' => 'name',
						'label' => 'Group Title',
						'rules' => 'required'
					),
				 );
			$this->form_validation->set_rules($config);
            if ($this->form_validation->run() == TRUE) 
			{
                $arrCheckUser =array();
				if (empty($arrCheckUser)) 
				{
					 $arrStudentgroup = array(
                        'name'=>$this->input->post('name'),
						'members'=>implode(",",$this->input->post('student_id')),
                        'status' =>1,
                        'domain_id' =>$this->session->userdata('current_user')[0]['domain_id']
                    );
					
					//$intGroup1 = $this->Student_group_model->insertData('tbl_student_group',$arrStudentgroup);
                    $intGroup = $this->Student_group_model->insertData('tbl_student_group',$arrStudentgroup);
					
                    //echo "<pre>";print_r($this->db->last_query());exit;
                    if(!empty($intGroup))
                    {
                        redirect("Group");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
				}
			}
		}
		$this->data['allstudent'] = $this->Student_model->get_list_students();
        $this->template->write_view('content', 'student_group/add_group', $this->data, true);
        $this->template->write_view('css', 'student/add_css', $this->data, true);
        $this->template->write_view('js', 'student/add_js', $this->data, true);
        $this->template->render();

    }
	function edit($id=0) 
	{
		$group = $this->Student_group_model->listData('tbl_student_group','*',array('id'=>$id),'',true);
        $this->data['group'] = $group[0];
      // echo "<pre>";print_r($this->data['group']);exit;
	   if ($this->input->post()) 
	   {
		   
	   $config = array
				 (
					array(
						'field' => 'name',
						'label' => 'Group Title',
						'rules' => 'required'
					),
				 );
			$this->form_validation->set_rules($config);
            if ($this->form_validation->run() == TRUE) 
			{
                $arrCheckUser =array();
				if (empty($arrCheckUser)) 
				{
					 $arrStudentgroup = array(
                        'name'=>$this->input->post('name'),
						'members'=>implode(",",$this->input->post('student_id')),
                        'status' =>1,
                        'domain_id' =>$this->session->userdata('current_user')[0]['domain_id']
                    );
					//$this->Student_model->updateData('tbl_users',$arrStudent,array('id'=>$id));
					//$intGroup1 = $this->Student_group_model->insertData('tbl_student_group',$arrStudentgroup);
                    $intGroup = $this->Student_group_model->updateData('tbl_student_group',$arrStudentgroup,array('id'=>$id));
					
                    //echo "<pre>";print_r($this->db->last_query());exit;
                    if(!empty($intGroup))
                    {
                        redirect("Group");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
				}
			}
		}
		$this->data['allstudent'] = $this->Student_model->get_list_students();
        $this->template->write_view('content', 'student_group/edit_group', $this->data, true);
        $this->template->write_view('css', 'student/add_css', $this->data, true);
        $this->template->write_view('js', 'student/add_js', $this->data, true);
        $this->template->render();

	}
	function delete($id=0)
	{
		if(!empty($id))
        {
            $arrSession = $this->session->userdata('current_user');
            $this->Student_model->updateData('tbl_student_group',array('deleted_by'=>isset($arrSession[0]['id']) ? $arrSession[0]['id'] : 1),array('id'=>$id),true);
            //echo $this->db->last_query();exit;
        }
        redirect('Group/index');
	}
}
?>