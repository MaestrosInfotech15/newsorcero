<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Instructor extends FrontendController 
{

    protected $domain_id;

    function __construct() 
	{
        parent::__construct(array());
        $this->load->model(array("Instructor_model"));
    }

    function index() 
	{
        $this->load->library('pagination');
        $params = array();
        $limit_per_page = 10;
        $page = ($this->uri->segment(4)) ? ($this->uri->segment(4) - 1) : 0;
        #echo $this->uri->segment(3);exit();
        $total_records = $this->Instructor_model->get_total_instructor();
        //echo $total_records;exit;
        if($total_records > 0)
        {
            $this->data['arrStudent'] = $this->Instructor_model->get_list_instructors($limit_per_page, $page*$limit_per_page);
                 
            $config['base_url'] = base_url() . 'instructor/index/page';
            $config['total_rows'] = $total_records;
            $config['per_page'] = $limit_per_page;
            $config["uri_segment"] = 4;
             
            // custom paging configuration
            $config['num_links'] =2;
            $config['use_page_numbers'] = TRUE;
            $config['reuse_query_string'] = TRUE;
             
            $config['full_tag_open'] = '<div class="pagination">';
            $config['full_tag_close'] = '</div>';
             
            $config['first_link'] = 'First Page';
            $config['first_tag_open'] = '<span class="firstlink">';
            $config['first_tag_close'] = '</span>';
             
            $config['last_link'] = 'Last Page';
            $config['last_tag_open'] = '<span class="lastlink">';
            $config['last_tag_close'] = '</span>';
             
            $config['next_link'] = 'Next Page';
            $config['next_tag_open'] = '<span class="nextlink">';
            $config['next_tag_close'] = '</span>';
 
            $config['prev_link'] = 'Prev Page';
            $config['prev_tag_open'] = '<span class="prevlink">';
            $config['prev_tag_close'] = '</span>';
 
            $config['cur_tag_open'] = '<span class="curlink">';
            $config['cur_tag_close'] = '</span>';
 
            $config['num_tag_open'] = '<span class="numlink">';
            $config['num_tag_close'] = '</span>';
             
            $this->pagination->initialize($config);
                 
            // build paging links
            $this->data["links"] = $this->pagination->create_links();
        }
        //echo "<pre>";print_r($this->data);exit;
        #$this->data['arrStudent'] = $this->Instructor_model->get_list_students();
        $this->template->write_view('content', 'instructor/list_instructor', $this->data, true);
        $this->template->write_view('js','instructor/list_js',$this->data,true);
        $this->template->render();
    }

    function add() 
	{
       //echo "<pre>";print_r($this->Instructor_model->check_domain_user($this->input->post()));exit;
        if ($this->input->post()) 
		{
            $config = array(
                array(
                    'field' => 'fname',
                    'label' => 'First Name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'lname',
                    'label' => 'Last Name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'username',
                    'label' => 'Username',
                    'rules' => 'required|alpha'
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required',
                    'errors' => array(
                        'required' => 'You must provide a %s.',
                    ),
                ),
                array(
                    'field' => 'email',
                    'label' => 'Email',
                    'rules' => 'required|valid_email'
                )
            );
           $this->form_validation->set_rules($config);
            if ($this->form_validation->run() == TRUE) 
			{
               $arrCheckUser = $this->Instructor_model->check_domain_user($this->input->post());
                
              if (empty($arrCheckUser)) 
			  {

                    $arrStudent = array(
                        'role_id'=>INSTRUCTOR_ROLE,
                        'email' => $this->input->post('email'),
                        'username' => $this->input->post('username'),
                        'password' => md5($this->input->post('password')),
                        'fname' => $this->input->post('fname'),
                        'lname' => $this->input->post('lname'),
                        'status' => $this->input->post('status'),
                        'emailsubscribe' => $this->input->post('emailsubscribe'),
                        'fburl' => $this->input->post('fburl'),
                        'linkedinurl' => $this->input->post('linkedinurl'),
                        'youtubeurl' => $this->input->post('youtubeurl'),
                        'twitterurl' => $this->input->post('twitterurl'),
                        'mediumurl' => $this->input->post('mediumurl'),
                        'weburl' => $this->input->post('weburl'),
                        'domain_id' => $this->session->userdata('current_user')[0]['domain_id']
                    );
                    $intStudentId = $this->Instructor_model->insertData('tbl_users',$arrStudent);
                  // echo "<pre>";print_r($this->db->last_query());exit;
                    if(!empty($intStudentId))
                    {
                        redirect("instructor/index");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
                }
                else
                {
                    $this->session->set_flashdata('error','Email or username already exist');
                }
            }
            $this->template->write_view('css', 'instructor/add_css', $this->data, true);
            $this->template->write_view('js', 'instructor/add_js', $this->data, true);
            $this->template->write_view('content', 'instructor/add', $this->data, true);
            $this->template->render();
        } else 
		{
            $this->template->write_view('css', 'instructor/add_css', $this->data, true);
            $this->template->write_view('js', 'instructor/add_js', $this->data, true);
            $this->template->write_view('content', 'instructor/add', $this->data, true);
            $this->template->render();
        }
    }
    function edit($id=0) 
	{
        $arrStudent = $this->Instructor_model->listData('tbl_users','*',array('id'=>$id),'',true);
        $this->data['arrStudent'] = $arrStudent[0];
        //echo "<pre>";print_r($this->data['arrStudent']);exit;
        if ($this->input->post()) 
		{
            $config = array(
                array(
                    'field' => 'fname',
                    'label' => 'First Name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'lname',
                    'label' => 'Last Name',
                    'rules' => 'required'
                ),
                array(
                    'field' => 'username',
                    'label' => 'Username',
                    'rules' => 'required|alpha'
                ),
                array(
                    'field' => 'password',
                    'label' => 'Password',
                    'rules' => 'required',
                    'errors' => array(
                        'required' => 'You must provide a %s.',
                    ),
                ),
                array(
                    'field' => 'email',
                    'label' => 'Email',
                    'rules' => 'required|valid_email'
                )
            );
            $this->form_validation->set_rules($config);
            if ($this->form_validation->run() == TRUE) 
			{
                $arrCheckUser = $this->Instructor_model->check_domain_user($this->input->post(),$id);
                
                if (empty($arrCheckUser)) {

                    $arrStudent = array(
                        'role_id'=>INSTRUCTOR_ROLE,
                        'email' => $this->input->post('email'),
                        'username' => $this->input->post('username'),
                        'password' => md5($this->input->post('password')),
                        'fname' => $this->input->post('fname'),
                        'lname' => $this->input->post('lname'),
                        'status' => $this->input->post('status'),
                        'emailsubscribe' => $this->input->post('emailsubscribe'),
                        'fburl' => $this->input->post('fburl'),
                        'linkedinurl' => $this->input->post('linkedinurl'),
                        'youtubeurl' => $this->input->post('youtubeurl'),
                        'twitterurl' => $this->input->post('twitterurl'),
                        'mediumurl' => $this->input->post('mediumurl'),
                        'weburl' => $this->input->post('weburl'),
                        'domain_id' => $this->session->userdata('current_user')[0]['domain_id']
                    );
                    $intStudentId = $this->Instructor_model->updateData('tbl_users',$arrStudent,array('id'=>$id));
                    //echo "<pre>";print_r($this->db->last_query());exit;
                    if($intStudentId==TRUE)
                    {
                        redirect("instructor/index");
                    }
                    else
                    {
                        $this->session->set_flashdata('error','Something went wrong please try again !');
                    }
                }
                else
                {
                    $this->session->set_flashdata('error','Email or username already exist');
                }
            }
            $this->template->write_view('content', 'instructor/edit', $this->data, true);
            $this->template->write_view('css', 'instructor/add_css', $this->data, true);
            $this->template->write_view('js', 'instructor/add_js', $this->data, true);
            $this->template->render();
        } else 
		{
            $this->template->write_view('content', 'instructor/edit', $this->data, true);
            $this->template->write_view('css', 'instructor/add_css', $this->data, true);
            $this->template->write_view('js', 'instructor/add_js', $this->data, true);
            $this->template->render();
        }
    }

 	function delete($id=0)
    {
		//echo $id;
        if(!empty($id))
        {
            $arrSession = $this->session->userdata('current_user');
            $this->Instructor_model->updateData('tbl_users',array('deleted_by'=>isset($arrSession[0]['id']) ? $arrSession[0]['id'] : 1),array('id'=>$id),true);
            //echo $this->db->last_query();exit;
        }
        redirect('instructor/index');
        
    }

}

?>
