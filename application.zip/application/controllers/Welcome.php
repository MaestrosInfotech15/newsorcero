<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    protected $domain;

    function __construct() {
        parent::__construct();
        //$this->load->model('User_model');
        $this->load->model(array('user_model'));
        $url = $_SERVER['HTTP_HOST'];
        $subdomain = str_replace(SITEURL, '', $url);
        $subdomain_arr = explode('.', $subdomain);
        if (!empty($subdomain_arr[0])) {
            $this->domain = $subdomain_arr[0];
        } else {
            //redirect(BASEURL . 'create');
        }



        //$this->load->model('setting_model');
    }

    public function index() {
        ///////////////Site Setting///////////////////////
        //$site_setting = $this->login_model->get_site_setting();
        //$site_setting = $site_setting[0];
        $this->data['site_title'] = "Socero";
        $user = $this->session->userdata('current_user');
        if ($user) {
            redirect('dashboard');
        }
        $this->data['domain'] = $this->domain;
        $this->template->write('pagetitle', 'Login');
        $this->template->write_view('content', 'welcome/index', $this->data, true);
        //$this->template->write_view('js', 'login/js', $this->data, true);
        $this->template->render();
    }

}
