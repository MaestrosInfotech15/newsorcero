<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login extends CI_Controller {

    protected $domain;

    function __construct() {
        parent::__construct();
        //$this->load->model('User_model');
        $this->load->model(array('user_model'));
        $url = $_SERVER['HTTP_HOST'];
        $subdomain = str_replace(SITEURL, '', $url);
        $subdomain_arr = explode('.', $subdomain);
        if (!empty($subdomain_arr[0])) {
            $this->domain = $subdomain_arr[0];
        } else {
            //redirect(BASEURL . 'create');
        }



        //$this->load->model('setting_model');
    }

    public function index() {
        ///////////////Site Setting///////////////////////
        //$site_setting = $this->login_model->get_site_setting();
        //$site_setting = $site_setting[0];
        $this->data['site_title'] = "Socero";
        $user = $this->session->userdata('current_user');
        if ($user) {
            redirect('dashboard');
        }
        $check_error = $this->session->userdata('invalid_cred');
        if (!empty($check_error)) {
            $this->data['error'] = "Invalid Credentials";
            $this->session->unset_userdata('invalid_cred');
        } else {
            $this->data['error'] = "";
        }
        $this->template->write('pagetitle', 'Login');
        $this->template->write_view('content', 'login/index', $this->data, true);
        //$this->template->write_view('js', 'login/js', $this->data, true);
        $this->template->render();
    }

    public function check_login() {
        $logindetails['current_user'] = $this->login_model->check_login($this->input->post(), $this->domain);
        //echo "<pre>";print_r($this->db->last_query());exit;
        if (empty($logindetails['current_user'])) {
            $this->session->unset_userdata('current_user');
            $this->session->set_flashdata('error', 'Invalid credential');
            redirect('login');
        } else {
            $this->session->set_userdata($logindetails);
            redirect('dashboard');
        }
    }

    public function register() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('domain_name', 'Domain Name', 'required|alpha');
            $this->form_validation->set_rules('fname', 'Name', 'required');
            $this->form_validation->set_rules('email', 'Email Address', 'required|valid_email|is_unique[tbl_users.email]');
            $this->form_validation->set_rules('username', 'Username', 'required|is_unique[tbl_users.username]');
            if ($this->form_validation->run() == TRUE) {
                $arrRegister = array(
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'fname' => $this->input->post('fname'),
                    'password' => md5($this->input->post('password')),
                    'role_id' => 1,
                    'status' => 0
                );
                //echo "<pre>";print_r($arrRegister);exit;
                $intUserId = $this->user_model->add_user($arrRegister);
                ///echo "<pre>";print_r($this->db->last_query());exit;
                if ($intUserId > 0) {
                    $intDomainId = $this->user_model->add_domain(array("domain_name" => $this->input->post('domain_name'), 'user_id' => $intUserId));
                    if ($intDomainId > 0) {
                        $intUpdate = $this->user_model->update_user(array("domain_id" => $intDomainId), $intUserId);
                        if ($intUpdate) {
                            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "http://" : "http://";
                            $strDomain = $protocol . $this->input->post("domain_name") . "." . SITEURL . '/verify_email';
                            //redirect($strDomain);
                            $arrEmail = $this->user_model->list_data("tbl_email_templates", "*", array("slug" => "REGISTRATION"));
                            $strHtml = $arrEmail[0]['content'];
                            $strHtml = str_replace(array('{{action_url}}'), array($strDomain), $strHtml);

                            $this->load->library('email');
                            $this->email->from('info@sorcero.net', 'Sorcero');
                            $this->email->to($this->input->post('email'));
                            $this->email->subject($arrEmail[0]['subject']);
                            $this->email->set_mailtype('html');
                            $this->email->message($strHtml);
                            //$this->email->send();
                            redirect("register-thank-you");
                        } else {
                            $this->session->set_flashdata("error", "Something went wrong please try again");
                        }
                    } else {
                        $this->session->set_flashdata("error", "Domain not register please try again");
                    }
                } else {
                    $this->session->set_flashdata("error", "User not register try again");
                }
            }
            $this->template->write('pagetitle', 'Registration');
            $this->template->write_view('content', 'login/register', $this->data, true);
            //$this->template->write_view('js', 'login/js', $this->data, true);
            $this->template->render();
        } else {
            $this->template->write('pagetitle', 'Registration');
            $this->template->write_view('content', 'login/register', $this->data, true);
            //$this->template->write_view('js', 'login/js', $this->data, true);
            $this->template->render();
        }
    }

    public function forgot_password() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('username', 'Email Address', 'required|valid_email');
            if ($this->form_validation->run() == TRUE) {
                $arrUser = $this->login_model->check_valid_user($this->domain, $this->input->post());
                if (!empty($arrUser)) {
                    $email = md5($arrUser['email']);
                    redirect('generate-password/' . $email);
                } else {
                    $this->session->set_flashdata("error", "Email not found in system");
                    redirect('forgot-password');
                }
            } else {
                $this->session->set_flashdata('error', validation_errors());
                redirect('forgot-password');
            }
        } else {
            $this->template->write('pagetitle', 'Forgot password');
            $this->template->write_view('content', 'login/forgot_password', $this->data, true);
            //$this->template->write_view('js', 'login/js', $this->data, true);
            $this->template->render();
        }
    }

    public function logout() {
        $this->session->unset_userdata('users_color');
        $this->session->unset_userdata('current_user');
        $this->session->unset_userdata('invalid_cred');
        redirect('login');
    }

    public function reset_password($email = '') {
        if ($this->input->post()) {
            $this->form_validation->set_rules('pass', 'Password', 'required');
            $this->form_validation->set_rules('pass_confirmation', 'Password Confirmation', 'required|matches[pass]');
            if ($this->form_validation->run() == TRUE) {
                $arrUser = $this->login_model->check_valid_user($this->domain, $this->input->post(), 1, $email);
                if (!empty($arrUser)) {
                    $update = $this->login_model->update_password($arrUser, $this->input->post());
                    if ($update) {
                        $this->session->set_flashdata("error", "Password update successfully");
                        redirect('login');
                    } else {
                        $this->session->set_flashdata("error", "Please try after some time!!");
                        redirect('generate-password/' . $email);
                    }
                } else {
                    $this->session->set_flashdata("error", "Email not found in system");
                    redirect('generate-password/' . $email);
                }
            } else {
                $this->session->set_flashdata('error', validation_errors());
                redirect('generate-password/' . $email);
            }
        } else {
            $arrUser = $this->login_model->check_valid_user($this->domain, $this->input->post(), 1, $email);
            if (!empty($arrUser)) {
                $this->data['email'] = $email;
                $this->template->write('pagetitle', 'Forgot password');
                $this->template->write_view('content', 'login/reset_password', $this->data, true);
                //$this->template->write_view('js', 'login/js', $this->data, true);
                $this->template->render();
            } else {
                redirect('login');
            }
        }
    }

    public function check_avialable_domain() {
        $response = array(
            'valid' => false,
            'message' => 'Domain name is missing.'
        );

        if (!empty($_POST['domain_name'])) {
            $userRepo = $this->login_model->check_domain($_POST['domain_name']);
            //echo "<pre>";print_r($this->db->last_query());exit;
            if (!empty($userRepo)) {
                // User name is registered on another account
                $response = array('valid' => false, 'message' => 'This domain is already registered.');
            } else {
                // User name is available
                $response = array('valid' => true);
            }
        }
        echo json_encode($response);
    }

    public function register_thank_you() {
        $this->template->write('pagetitle', 'Registration');
        $this->template->write_view('content', 'login/thankyou', $this->data, true);
        //$this->template->write_view('js', 'login/js', $this->data, true);
        $this->template->render();
    }
    public function verify_email()
    {
       if(!empty($this->domain))
       {
           $intUpate = $this->user_model->update_domain_user($this->domain);
           if($intUpate)
           {
               $this->data['msg'] = "Email Verify successfully";
               $this->data['success'] = 1;
           }
           else
           {
               $this->data['msg'] = "Email Verification failed.";
               $this->data['success'] = 0;
           }
       }
       $this->template->write('pagetitle', 'Registration');
        $this->template->write_view('content', 'login/verificatioin', $this->data, true);
        //$this->template->write_view('js', 'login/js', $this->data, true);
        $this->template->render();
    }

}
