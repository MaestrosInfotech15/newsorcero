<?php

class Instructor_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }
    function get_list_instructors($limit, $start)
    {
         $intDomain = 0;
        if(!empty($this->session->userdata('current_user')[0]['domain_id']))
        {
            $intDomain = $this->session->userdata('current_user')[0]['domain_id'];
        }
        $this->db->select("*,CONCAT_WS(' ',fname,lname) as student_name,,CASE status WHEN '0' THEN 'Inactive' ELSE 'Active' END AS status");
        $this->db->from("tbl_users tu");
        $this->db->where(array("tu.role_id"=>INSTRUCTOR_ROLE,"tu.domain_id"=>$intDomain,"deleted_by"=>0));
        $this->db->order_by("tu.id","desc");
        $this->db->limit($limit, $start);

        return $this->db->get()->result_array();
    }
    function get_total_instructor()
    {
        $intDomain = 0;
        if(!empty($this->session->userdata('current_user')[0]['domain_id']))
        {
            $intDomain = $this->session->userdata('current_user')[0]['domain_id'];
        }
        $this->db->select("COUNT(*) AS total_students");
        $this->db->from("tbl_users tu");
        $this->db->where(array("tu.role_id"=>INSTRUCTOR_ROLE,"tu.domain_id"=>$intDomain,"deleted_by"=>0));
        $this->db->order_by("tu.id","desc");
        $arrTotal = $this->db->get()->row_array();
        return $arrTotal['total_students'];
    }
}
?>