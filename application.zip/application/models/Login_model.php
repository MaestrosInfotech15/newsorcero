<?php

class Login_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function check_login($data,$domain) {
        $this->db->select('u.id as user_id,u.email,u.domain_id,u.fname,u.lname');
        $this->db->from('tbl_users u');
        $this->db->join('tbl_roles as r', 'u.role_id=r.id');
        $this->db->join('tbl_domains as d', 'd.id=u.domain_id');
        $password = md5($data['password']);
        $this->db->where('u.status', 1);
        $this->db->where('u.deleted_by', 0);
        $this->db->where('d.domain_name',$domain);
        $this->db->group_start();
            $this->db->where('u.email', $data['username']);
            $this->db->or_where('u.username', $data['username']);
        $this->db->group_end();
        $this->db->where("u.password",$password);
        $query = $this->db->get();
        $res = $query->result_array();
        //echo "<pre>";print_r($this->db->last_query());exit;
        return $res;
    }

    public function check_valid_user($domain,$data,$reset_password=0,$email='')
    {
        $this->db->select('u.id as user_id,u.email,u.domain_id,u.fname,u.lname');
        $this->db->from('tbl_users u');
        $this->db->join('tbl_roles as r', 'u.role_id=r.id');
        $this->db->join('tbl_domains as d', 'd.id=u.domain_id');
        $this->db->where('u.status', 1);
        $this->db->where('u.deleted_by', 0);
        $this->db->where('d.domain_name',$domain);
        if($reset_password==1)
        {
            $this->db->where("MD5(u.email)",$email);
        }
        else
        {
            $this->db->where('u.email', $data['username']);
        }
        $query = $this->db->get();
        $res = $query->row_array();
        return $res; 
    }
    function update_password($arrUser,$data)
    {
        //echo "<pre>";print_r($arrUser);exit;
        $this->db->where("id",$arrUser['user_id']);
        return $this->db->update("tbl_users",array("password"=> md5($data['pass'])));
        //echo "<pre>";print_r($this->db->last_query());exit;
    }
    function check_domain($domain_name)
    {
        $this->db->select('*');
        $this->db->from('tbl_domains');
        $this->db->where('domain_name',$domain_name);
        return $this->db->get()->result_array();
    }

}

?>
