<?php

class Category_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }
    function get_list_category($limit, $start)
    {
         $intDomain = 0;
        if(!empty($this->session->userdata('current_user')[0]['domain_id']))
        {
            $intDomain = $this->session->userdata('current_user')[0]['domain_id'];
        }
        $this->db->select("*");
        $this->db->from("tbl_course_category tu");
        $this->db->where(array("tu.domain_id"=>$intDomain,"deleted_by"=>0));
        $this->db->order_by("tu.id","desc");
        $this->db->limit($limit, $start);

        return $this->db->get()->result_array();
    }
    function get_total_category()
    {
        $intDomain = 0;
        if(!empty($this->session->userdata('current_user')[0]['domain_id']))
        {
            $intDomain = $this->session->userdata('current_user')[0]['domain_id'];
        }
        $this->db->select("COUNT(*) AS total_category");
        $this->db->from("tbl_course_category tu");
        $this->db->where(array("tu.domain_id"=>$intDomain,"deleted_by"=>0));
        $this->db->order_by("tu.id","desc");
        $arrTotal = $this->db->get()->row_array();
        return $arrTotal['total_category'];
    }
}
?>