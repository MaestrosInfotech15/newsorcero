<?php

class User_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function add_user($data = array()) {
        $this->db->insert('tbl_users', $data);
        return $this->db->insert_id();
    }

    function add_domain($data = array()) {
        $this->db->insert('tbl_domains', $data);
        return $this->db->insert_id();
    }

    function update_user($data = array(), $user_id) {
        $this->db->where("id", $user_id);
        return $this->db->update("tbl_users", $data);
    }
	  function get_list_users($limit, $start)
    {
        $this->db->select("*");
        $this->db->from("tbl_users");
        $this->db->order_by("id","desc");
        $this->db->limit($limit, $start);

        return $this->db->get()->result_array();
    }

    public function list_data($table, $select = "*", $strWhere = array()) {
        $this->db->select($select);
        $this->db->from($table);
        if (is_array($strWhere) && !empty($strWhere)) {
            $this->db->where($strWhere);
        }
        return $this->db->get()->result_array();
    }

    public function update_domain_user($strDomain = '') {
       return $this->db->query("UPDATE tbl_users JOIN tbl_domains ON tbl_users.domain_id = tbl_domains.id AND tbl_domains.user_id = tbl_users.id SET tbl_users.status = 1 WHERE tbl_domains.domain_name = '".$strDomain."'");
    }

}

?>
