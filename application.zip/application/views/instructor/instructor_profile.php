<main class="main-wrapper clearfix">
            <!-- Page Title Area -->
            <section class="">
                <div class="row page-title clearfix">

                    <div class="page-title-left">
                        <ol class="breadcrumb">

                            <li class="breadcrumb-item"><a href="./index.html">Dashboard</a>
                            </li>
                            <li class="breadcrumb-item"><a href="./manage-instructors.html">Manage Instructors</a>
                            </li>

                        </ol>
                    </div>
                </div>
                <div class="row  clearfix">
                    <div class="col-sm-4 col-md-6">
                        <h6 class="page-title-heading color-blue mr-0 mr-r-5">Instructor Profile</h6>
                    </div>
                    <div class="col-sm-8 col-md-6 text-right">
                        <button class="btn btn-rounded custom-btn BlueGrad ripple edit" >Edit Profile
                        </button>

                    </div>
                </div>
            </section>
            <section class="category-list-section">
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <img src="<?php echo base_url();?>assets/img/profile.png">
                        <!-- /.list-group -->
                        <div class="profile-name">Fahad Khan</div>
                        <div class="profile-id">@fahadk</div>
                        <div class="profile-social-meida-list">
                            <ul class="list-inline">
                                <li>
                                    <a href="fa fa-facebook"></a>
                                </li>
                                <li>
                                    <a href="fa fa-facebook"></a>
                                </li>
                                <li>
                                    <a href="fa fa-facebook"></a>
                                </li>
                                <li>
                                    <a href="fa fa-facebook"></a>
                                </li>
                            </ul>
                        </div>
                        <div class="about-profile">
                            <p>
                                As a high school math teacher at Naperville Central High School in Illinois, Sladkey's active style of teaching helps students remain engaged and eager to learn, but it took years of growth, preparation, and work for Sladkey to arrive where he is today. Sladkey's interest in teaching continued to grow throughout high school, where one of his teachers inspired him to follow his dream of teaching. His teacher's attitude and way of working with students pushed Sladkey to enroll in a teacher preparation program.
                            </p>
                        </div>
                        <h6>Courses Offers</h6>
                        <table class="table table-striped normal-table">
                            <thead>
                            <th></th>
                            <th>
                                S.No
                            </th>
                            <th class="text-center">
                                Duration
                            </th>
                            <th class="text-center">
                                Learners Enrolled
                            </th>
                            <th class="text-center">
                                Certified Learners
                            </th>
                            <th>
                                Creation Date
                            </th>
                            <th>
                                Course Creator
                            </th>
                            <th>
                                Action
                            </th>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td>Fahad khan</td>
                                <td>fahadkhan@gmail.com</td>
                                <td>0012</td>
                                <td>Active</td>
                                <td>07:18 AM 2018-01-01</td>
                                <td>Course Title Here</td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-trash list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                            </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </section>


        </main>