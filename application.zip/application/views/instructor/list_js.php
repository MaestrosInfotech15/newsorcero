<script type="text/javascript">
    $(document).on('click', '.delete_student', function (e) {
        e.preventDefault();
        var conf = confirm('Are you sure want to delete student');
        if (conf)
        {
            return true;
        }
        return false;
    });
</script>