<main class="main-wrapper clearfix">
 <form method="post" action="<?php echo base_url('instructor/add');?>" name="frmAddStudent" id="frmAddStudent">
    <section class="">
        <div class="row page-title clearfix">

            <div class="page-title-left">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url("dashboard"); ?>">Dashboard</a>
                    </li>

                    <li class="breadcrumb-item"><a href="<?php echo base_url("instructor"); ?>">Instructors</a>
                    </li>
                    <li class="breadcrumb-item"><a href="javascipt:void(0);">Manage Instructor</a>
                    </li>
                </ol>
            </div>
        </div>
        <div class="row  clearfix">
            <div class="col-sm-4 col-md-6">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">Create Instructor</h6>
            </div>
            <div class="col-sm-8 col-md-6 text-right">
                <a class="btn btn-rounded custom-btn whiteGrad ripple" href="<?php echo base_url('instructor'); ?>">Discard
                </a>
                <button class="btn btn-rounded custom-btn BlueGrad ripple" id="btnSave" type="submit">Save
                </button>

            </div>
        </div>
    </section>
    <section class="content-section add-form">
       
            <div class="row">
                <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong>Oh snap!</strong> <?php echo $this->session->flashdata('error'); ?>
                    </div>  
                <?php endif; ?>
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l36" class="label">First Name</label>
                                <input class="form-control" name="fname" value="<?php echo set_value('fname'); ?>"/>
                                <?php echo form_error('fname'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l37" class="label">Last Name</label>
                                <input id="137" class="form-control" name="lname" value="<?php echo set_value('lname'); ?>" />
                                <?php echo form_error('lname'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l36" class="label">Email</label>
                                <input class="form-control" name="email" value="<?php echo set_value('email'); ?>"/>
                                <?php echo form_error('email'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="selectpicker1" class="form-control-label" class="label">User Type</label>
                                <select id="selectpicker1" class="form-control selectpicker">
                                    <option>Instructor</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l37" class="label">User Name</label>
                                <input class="form-control" name="username" value="<?php echo set_value('username'); ?>"/>
                                <?php echo form_error('username'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l36" class="label">Password</label>
                                <input class="form-control" name="password" />
                                <?php echo form_error('password'); ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <div class=""><label class="label">Status</label></div>
                                <label class="custom-control custom-radio">
                                    <input name="status" type="radio" class="custom-control-input" value="1">
                                    <span class="custom-control-indicator"></span>
                                    <span class="custom-control-description">Active</span>
                                </label>
                                <label class="custom-control custom-radio">
                                    <input id="mixed0" name="status" checked="" type="radio" class="custom-control-input" value="0">
                                    <span class="custom-control-indicator"></span>
                                    <span class="custom-control-description">InActive</span>
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <div class=""><label class="label">Email Subscription</label></div>
                                <label class="custom-control custom-radio">
                                    <input name="cat" type="emailsubscribe" class="custom-control-input" value="1">
                                    <span class="custom-control-indicator"></span>
                                    <span class="custom-control-description">Active</span>
                                </label>
                                <label class="custom-control custom-radio">
                                    <input id="mixed0" name="emailsubscribe" checked="" type="radio" class="custom-control-input" value="0">
                                    <span class="custom-control-indicator"></span>
                                    <span class="custom-control-description">InActive</span>
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <div class=""><label class="label">Profile Picture</label></div>
                                <div class="mb-3"><img src="<?php echo base_url(); ?>assets/img/default-avatar.jpg"></div>
                                <label class="   pr">
                                    <input type="file" class="filestyle" name="userfile"
                                           data-icon="false">

                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 mb-5">
                    <h6 class=" color-blue mr-0 mr-r-5 ">Web Social Media Links</h6>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="l36" class="label">Linkedin</label>
                        <input class="form-control" name="linkedinurl" value="<?php echo set_value('linkedinurl'); ?>"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="l36" class="label">Website</label>
                        <input class="form-control" name="weburl" value="<?php echo set_value('weburl'); ?>"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="l36" class="label">Twitter</label>
                        <input class="form-control" name="twitterurl" value="<?php echo set_value('twitterurl'); ?>"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="l36" class="label">Medium</label>
                        <input class="form-control" name="mediumurl" value="<?php echo set_value('mediumurl'); ?>"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="l36" class="label">Facebook</label>
                        <input class="form-control" name="fburl" value="<?php echo set_value('fburl'); ?>"/>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="l36" class="label">Youtube</label>
                        <input class="form-control" name="youtubeurl" value="<?php echo set_value('youtubeurl'); ?>"/>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 mb-5">
                <h6 class=" color-blue mr-0 mr-r-5 ">Add Data Form</h6>
            </div>
            <div class="col-sm-12">
                <div class="tabs tabs-bordered tabs_create_course">
                    <ul class="nav nav-tabs nav-justified">
                        <li class="nav-item"><a class="nav-link active" href="#sales-force"
                                                data-toggle="tab" aria-expanded="true">Sales Force</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="#other-widget" data-toggle="tab"
                                                aria-expanded="true">Other Widget</a>
                        </li>
                    </ul>
                    <div class="tab-content custom-tab-content ">
                        <div class="tab-pane active " id="sales-force">
                            <div class="container">
                                Sales Force
                            </div>
                        </div>
                        <div class="tab-pane  " id="other-widget">
                            <div class="container">
                                Other Widget
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 mb-5">
                <h6 class=" color-blue mr-0 mr-r-5 ">Assign Courses</h6>
            </div>
            <div class="col-sm-12">

                <select id="pre-selected-options" class="form-control" data-toggle="multiselect" multiple="multiple">
                    <option value="elem_1" />elem 1
                    <option value="elem_2" />elem 2
                    <option value="elem_3" />elem 3
                    <option value="elem_4" selected="selected" />elem 4
                    <option value="elem_5" selected="selected" />elem 5
                    <option value="elem_6" />elem 6
                    <option value="elem_7" />elem 7
                    <option value="elem_8" />elem 8
                    <option value="elem_9" />elem 9
                    <option value="elem_10" />elem 10
                    <option value="elem_11" />elem 11
                    <option value="elem_12" />elem 12
                    <option value="elem_13" />elem 13
                    <option value="elem_14" />elem 14
                    <option value="elem_15" />elem 15
                    <option value="elem_16" />elem 16
                    <option value="elem_17" />elem 17
                    <option value="elem_18" />elem 18
                    <option value="elem_19" />elem 19
                    <option value="elem_20" />elem 20
                </select>
            </div>
       
    </section>
 </form>

</main>

