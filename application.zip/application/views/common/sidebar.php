<!-- SIDEBAR -->
<aside class="site-sidebar scrollbar-enabled" data-suppress-scroll-x="true">

    <!-- /.side-user -->
    <!-- Sidebar Menu -->
    <nav class="sidebar-nav">
        <ul class="nav in side-menu">
            <li class="current-page ">
                <a href="<?php echo base_url('dashboard');?>"><i class="list-icon feather feather-command"></i> <span
                        class="hide-menu">Dashboard</span></a>

            </li>
            <li class="menu-item-has-children active">
                <a href="javascript:void(0);"><i class="list-icon fa fa-graduation-cap"></i> <span
                        class="hide-menu">Courses</span></a>
                <ul class="list-unstyled sub-menu">
                    <li><a href="<?php echo base_url('course/create');?>">Create Course</a>
                    </li>
                    <li><a href="<?php echo base_url('Dashboard/lists');?>">Manage Courses</a>
                    </li>
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="javascript:void(0);"><i class="list-icon feather feather-tag"></i> <span
                        class="hide-menu">Categories</span></a>
                <ul class="list-unstyled sub-menu">
                    <li><a href="<?php echo base_url('categories');?>">Manage categories </a>
                    </li>
                    <li><a href="#">Link 2</a>
                    </li>

                   
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="javascript:void(0);"> <i class="list-icon feather feather-user"></i><span
                        class="hide-menu">Students</span></a>
                <ul class="list-unstyled sub-menu">
                    <li><a href="<?php echo base_url('student/add');?>">Add</a>
                    </li>
                    <li><a href="<?php echo base_url('student');?>">List</a>
                    </li>
                    
                </ul>
            </li>
            
            <li class="menu-item-has-children">
                <a href="javascript:void(0);"> <i class="list-icon feather feather-user"></i><span
                        class="hide-menu">Student Groups</span></a>
                <ul class="list-unstyled sub-menu">
                    <li>
                        <a href="<?php echo base_url('Group');?>">Manage Groups</a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('Group/create')?>">Add Group</a>
                    </li>
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="javascript:void(0);"><i class="list-icon feather feather-message-square"></i> <span
                        class="hide-menu">Message Center</span></a>
                <ul class="list-unstyled sub-menu">
                    <li><a href="<?php echo base_url('message');?>">Manage Message </a>
                    </li>
                    <li><a href="#">Link 2</a>
                    </li>
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="javascript:void(0);"><i class="list-icon fa fa-bar-chart"></i> <span class="hide-menu">Reports</span></a>
                <ul class="list-unstyled sub-menu">
                    <li><a href="#">Link </a>
                    </li>
                    <li><a href="#">Link 2</a>
                    </li>
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="javascript:void(0);"><i class="list-icon fa fa-user"></i> <span class="hide-menu">Instructors</span></a>
                <ul class="list-unstyled sub-menu">
                    <li><a href="<?php echo base_url('instructor/add');?>">Add</a>
                    </li>
                    <li><a href="<?php echo base_url('instructor');?>">List instructor </a>
                    </li>
                    
                </ul>
            </li>

            <li class="">
                <a href="javascript:void(0);"><i class="list-icon fa fa-gear"></i> <span class="hide-menu">Settings</span></a>

            </li>

        </ul>
        <!-- /.side-menu -->
    </nav>
    <!-- /.sidebar-nav -->
</aside>
<!-- /.site-sidebar -->