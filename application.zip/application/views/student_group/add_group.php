<main class="main-wrapper clearfix">
    <!-- Page Title Area -->
    <form method="post" action="<?php echo base_url('student-groups/create');?>">
        <section class="">
            <div class="row page-title clearfix">
    
                <div class="page-title-left">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('students');?>">Students</a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('student-groups');?>">Manage Student Group</a>
                        </li>
    
                    </ol>
                </div>
            </div>
            <div class="row  clearfix">
                <div class="col-sm-4 col-md-6">
                    <h6 class="page-title-heading color-blue mr-0 mr-r-5">New Student Group</h6>
                </div>
                <div class="col-sm-8 col-md-6 text-right">
                    <button class="btn btn-rounded custom-btn whiteGrad ripple " data-toggle="modal"
                            data-target=".add-category-model">Discard
                    </button>
                    <button class="btn btn-rounded custom-btn BlueGrad ripple " data-toggle="modal"
                            data-target=".add-category-model">Save
                    </button>
    
                </div>
            </div>
        </section>
        <section class="content-section add-form">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l36" class="label">Group Title</label>
                                <input class="form-control" data-validation="name" value="<?php echo set_value('lname'); ?>" name="name" id="l36" placeholder="" type="text">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <label for="l36" class="label">Available Students</label>
                            <select id="pre-selected-options" class="form-control" name="student_id[]" data-toggle="multiselect" multiple="multiple">
                            <?php 
							foreach($allstudent as $student)
							{
							?>
                                <option value="<?php echo $student['id'];?>" /><?php echo $student['username'];?>
                             <?php
							  }
							  ?>
                                
                            </select>
                        </div>
    
                    </div>
    
                    <!-- /.list-group -->
                </div>
            </div>
    
    
        </section>
    </form>

</main>