<main class="main-wrapper clearfix">
    <!-- Page Title Area -->
    <section class="">
        <div class="row page-title clearfix">

            <div class="page-title-left">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="<?php echo base_url('students'); ?>">Students</a>
                    </li>

                </ol>
            </div>
        </div>
        <div class="row  clearfix">
            <div class="col-sm-4 col-md-6">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">Manage Student Groups</h6>
            </div>
            <div class="col-sm-8 col-md-6 text-right">
                <button class="btn btn-rounded custom-btn BlueGrad ripple" data-toggle="modal" data-target=".add-group-model">Add Group</button>

            </div>
        </div>
    </section>
    <section class="content-section">
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive">
                    <table class="table table-striped normal-table table-hover">
                        <thead>
                        <th colspan="2">S.No.</th>
                        <th class="text-center">
                            Group Title
                        </th>
                        <th class="text-center">
                            Status
                        </th>
                        <th class="text-center">
                            Last Visit
                        </th>
                        <th>
                            Action
                        </th>

                        </thead>
                        <tbody>
                        <?php 
						//print_r($arrStudent_group);
						if (isset($arrStudent_group)) { ?>
                            <?php foreach($arrStudent_group as $intKey=>$strValue):?>
                            <tr>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <label>
                                            <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                        </label></div>
                                </td>
                                <td>
                                    01
                                </td>
                                <td class="text-center"><?php echo $strValue['name'];?></td>
                                <td class="text-center"><?php if($strValue['status']==1){?> Active <?php } else{?>Not Active<?php } ?></td>
                                <td class="text-center"><?php echo $strValue['lastupdated_on'];?></td>
                                <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                    <a href="<?php echo base_url('Group/delete/'.$strValue['id']);?>" ><i class="fa fa-trash list-icon"></i></a>
                                    <a href="<?php echo base_url('Group/edit/'.$strValue['id']); ?>"><i class="fa fa-pencil list-icon"></i></a>
                                </td>
                            </tr>
                             <?php endforeach;?>    
                      <?php } ?>
                         
                        </tbody>
                    </table>
                     <?php if (isset($links)) { ?>
                <?php echo $links ?>
            <?php } ?>
                </div>
                <!-- /.list-group -->
            </div>
        </div>
    </section>


</main>
<!-- /.modal -->
<div class="modal modal-color-scheme fade add-group-model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header text-inverse">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i></button>
                <h5 class="modal-title" id="myLargeModalLabel">Add Group</h5>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form-group">
                        <input type="text" name="" class="form-control" placeholder="Title goes here">
                    </div>
                    <div class="text-right">
                        <button class="btn btn-rounded custom-btn BlueGrad ripple " >Add </button>
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->