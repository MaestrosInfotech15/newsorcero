<main class="main-wrapper clearfix">
    <!-- Page Title Area -->
    <form method="post" >
        <section class="">
            <div class="row page-title clearfix">
    
                <div class="page-title-left">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('students');?>">Students</a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('Group');?>">Manage Student Group</a>
                        </li>
    
                    </ol>
                </div>
            </div>
            <div class="row  clearfix">
                <div class="col-sm-4 col-md-6">
                
                    <h6 class="page-title-heading color-blue mr-0 mr-r-5">Edit Student Group</h6>
                </div>
                <div class="col-sm-8 col-md-6 text-right">
                    <button class="btn btn-rounded custom-btn whiteGrad ripple " data-toggle="modal"
                            data-target=".add-category-model">Discard
                    </button>
                    <button class="btn btn-rounded custom-btn BlueGrad ripple " data-toggle="modal"
                            data-target=".add-category-model">Save
                    </button>
    
                </div>
            </div>
        </section>
        <section class="content-section add-form">
            <div class="row">
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="l36" class="label">Group Title</label>
                                <input class="form-control" data-validation="name" value="<?php echo $group['name'];?>" name="name" id="l36" placeholder="" type="text">
                            </div>
                        </div>
                        <?php print_r($group['name']);?>
                        <div class="col-sm-12">
                            <label for="l36" class="label">Available Students</label>
                            <select id="pre-selected-options" class="form-control" name="student_id[]" data-toggle="multiselect" multiple="multiple">
                            <?php 
							foreach($allstudent as $student)
							{
								$jitu=explode(",",$group['members']);
								foreach($jitu as $selected)
								{
									if($student['id']==$selected)
									{
										$select="selected";
										
									}
								}
							?>
                                <option value="<?php echo $student['id'];?>" <?php echo $select ?> /><?php echo $student['username'];?>
                             <?php
							  }
							  ?>
                                
                            </select>
                        </div>
    
                    </div>
    
                    <!-- /.list-group -->
                </div>
            </div>
    
    
        </section>
    </form>

</main>