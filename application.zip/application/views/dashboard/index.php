<main class="main-wrapper clearfix">

    <!-- =================================== -->
    <!-- Different data widgets ============ -->
    <!-- =================================== -->
    <div class="widget-list">
        <div class="row">
            <div class="col-md-12 widget-holder">
                <div class="">
                    <div class="widget-body clearfix">
                        <h6 class="box-title page-title-heading color-blue mr-0 mr-r-5">COURSE ACTIVITY</h6>
                        <div style="height: 230px" class="mt50">
                            <canvas id="chartJsLineSingleGradient"></canvas>
                        </div>
                    </div>
                    <!-- /.widget-body -->
                </div>
                <!-- /.widget-bg -->
            </div>
        </div>
    </div>
    <section class="counter-section">
        <div class="widget-list">
            <div class="row">
                <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                    <div class="">
                        <div class=" text-center">
                            <div class="counter-custom">
                                New Students
                                <div class="counterBg green">
                                    <div class="counterFg">
                                        <i class="fa fa-graduation-cap"></i>
                                        <small>&nbsp;&nbsp;<?php echo $total_new_students;?></small>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
                <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                    <div class="">
                        <div class=" text-center">
                            <div class="counter-custom">
                                Total Students
                                <div class="counterBg red">
                                    <div class="counterFg">
                                        <i class="fa fa-graduation-cap"></i>
                                        <small>&nbsp;&nbsp;<?php echo $total_students;?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
                <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                    <div class="">
                        <div class=" text-center">
                            <div class="counter-custom">
                                course completed
                                <div class="counterBg green">
                                    <div class="counterFg">
                                        <i class="fa fa-check"></i>
                                        <small>&nbsp;&nbsp;2960</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
                <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                    <div class="">
                        <div class=" text-center">
                            <div class="counter-custom">
                                Total courses
                                <div class="counterBg red">
                                    <div class="counterFg">
                                        <i class="fa fa-book"></i>
                                        <small>&nbsp;&nbsp;2960</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
                <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                    <div class="">
                        <div class=" text-center">
                            <div class="counter-custom">
                                Active courses
                                <div class="counterBg green">
                                    <div class="counterFg">
                                        <i class="fa fa-book"></i>
                                        <small>&nbsp;&nbsp;2960</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
                <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                    <div class="">
                        <div class=" text-center">
                            <div class="counter-custom ">
                                users online
                                <div class="counterBg red">
                                    <div class="counterFg">
                                        <i class="fa fa-users"></i>
                                        <small>&nbsp;&nbsp;2960</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
            </div>
            <!-- /.row -->
        </div>
    </section>
    <section class="event-calendar-section">
        <div class="widget-list">
            <div class="row">
                <!-- Events List -->
                <div class="col-md-12 widget-holder widget-full-content border-all px-0">
                    <div class="widget-bg">
                        <div class="widget-body">
                            <div class="row no-gutters">
                                <!-- Calender Sidebar -->
                                <div class="col-md-3 custom-fullcalendar-sidebar pos-absolute pos-left d-none d-md-block">
                                    <div class="fullcalendar-events" data-toggle="fullcalendar-events"
                                         data-target="#fullcalendar-1">
                                        <div class="inbox-categories inbox-labels px-3">
                                            <h5 class="pl-3 mt-4">Month Planner</h5>
                                            <div class="fc-events">
                                                <div class="fc-event bg-persian-blue"><i
                                                        class="feather feather-check color-white bg-persian-blue"></i>
                                                    <span class="fc-event-text">Meetings</span>
                                                </div>
                                                <div class="fc-event bg-cerize-red"><i
                                                        class="feather feather-check color-white bg-cerize-red"></i>
                                                    <span class="fc-event-text">Callbacks</span>
                                                </div>
                                                <div class="fc-event bg-mustard"><i
                                                        class="feather feather-check color-white bg-mustard"></i><span
                                                        class="fc-event-text">Tasks Pending</span>
                                                </div>
                                                <div class="fc-event bg-gray-light"><i
                                                        class="feather feather-check color-white bg-gray-light"></i>
                                                    <span class="fc-event-text">Travel</span>
                                                </div>
                                            </div>
                                            <!-- /.fc-events -->
                                        </div>
                                        <div class="m-3 mr-t-40">
                                            <button class="btn btn-color-scheme btn-block btn-rounded btn-xl px-4 my-0 fs-16 ripple fc-add-event fw-500">
                                                <span>Add Event</span>
                                            </button>
                                        </div>
                                    </div>
                                    <!-- /.fullcalendar-events -->
                                </div>
                                <!-- /.col-md-3 -->
                                <!-- Calender App -->
                                <div class="col-12 mb-0">
                                    <div class="custom-fullcalendar fullcalendar" id="fullcalendar-1"
                                         data-toggle="fullcalendar"
                                         data-plugin-options='{ "events" : "assets/js/events-sample.json"}'></div>
                                    <!-- /.fullcalendar -->
                                </div>
                                <!-- /.col-md-9 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.widget-body -->
                    </div>
                    <!-- /.widget-bg -->
                </div>
                <!-- /.widget-holder -->
            </div>
            <!-- /.row -->
        </div>
    </section>
    <!-- /.widget-list -->
    <section class="assignment-section">
        <div class="row page-title clearfix">
            <div class="page-title-left">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">Latest Assignments</h6>
                <!-- <p class="page-title-description mr-0 d-none d-md-inline-block">statistics, charts and events</p> -->
            </div>
            <!-- /.page-title-left -->
            <div class="page-title-right d-inline-flex">
                <div class="col-lg-12 ">
                    <button class="btn btn-block btn-rounded btn-pink ripple v_all">VIEW ALL</button>
                </div>
            </div>
            <!-- /.page-title-right -->
        </div>

        <div class="assignment-cards eq-contain-card">
            <div class="row">
                <div class="col-xl-4  col-sm-6">
                    <div class="eq-card">
                        <div class="assignment-jumbotron mr-b-30 ">
                            <div class="course_title_jumb">
                                Microlearning Delivery
                            </div>
                            <div class="topic_title_jumb">
                                Advanced Strategic Planning Workshop
                            </div>
                            <div class="teacher_profile_pic">
                                <img src="assets/img/member2.png">
                            </div>
                            <div class="teacher_profile_name">
                                Victor J. Kessler
                            </div>
                            <footer class="mr-t-30"><a href="#" class="btn btn-outline-primary btn-rounded">Review</a>
                            </footer>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4  col-sm-6">
                    <div class="eq-card">
                        <div class="assignment-jumbotron mr-b-30 ">
                            <div class="course_title_jumb">
                                Microlearning Delivery
                            </div>
                            <div class="topic_title_jumb">
                                Advanced Strategic Planning Workshop
                            </div>
                            <div class="teacher_profile_pic">
                                <img src="assets/img/member2.png">
                            </div>
                            <div class="teacher_profile_name">
                                Victor J. Kessler
                            </div>
                            <footer class="mr-t-30"><a href="#" class="btn btn-outline-primary btn-rounded">Review</a>
                            </footer>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4  col-sm-6 ">
                    <div class="eq-card">
                        <div class="assignment-jumbotron mr-b-30 ">
                            <div class="course_title_jumb">
                                Team Engagement


                            </div>
                            <div class="topic_title_jumb">
                                Extended Leadership Winter Academy
                            </div>
                            <div class="teacher_profile_pic">
                                <img src="assets/img/member3.png">
                            </div>
                            <div class="teacher_profile_name">
                                James J. Cruz
                            </div>
                            <footer class="mr-t-30"><a href="#" class="btn btn-outline-primary btn-rounded">Review</a>
                            </footer>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="tabs-section">
        <div class="row">
            <div class="col-sm-12">
                <div class="tab_container">
                    <input id="tab1" class="tab-radio" type="radio" name="tabs" checked>
                    <label class="tabs-label" for="tab1"><span>Top performers</span></label>

                    <input id="tab2" class="tab-radio" type="radio" name="tabs">
                    <label class="tabs-label" for="tab2"><span>learners online</span></label>

                    <input id="tab3" class="tab-radio" type="radio" name="tabs">
                    <label class="tabs-label" for="tab3"><span>popular courses</span></label>

                    <input id="tab4" class="tab-radio" type="radio" name="tabs">
                    <label class="tabs-label" for="tab4"><span>inactive learners</span></label>

                    <input id="tab5" class="tab-radio" type="radio" name="tabs">
                    <label class="tabs-label" for="tab5"><span>fresh enrollments</span></label>

                    <section id="content1" class="tab-content">
                        <table class="table table-striped">
                            <thead>
                            <th>
                                Learners Name
                            </th>
                            <th class="text-center">
                                Points Earned
                            </th>
                            <th class="text-center">
                                Time Spent
                            </th>
                            <th class="text-center">
                                Current Level
                            </th>
                            <th>
                                Course Title
                            </th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Lucy D. Hauer
                                    </td>
                                    <td class="text-center">
                                        800 Points
                                    </td>
                                    <td class="text-center">
                                        2 hours
                                    </td>
                                    <td class="text-center">
                                        Level 8
                                    </td>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Blake J. Pointer
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member3.png">
                                        Blake J. Pointer
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member4.png">
                                        James J. Cruz
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member5.png">
                                        James J. Cruz
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member6.png">
                                        James J. Cruz
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </section>

                    <section id="content2" class="tab-content">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </section>

                    <section id="content3" class="tab-content">
                        <table class="table table-striped">
                            <thead>
                            <th>
                                Course Title
                            </th>
                            <th class="text-center">
                                Total Students Enrolled
                            </th>
                            <th class="text-center">
                                Time Spent
                            </th>
                            <th class="text-center">
                                Certified Learners
                            </th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        Extended Leadership Winter Academy
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Diploma of Leadership and Management
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Sustainable Leadership - Twenty Leadership Programme
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Advanced Strategic Planning Workshop
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Fundamentals of UX UI Design for Augmented Reality
                                    </td>
                                    <td class="text-center">
                                        150
                                    </td>
                                    <td class="text-center">
                                        3 hours
                                    </td>
                                    <td class="text-center">
                                        80
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </section>

                    <section id="content4" class="tab-content">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </section>

                    <section id="content5" class="tab-content">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                    <td>
                                        <img src="assets/img/member1.png">
                                        Blake J. Pointer
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                    <td>
                                        <img src="assets/img/member2.png">
                                        Victor J. Kessler
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </section>
                </div>
            </div>
        </div>
    </section>


</main>
<!-- /.main-wrappper -->