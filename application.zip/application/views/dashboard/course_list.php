<main class="main-wrapper clearfix">
<form  method="POST"  enctype="multipart/form-data">
    <!-- Page Title Area -->
    <section class="top-section">
        <div class="row  clearfix">
            <div class="col-sm-4 col-md-6">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">  Courses</h6>
            </div>
           
        </div>
    </section>
    <!-- /.page-title -->
    <!-- =================================== -->
    <!-- Form Section for Create New Courd ============ -->
    <!-- =================================== -->
    <section class="tabs-section createCourse">
        <div class="row">
            <div class="col-sm-12">

               
                              <section class="content-section">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="table-responsive">
                                                <table class="table table-striped normal-table table-hover">
                                                    <thead>
                                                    <th colspan="2">S.No.</th>
                                                    <th class="text-center">
                                                        Course Title
                                                    </th>
                                                    <th class="text-center">
                                                        Status
                                                    </th>
                                                    <th class="text-center">
                                                        Last Visit
                                                    </th>
                                                    <th>
                                                        Action
                                                    </th>
                            
                                                    </thead>
                                                    <tbody>
                                                    <?php 
                                                    //print_r($arrStudent_group);
                                                    if (isset($arrCourse)) { ?>
                                                        <?php foreach($arrCourse as $intKey=>$strValue):?>
                                                        <tr>
                                                            <td>
                                                                <div class="checkbox checkbox-primary">
                                                                    <label>
                                                                        <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                                                    </label></div>
                                                            </td>
                                                            <td>
                                                                01
                                                            </td>
                                                            <td class="text-center"><?php echo $strValue['name'];?></td>
                                                            <td class="text-center"><?php if($strValue['status']==1){?> Active <?php } else{?>Not Active<?php } ?></td>
                                                            <td class="text-center"><?php echo $strValue['lastupdated_on'];?></td>
                                                            <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                                                <a href="<?php echo base_url('Dashboard/delete/'.$strValue['id']);?>" ><i class="fa fa-trash list-icon"></i></a>
                                                                <a href="<?php echo base_url('Dashboard/edit/'.$strValue['id']); ?>"><i class="fa fa-pencil list-icon"></i></a>
                                                            </td>
                                                        </tr>
                                                         <?php endforeach;?>    
                                                  <?php } ?>
                                                     
                                                    </tbody>
                                                </table>
                                                 <?php if (isset($links)) { ?>
                                            <?php echo $links ?>
                                        <?php } ?>
                                            </div>
                                            <!-- /.list-group -->
                                        </div>
                                    </div>
                                </section>
                           
                    </div>
                    <!-- /.tab-content -->
                </div>
            </div>
        </div>
    </section>
  
    </form>
</main>