<main class="main-wrapper clearfix">
<form  method="POST"  enctype="multipart/form-data">
    <!-- Page Title Area -->
    <section class="top-section">
        <div class="row  clearfix">
            <div class="col-sm-4 col-md-6">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">Create New Course</h6>
            </div>
            <div class="col-sm-8 col-md-6 text-right">
                <input class="btn btn-rounded custom-btn whiteGrad ripple" type="submit" name="draft" value="Save as draft">
                <input class="btn btn-rounded custom-btn whiteGrad ripple" type="submit" name="publish" value="Publish">
                <input class="btn btn-rounded custom-btn BlueGrad ripple" type="submit" name="pending" value="Save">
            </div>
        </div>
    </section>
    <!-- /.page-title -->
    <!-- =================================== -->
    <!-- Form Section for Create New Courd ============ -->
    <!-- =================================== -->
    <section class="tabs-section createCourse">
        <div class="row">
            <div class="col-sm-12">

                <div class="tabs tabs-bordered tabs_create_course">
                    <ul class="nav nav-tabs nav-justified">
                        <li class="nav-item"><a class="nav-link active" href="#course-detail-tab"
                                                data-toggle="tab" aria-expanded="true">COURSE DETAILS</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="#course-user-tabs" data-toggle="tab"
                                                aria-expanded="true">USERS</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="#course-content-tab" data-toggle="tab"
                                                aria-expanded="true">COURSE CONTENT</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="#course-evaluation-tab" data-toggle="tab"
                                                aria-expanded="true">COURSE EVALUATION</a>
                        </li>
                    </ul>
                    <!-- /.nav-tabs -->
                    <div class="tab-content custom-tab-content ">
                        <div class="tab-pane active " id="course-detail-tab">
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-12">
                                    <?php  ?>
                                        
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="course_title" class="label">Course
                                                            Title</label>
                                                        <input type="text" class="form-control"
                                                               name="name" placeholder="Add title here" 
                                                               value="<?php echo !empty($edit_course['name'])?$edit_course['name']:''; ?>" 
                                                                required=""/>
                                                    </div>
                                                     <p> <?php echo form_error('name','<span class="help-block">','</span>'); ?></p>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="course_title" class="label">Title
                                                            Image</label>
                                                        <div class="">
                                                        
                                                            <label for="" class="">
                                                                <input type="radio" name="image"  id="showimage" value='none'>
                                                                &nbsp;&nbsp;No Image
                                                            </label>
                                                            <label for="" class="ml-5">
                                                                <input type="radio" name="image" id="showimage" value="block" checked="checked">
                                                                &nbsp;&nbsp;Select Image
                                                            </label>
                                                            <label class="ml-5  width-50 pr" id="filesn">
                                                                <input type="file" class="filestyle"
                                                                       data-icon="false" name="userfile[]">
                                                                <span class="pa-l-0 c_grey">Should be 400 x 400 pixels</span>
                                                            </label>
                                                            <!--<label class="ml-2 tag"><span>Course-title.jpg</span>
                                                                <a><i class="fa fa-trash"></i></a></label>-->
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="course_title" class="label">Assign
                                                            Categories  </label>
                                                        <fieldset class="width-50">
                                                            <div class="form-group searchIco">
                                                         
                                                                <select class="selectpicker form-control" multiple="multiple" 
                                                                name="category[]">
                                                                    
                                                                
                                                                     <?php 
																	 foreach($category as $cat)
																	 {
																		 echo "<option value='".$cat['id']."' />";
																		 echo $cat['name'];
																		
																	 }
																	  ?>
                                                                </select>
                                                            </div>
                                                        </fieldset>
                                                       <!-- <ul class="tagsArea">
                                                            <li class="tag"><a><i class="fa fa-trash"></i></a>
                                                                <span>Physics</span></li>
                                                        </ul>-->
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="course_title" class="label">Course
                                                            Availability</label>
                                                        <div class="">
                                                            <label for="" class="">
                                                                <input type="radio" name="status" value="0">
                                                                &nbsp;&nbsp;Not available
                                                            </label>
                                                            <label for="" class="ml-5">
                                                                <input type="radio" name="status" value="1">
                                                                &nbsp;&nbsp;Available now
                                                            </label>
                                                            <label for="" class="ml-5">
                                                                <input type="radio" name="status" value="0">
                                                                &nbsp;&nbsp;Publish on
                                                            </label>
                                                            <label for="" class="ml-4">
                                                                <div class="input-group">
                                                                    <input type="text"
                                                                           class="form-control datepicker"
                                                                           value="06/13/2017" name="date_from_available"/> <span
                                                                           class="input-group-addon"><i
                                                                            class="list-icon material-icons">date_range</i></span>
                                                                </div>
                                                            </label>
                                                            <label for="" class="ml-4">
                                                                <div class="input-group clockpicker">
                                                                    <input type="text" class="form-control"
                                                                           data-masked-input="99:99"
                                                                           id="sampleClockPicker1" name="time_from_available"/> <span
                                                                           class="input-group-addon"><span
                                                                            class="material-icons list-icon">watch_later</span></span>
                                                                </div>
                                                            </label>
                                                        </div>
                                                        <div class="">
                                                            <label>After Course Completoin</label>
                                                            <div class="ml-5 width-20 selectBox">
                                                                <select id="total_levels"
                                                                        class="form-control selectpicker">
                                                                    <option/>
                                                                    Mustard
                                                                    <option/>
                                                                    Ketchup
                                                                    <option/>
                                                                    Relish
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="total_levels" class="label">Total
                                                            Levels</label>
                                                        <div>
                                                            <div class="selectBox width-50">
                                                                <select id="total_levels"
                                                                        class="form-control selectpicker" name="total_level">
                                                                    <?php for($i=1;$i<100;$i++){?>
                                                                    <option><?php echo $i;  ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="price" class="label">Price</label>
                                                        <div class="">
                                                            <label for="free-for-everyone" class="">
                                                                <input type="radio" name="price" value="free">
                                                                &nbsp;&nbsp;Free for everyone
                                                            </label>
                                                            <label for="free-for-everyone" class="ml-5">
                                                                <input type="radio" name="price" value="free_for_pro">
                                                                &nbsp;&nbsp;Free for pro users only
                                                            </label>
                                                            <label for="free-for-everyone" class="ml-5">
                                                                <input type="radio" name="price" value="paid">
                                                                &nbsp;&nbsp;Price for everyone
                                                            </label>
                                                            <label for="" class="ml-5">
                                                                <div class="input-group">
                                                                    <input type="text" placeholder="$"
                                                                           class="form-control" name="price_value"/>
                                                                </div>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane " id="course-user-tabs">
                            
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="borderBox">
                                            <h4>All Users Group</h4>
                                            <fieldset>
                                                <div class="form-group searchIco">
                                                    <select class="selectpicker form-control"
                                                            multiple="multiple" name="usergroup[]" id="usergroup" >
                                                            <?php foreach($student_group as $group)
															
															{
															?>
                                                        <option value="<?php echo $group['id'];?>" /><?php echo $group['name'];?>
                                                        <?php } ?>
                                                      
                                                   </select>
                                                </div>
                                            </fieldset>
                                            <ul class="actionRow">
                                                <li><a href="javascript:;" class="pd_left0">Select All</a><a
                                                        href="javascript:;">Clear All</a></li>
                                                <li class="text-right"><a href="javascript:;" class="redLink">Delete
                                                        All</a><a href="javascript:;" class="redLink pd_right0">Delete
                                                        All</a></li>
                                            </ul>
                                            <ul class="tagsArea" id="grouptag">
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="borderBox">
                                            <h4>All Users</h4>
                                            <fieldset>
                                                <div class="form-group searchIco">
                                                <?php //print_r($users); ?>
                                                    <select class="selectpicker form-control"
                                                            multiple="multiple" id="alluser" name="alluser[]">
                                                       <?php 
													   foreach($users as $user)
													   {
														   echo '<option value="'.$user['id'].'" />';
														   echo $user['username'];
														  
														}
													   ?>
                                                    </select>
                                                </div>
                                            </fieldset>
                                            <ul class="actionRow">
                                                <li><a href="javascript:;" class="pd_left0">Select All</a><a
                                                        href="javascript:;">Clear All</a></li>
                                                <li class="text-right"><a href="javascript:;" class="redLink">Delete
                                                        All</a><a href="javascript:;" class="redLink pd_right0">Delete
                                                        All</a></li>
                                            </ul>
                                            <ul class="tagsArea" id="usertag">
                                               
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                           
                        </div>
                        <div class="tab-pane " id="course-content-tab">
                            <div class="row">
                                <div class="col-sm-12">
                                    <h5 class="mb-2">Drag any icon or double click to add a slide</h5>


                                    <div class="wrapper-slide-roll ">
                                        <div class="block-grid-xs-2 block-grid-sm-3 block-grid-md-5 block-grid-lg-10 block-grid">
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-square-o"></i>Empty Slide</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-edit"></i>Text</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-film"></i>Video</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-headphones"></i>Audio</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-link"></i>URL</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-file"></i>File</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-wpforms"></i>Form</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-download"></i>Assignment</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-code"></i>Embed</a>
                                            </div>
                                            <div>
                                                <a href="#text" data-toggle="tab"><i
                                                        class="fa fa-copy"></i>Existing Slide</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 mt-5">
                                <!-- Tab panes -->
                               
                                    <div class="accordion custom" id="text-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">02</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">Text Slides</a></li>

                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#text-slide-accordian"
                                                               href="#text-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>--><style>.mce-notification-inner {
    display: none;
}</style>
                                                
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="text-slide" class="card-collapse collapse show"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="">
                                               
  
                                                    <textarea data-toggle="wysiwyg" id="editor" name="description"></textarea>
                                                    <div class="strip text-center mt-5 mb-2">
                                                        <ul class="list-inline">
                                                            <li class="">Complete this slide with</li>
                                                            <li class=""><input type="radio" name="button_type" value="next">&nbsp;&nbsp;Next
                                                                button
                                                            </li>
                                                            <li class=""><input type="radio" name="button_type" value="Ask questions">&nbsp;&nbsp;Ask
                                                                questions
                                                            </li>
                                                            <li class=""><input type="radio" name="button_type" value="End Course" >&nbsp;&nbsp;End
                                                                Course
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    
                                                    <style>.q {
    font-size: 16px !important;
}</style>
                                                    <div class="strip text-center mt-5 mb-2">
                                                        <ul class="list-inline" >
                                                        <li> Question . 1</li>
                                                            <li class="">&nbsp&nbsp&nbspSelect Question Type</li>
                                                            
                                                           </ul>
                                                           <ul class="list-inline" >
                                                          <li class="q" style="background: aliceblue;
    color: #9f9999;
    font-size: 16px;"><input data-value="" type="radio" name="Question_type" 
                                                            value="Open Ended Question">&nbsp
                                                               Open Ended Question
                                                            </li>
                                                            <li class="q"><input data-value="" type="radio" name="Question_type" 
                                                            value="Single Choice Question">&nbsp
                                                               Single Choice Question
                                                            </li>
                                                            <li class="q"><input type="radio" data-value="" name="Question_type" 
                                                            value="Multiple Choice Question" >&nbsp
                                                                Multiple Choice Question
                                                            </li>
                                                            <li class="q"><input type="radio" data-value="" name="Question_type" 
                                                            value="Question with File  Upload" >&nbsp
                                                               Question with File Upload
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div id="question1">
                                                    	<div class="accordion custom p-2"
                                                         id="open-ended-question-accordian" role="tablist"
                                                         aria-multiselectable="true">
                                                        <div class="card card-outline-lms-blue light">
                                                            <div class="card-header" role="tab" id="heading4">
                                                                <div class="panel-left" >
                                                                    <ul class="list-inline">
                                                                        <li><a class=""><i
                                                                                    class="fa fa-bars"></i></a></li>
                                                                        <li><a class="">|</a></li>
                                                                        <li><a class="">01</a></li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a href="">Open Ended Question</a>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                                <div class="panel-right" style="float: right">
                                                                    <ul class="list-inline">

                                                                        <li><a class=""><i
                                                                                    class="fa fa-copy"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-ban"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-trash"></i></a>
                                                                        </li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a role="button" class="chevron"
                                                                               data-toggle="collapse"
                                                                               data-parent="#open-ended-question-accordian"
                                                                               href="#open-ended-question"
                                                                               aria-expanded="true"
                                                                               aria-controls="open-ended-question"></a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                                            </div>
                                                            <!-- /.card-header -->
                                                            <div id="open-ended-question"
                                                                 class="card-collapse collapse show"
                                                                 role="tabpanel" aria-labelledby="heading4">
                                                                <div class="card-body">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="question"
                                                                                   class="label">Question</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="question"/>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="answer-type"
                                                                                   class="label">Answer
                                                                                Type</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Open Ended">
                                                                                    &nbsp;&nbsp;Open Ended
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Single Choice">
                                                                                    &nbsp;&nbsp;Single Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Multiple Choice">
                                                                                    &nbsp;&nbsp;Multiple Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Upload File">
                                                                                    &nbsp;&nbsp;Upload File
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="question-check"
                                                                                   class="label">Question
                                                                                Check</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer_check" value="Auto check">
                                                                                    &nbsp;&nbsp;Auto check
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_check" value="Check Later">
                                                                                    &nbsp;&nbsp;Check Later
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="correct-answer"
                                                                                   class="label">Correct
                                                                                Answer</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="correct_answer"
                                                                                   placeholder="Type your question here"/>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Marks</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="marks" value="1">
                                                                                    &nbsp;&nbsp;No Marks
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="marks" value="0">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type_marks">
                                                                                </label>

                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Correct
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="correct_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="currect_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="Yay! your answer is right!"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="currect_message"
                                                                                           value="value2"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="currect_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Wrong
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="wrong_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="wrong_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="We are sorry, your answer is wrong"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="wrong_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="wrong_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for=""
                                                                                   class="label">Time
                                                                                Limit</label>
                                                                            <div>
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="limit_time" value="none">
                                                                                    &nbsp;&nbsp;None
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="limit_time" value="block">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="limit_time_value" id="time">
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <select>
                                                                                        <option>Seconds</option>
                                                                                        <option></option>
                                                                                        <option></option>
                                                                                    </select>
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <!-- /.card-body -->
                                                        </div>
                                                        <!-- /.card-collapse -->
                                                    </div>
                                                    </div>
                                                    <div id="question2" style="display:none;">
                                                    	<div class="accordion custom p-2"
                                                         id="single-choice-question-accordian" role="tablist"
                                                         aria-multiselectable="true"  >
                                                        <div class="card card-outline-lms-blue light  ">
                                                            <div class="card-header" role="tab" id="heading4">
                                                                <div class="panel-left">
                                                                    <ul class="list-inline">
                                                                        <li><a class=""><i
                                                                                    class="fa fa-bars"></i></a></li>
                                                                        <li><a class="">|</a></li>
                                                                        <li><a class="">02</a></li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a href="">Single Choice
                                                                                Question</a>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                                <div class="panel-right" style="float: right">
                                                                    <ul class="list-inline">

                                                                        <li><a class=""><i
                                                                                    class="fa fa-copy"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-ban"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-trash"></i></a>
                                                                        </li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a role="button" class="chevron"
                                                                               data-toggle="collapse"
                                                                               data-parent="#single-choice-question-accordian"
                                                                               href="#single-choice-question"
                                                                               aria-expanded="true"
                                                                               aria-controls="single-choice-question"></a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                                            </div>
                                                            <!-- /.card-header -->
                                                            <div id="single-choice-question"
                                                                 class="card-collapse collapse show"
                                                                 role="tabpanel" aria-labelledby="heading4">
                                                                <div class="card-body">
                                                                    <div class="col-sm-12">

                                                                        <div class="form-group">
                                                                            <label for="question"
                                                                                   class="label">Question</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="question"/>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="answer-type"
                                                                                   class="label">Answer
                                                                                Type</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Open Ended">
                                                                                    &nbsp;&nbsp;Open Ended
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Single Choice">
                                                                                    &nbsp;&nbsp;Single Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Multiple Choice">
                                                                                    &nbsp;&nbsp;Multiple Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_type" value="Upload File">
                                                                                    &nbsp;&nbsp;Upload File
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="question-check"
                                                                                   class="label">Question Check
                                                                                Check</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer_check" value="1">
                                                                                    &nbsp;&nbsp;Auto check
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer_check" value="0">
                                                                                    &nbsp;&nbsp;Check Later
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="correct-answer"
                                                                                   class="label">Possible
                                                                                Answers</label>
                                                                            <div class="radio inline-radio">
                                                                                <a href="">
                                                                                    <i class="fa fa-trash"></i>
                                                                                </a>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="anwser_value1"
                                                                                       type="text" value=""
                                                                                       placeholder="Type your question here"/>
                                                                                <span style="line-height:34px"><input
                                                                                        type="radio" name="correct_anwser" value="a">&nbsp;&nbsp;Set as a correct answer</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <a href="">
                                                                                    <i class="fa fa-trash"></i>
                                                                                </a>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="anwser_value2"
                                                                                       type="text" value=""
                                                                                       placeholder="Type your question here"/>
                                                                                <span style="line-height:34px"><input
                                                                                        type="radio" name="correct_anwser" value="b">&nbsp;&nbsp;Set as a correct answer</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <a href="">
                                                                                    <i class="fa fa-plus"></i>
                                                                                </a>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="anwser_value3"
                                                                                       type="text" value=""
                                                                                       placeholder="Type your question here"/>
                                                                                <span style="line-height:34px"><input
                                                                                        type="radio" name="correct_anwser" value="c">&nbsp;&nbsp;Set as a correct answer</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <a href="">
                                                                                    <i class="fa fa-plus"></i>
                                                                                </a>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="anwser_value4"
                                                                                       type="text" value=""
                                                                                       placeholder="Type your question here"/>
                                                                                <span style="line-height:34px"><input
                                                                                        type="radio" name="correct_anwser" value="d">&nbsp;&nbsp;Set as a correct answer</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Marks</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="marks" value="1">
                                                                                    &nbsp;&nbsp;No Marks
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="marks" value="0">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type_marks">
                                                                                </label>

                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Correct
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="correct_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="correct_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="Yay! your answer is right!"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="correct_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="correct_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Wrong
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="wrong_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="wrong_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="We are sorry, your answer is wrong"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="wrong_message"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="wrong_message_value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for=""
                                                                                   class="label">Time
                                                                                Limit</label>
                                                                            <div>
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="time_limit" value="none">
                                                                                    &nbsp;&nbsp;None
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="time_limit_value" value="block">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type_marks" id="marks">
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <select>
                                                                                        <option>Seconds</option>
                                                                                        <option></option>
                                                                                        <option></option>
                                                                                    </select>
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>

                                                            <!-- /.card-body -->
                                                        </div>
                                                        <!-- /.card-collapse -->
                                                    </div>
                                                    </div>
                                                    <div id="question3" style="display:none;">
                                                    	<div class="accordion custom p-2"
                                                         id="multiple-choice-question-accordian" role="tablist"
                                                         aria-multiselectable="true" >
                                                        <div class="card card-outline-lms-blue light  ">
                                                            <div class="card-header" role="tab" id="heading4">
                                                                <div class="panel-left">
                                                                    <ul class="list-inline">
                                                                        <li><a class=""><i
                                                                                    class="fa fa-bars"></i></a></li>
                                                                        <li><a class="">|</a></li>
                                                                        <li><a class="">03</a></li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a href="">Multiple Choice
                                                                                Question</a>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                                <div class="panel-right" style="float: right">
                                                                    <ul class="list-inline">

                                                                        <li><a class=""><i
                                                                                    class="fa fa-copy"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-ban"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-trash"></i></a>
                                                                        </li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a role="button" class="chevron"
                                                                               data-toggle="collapse"
                                                                               data-parent="#multiple-choice-question-accordian"
                                                                               href="#multiple-choice-question"
                                                                               aria-expanded="true"
                                                                               aria-controls="multiple-choice-question"></a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                                            </div>
                                                            <!-- /.card-header -->
                                                            <div id="multiple-choice-question"
                                                                 class="card-collapse collapse show"
                                                                 role="tabpanel" aria-labelledby="heading4">
                                                                <div class="card-body">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="question"
                                                                                   class="label">Question</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="question"/>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="answer-type"
                                                                                   class="label">Answer
                                                                                Type</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Open Ended
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Single Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Multiple Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Upload File
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="question-check"
                                                                                   class="label">Question
                                                                                Check</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Auto check
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Check Later
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="correct-answer"
                                                                                   class="label">Correct
                                                                                Answer</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="correct-answer"
                                                                                   placeholder="Type your question here"/>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Marks</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="marks">
                                                                                    &nbsp;&nbsp;No Marks
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="marks">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type marks">
                                                                                </label>

                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Correct
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="Yay! your answer is right!"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Wrong
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="We are sorry, your answer is wrong"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for=""
                                                                                   class="label">Time
                                                                                Limit</label>
                                                                            <div>
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="marks1" value="none">
                                                                                    &nbsp;&nbsp;None
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="marks1" value="block">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type_marks" id="marks1">
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <select>
                                                                                        <option>Seconds</option>
                                                                                        <option></option>
                                                                                        <option></option>
                                                                                    </select>
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>

                                                            <!-- /.card-body -->
                                                        </div>
                                                        <!-- /.card-collapse -->
                                                    </div>
                                                    </div>
                                                    <div id="question4" style="display:none;">
                                                    	<div class="accordion custom p-2"
                                                         id="file-upload-question-accordian" role="tablist"
                                                         aria-multiselectable="true"  >
                                                        <div class="card card-outline-lms-blue light  ">
                                                            <div class="card-header" role="tab" id="heading4">
                                                                <div class="panel-left">
                                                                    <ul class="list-inline">
                                                                        <li><a class=""><i
                                                                                    class="fa fa-bars"></i></a></li>
                                                                        <li><a class="">|</a></li>
                                                                        <li><a class="">04</a></li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a href="">Question with File
                                                                                Upload</a>
                                                                        </li>

                                                                    </ul>
                                                                </div>
                                                                <div class="panel-right" style="float: right">
                                                                    <ul class="list-inline">

                                                                        <li><a class=""><i
                                                                                    class="fa fa-copy"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-ban"></i></a></li>
                                                                        <li><a class=""><i
                                                                                    class="fa fa-trash"></i></a>
                                                                        </li>
                                                                        <li><a href="">|</a></li>
                                                                        <li><a role="button" class="chevron"
                                                                               data-toggle="collapse"
                                                                               data-parent="#file-upload-question-accordian"
                                                                               href="#file-upload-question"
                                                                               aria-expanded="true"
                                                                               aria-controls="file-upload-question"></a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                                            </div>
                                                            <!-- /.card-header -->
                                                            <div id="file-upload-question"
                                                                 class="card-collapse collapse show"
                                                                 role="tabpanel" aria-labelledby="heading4">
                                                                <div class="card-body">
                                                                    <div class="col-sm-12">
                                                                        <div class="form-group">
                                                                            <label for="question"
                                                                                   class="label">Question</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="question"/>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="answer-type"
                                                                                   class="label">Answer
                                                                                Type</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Open Ended
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Single Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Multiple Choice
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Upload File
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="question-check"
                                                                                   class="label">Question
                                                                                Check</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Auto check
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="answer-type">
                                                                                    &nbsp;&nbsp;Check Later
                                                                                </label>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="correct-answer"
                                                                                   class="label">Correct
                                                                                Answer</label>
                                                                            <input type="text"
                                                                                   class="form-control"
                                                                                   name="correct-answer"
                                                                                   placeholder="Type your question here"/>
                                                                        </div>
                                                                        <!--file-->
                                                                        <div class="form-group">
                                                                            <label for="question-check"
                                                                                   class="label">Upload File
                                                                                Types</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="checkbox"
                                                                                           name="file-type-pdf">
                                                                                    &nbsp;&nbsp;PDF
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="checkbox"
                                                                                           name="file-type-office">
                                                                                    &nbsp;&nbsp;All Office
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="checkbox"
                                                                                           name="file-type-media">
                                                                                    &nbsp;&nbsp;All media
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="checkbox"
                                                                                           name="file-type-zip">
                                                                                    &nbsp;&nbsp;Zip
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="checkbox"
                                                                                           name="file-type-any">
                                                                                    &nbsp;&nbsp;Any Type
                                                                                </label>
                                                                            </div>
                                                                        </div>


                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Marks</label>
                                                                            <div class="">
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="marks">
                                                                                    &nbsp;&nbsp;No Marks
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="marks">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type marks">
                                                                                </label>

                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Correct
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="Yay! your answer is right!"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="marks"
                                                                                   class="label">Message on
                                                                                Wrong
                                                                                answer</label>
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="We are sorry, your answer is wrong"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <div class="radio inline-radio">
                                                                                <label>
                                                                                    <input type="radio"
                                                                                           id="radio-value"
                                                                                           name="value"
                                                                                           value="value1"/>
                                                                                </label>
                                                                                <input id="result-value"
                                                                                       class="form-control"
                                                                                       name="value"
                                                                                       type="text" value=""
                                                                                       placeholder="Custom Message"/>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for=""
                                                                                   class="label">Time
                                                                                Limit</label>
                                                                            <div>
                                                                                <label for="free-for-everyone"
                                                                                       class="">
                                                                                    <input type="radio"
                                                                                           name="marks2" value="none">
                                                                                    &nbsp;&nbsp;None
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="radio"
                                                                                           name="marks2" value="block">
                                                                                    &nbsp;&nbsp;Enter
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <input type="text"
                                                                                           name="type_marks" id="marks2">
                                                                                </label>
                                                                                <label for="free-for-everyone"
                                                                                       class="ml-5">
                                                                                    <select>
                                                                                        <option>Seconds</option>
                                                                                        <option></option>
                                                                                        <option></option>
                                                                                    </select>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- /.card-body -->
                                                        </div>
                                                        <!-- /.card-collapse -->
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.card-body -->
                                        </div>
                                        <!-- /.card-collapse -->
                                    </div>
                                    <!--video section-->
                                    <div class="accordion custom" id="video-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">03</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">Video</a></li>

                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">

                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#video-slide-accordian"
                                                               href="#video-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="video-slide" class="card-collapse collapse show"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="tab_container tabs_create_course text-center m-5 ">

                                                    <ul class="nav nav-tabs nav-justified">
                                                        <li class="nav-item"></li>
                                                        <li class="nav-item active"><a class="nav-link"
                                                                                       href="#embed-code-tab-"
                                                                                       data-toggle="tab"
                                                                                       aria-expanded="true">EMBED
                                                                CODE</a>
                                                        </li>
                                                        <li class="nav-item"><a class="nav-link"
                                                                                href="#upload-tab-"
                                                                                data-toggle="tab"
                                                                                aria-expanded="true">UPLOAD</a>
                                                        </li>
                                                        <li class="nav-item"></li>
                                                    </ul>
                                                    <!-- /.nav-tabs -->
                                                    <div class="tab-content custom-tab-content">
                                                        <div class="tab-pane active" id="embed-code-tab-">
                                                            
                                                                <div class="col-sm-12">
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control"
                                                                               name="embed-code"
                                                                               placeholder="Paste embed code here"/>
                                                                    </div>
                                                                </div>
                                                                <div class="strip text-center mt-5 mb-2">
                                                                    <ul class="list-inline">
                                                                        <li class="">Complete this slide with
                                                                        </li>
                                                                        <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                            button
                                                                        </li>
                                                                        <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                            questions
                                                                        </li>
                                                                        <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                            Course
                                                                        </li>
                                                                    </ul>
                                                                </div>

                                                            
                                                        </div>
                                                        <div class="tab-pane" id="upload-tab-">
                                                            <div class="form-group">
                                                                <label class="ml-5  width-50 pr">
                                                                    <input type="file" class="filestyle"
                                                                           data-icon="false">

                                                                </label>

                                                            </div>
                                                            <div class="form-group">
                                                                <img src="<?php echo base_url();?>assets/img/image3.png"><br>
                                                                <a href=""><i class="fa fa-trash"></i></a>video.mp4
                                                            </div>
                                                            <div class="strip text-center mt-5 mb-2">
                                                                <ul class="list-inline">
                                                                    <li class="">Complete this slide with</li>
                                                                    <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                        button
                                                                    </li>
                                                                    <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                        questions
                                                                    </li>
                                                                    <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                        Course
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- /.tab-content -->

                                                </div>


                                            </div>

                                        </div>
                                    </div>
                                    <!--Audio section-->
                                    <div class="accordion custom" id="audio-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">04</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">Audio</a></li>

                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">

                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#audio-slide-accordian"
                                                               href="#audio-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="audio-slide" class="card-collapse collapse show"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="tab_container tabs_create_course m-5  ">

                                                    <ul class="nav nav-tabs nav-justified">
                                                        <li class="nav-item"></li>
                                                        <li class="nav-item active"><a class="nav-link"
                                                                                       href="#embed-code-tab--"
                                                                                       data-toggle="tab"
                                                                                       aria-expanded="true">EMBED
                                                                CODE</a>
                                                        </li>
                                                        <li class="nav-item"><a class="nav-link"
                                                                                href="#upload-tab--"
                                                                                data-toggle="tab"
                                                                                aria-expanded="true">UPLOAD</a>
                                                        </li>
                                                        <li class="nav-item"></li>
                                                    </ul>
                                                    <!-- /.nav-tabs -->
                                                    <div class="tab-content custom-tab-content text-center">
                                                        <div class="tab-pane active" id="embed-code-tab--">
                                                           
                                                                <div class="col-sm-12">
                                                                    <div class="form-group">
                                                                        <input type="text" class="form-control"
                                                                               name="embed-code"
                                                                               placeholder="Paste embed code here"/>
                                                                    </div>
                                                                </div>
                                                                <div class="strip text-center mt-5 mb-2">
                                                                    <ul class="list-inline">
                                                                        <li class="">Complete this slide with
                                                                        </li>
                                                                        <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                            button
                                                                        </li>
                                                                        <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                            questions
                                                                        </li>
                                                                        <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                            Course
                                                                        </li>
                                                                    </ul>
                                                                </div>

                                                           
                                                        </div>
                                                        <div class="tab-pane" id="upload-tab--">
                                                            <div class="form-group">
                                                                <label class="ml-5  width-50 pr">
                                                                    <input type="file" class="filestyle"
                                                                           data-icon="false">

                                                                </label>

                                                            </div>
                                                            <div class="form-group">
                                                                <a href=""><i class="fa fa-trash"></i></a>audio.mp3
                                                            </div>
                                                            <div class="strip text-center mt-5 mb-2">
                                                                <ul class="list-inline">
                                                                    <li class="">Complete this slide with</li>
                                                                    <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                        button
                                                                    </li>
                                                                    <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                        questions
                                                                    </li>
                                                                    <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                        Course
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- /.tab-content -->

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <!--URL section-->
                                    <div class="accordion custom" id="url-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">06</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">URL</a></li>

                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">

                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#url-slide-accordian"
                                                               href="#url-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="url-slide" class="card-collapse collapse show"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="m-5 text-center">
                                                   
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control"
                                                                       name="embed-code"
                                                                       placeholder="Type or paste URL here"/>
                                                            </div>
                                                        </div>
                                                        <div class="strip text-center mt-5 mb-2">
                                                            <ul class="list-inline">
                                                                <li class="">Complete this slide with</li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                    button
                                                                </li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                    questions
                                                                </li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                    Course
                                                                </li>
                                                            </ul>
                                                        </div>

                                                    
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <!--File section-->
                                    <div class="accordion custom" id="file-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">05</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">File</a></li>

                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">

                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#file-slide-accordian"
                                                               href="#file-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="file-slide" class="card-collapse collapse show"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="m-5 text-center">
                                                  
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control"
                                                                       name="embed-code"
                                                                       placeholder="Paste embed code here"/>
                                                            </div>
                                                        </div>
                                                        <div class="strip text-center mt-5 mb-2">
                                                            <ul class="list-inline">
                                                                <li class="">Complete this slide with</li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                    button
                                                                </li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                    questions
                                                                </li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                    Course
                                                                </li>
                                                            </ul>
                                                        </div>

                                                   
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <!--Embed section-->
                                    <div class="accordion custom" id="embed-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">09</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">Embed</a></li>

                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">

                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#embed-slide-accordian"
                                                               href="#embed-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="embed-slide" class="card-collapse collapse show"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="m-5 text-center">
                                                   
                                                        <div class="col-sm-12">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control"
                                                                       name="embed-code"
                                                                       placeholder='<iframe width="1903" height="764" src="https://www.youtube.com/embed/BWIenEwKrmY?list=PL334FsZuGYwo7whkjTe6J9lx6r09kX7X3" frameborder="0" allow="autoplay; encrypt'/>
                                                            </div>
                                                        </div>
                                                        <div class="strip text-center mt-5 mb-2">
                                                            <ul class="list-inline">
                                                                <li class="">Complete this slide with</li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;Next
                                                                    button
                                                                </li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;Ask
                                                                    questions
                                                                </li>
                                                                <li class=""><input type="radio">&nbsp;&nbsp;End
                                                                    Course
                                                                </li>
                                                            </ul>
                                                        </div>

                                                   
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <!--Existing Slide section-->
                                    <div class="accordion custom" id="existing-slide-accordian" role="tablist"
                                         aria-multiselectable="true">
                                        <div class="card card-outline-lms-blue  ">
                                            <div class="card-header" role="tab" id="heading4">
                                                <div class="panel-left">
                                                    <ul class="list-inline">
                                                        <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                        <li><a class="">|</a></li>
                                                        <li><a class="">10</a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a href="">Existing Block</a></li>
                                                    </ul>
                                                </div>
                                                <div class="panel-right" style="float: right">
                                                    <ul class="list-inline">

                                                        <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                        <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                        <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                        <li><a href="">|</a></li>
                                                        <li><a role="button" class="chevron"
                                                               data-toggle="collapse"
                                                               data-parent="#existing-slide-accordian"
                                                               href="#existing-slide" aria-expanded="true"
                                                               aria-controls="text-slide"></a></li>
                                                    </ul>
                                                </div>
                                                <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                            </div>
                                            <!-- /.card-header -->
                                            <div id="existing-slide"
                                                 class="card-collapse collapse show text-left"
                                                 role="tabpanel" aria-labelledby="heading4">
                                                <div class="m-5 text-center">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <fieldset>
                                                                <div class="form-group searchIco no-ico">
                                                                    <select class="selectpicker form-control"
                                                                            multiple="multiple">
                                                                        <option selected="selected"/>
                                                                        Mustard
                                                                        <option/>
                                                                        Ketchup
                                                                        <option/>
                                                                        Relish
                                                                    </select>
                                                                </div>
                                                            </fieldset>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <fieldset>
                                                                <div class="form-group searchIco no-ico">
                                                                    <select class="selectpicker form-control"
                                                                            multiple="multiple">
                                                                        <option selected="selected"/>
                                                                        Mustard
                                                                        <option/>
                                                                        Ketchup
                                                                        <option/>
                                                                        Relish
                                                                    </select>
                                                                </div>
                                                            </fieldset>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                        <div class="tab-pane" id="course-evaluation-tab">
                            <div class="accordion custom" id="text-slide-accordian1" role="tablist"
                                 aria-multiselectable="true">
                                <div class="card card-outline-lms-blue  ">
                                    <div class="card-header" role="tab" id="heading4">
                                        <div class="panel-left">
                                            <ul class="list-inline">
                                                <li><a class=""><i class="fa fa-bars"></i></a></li>
                                                <li><a class="">|</a></li>
                                                <li><a class="">02</a></li>
                                                <li><a href="">|</a></li>
                                                <li><a href="">Text Slides</a></li>
                                            </ul>
                                        </div>
                                        <div class="panel-right" style="float: right">
                                            <ul class="list-inline">
                                                <li><a class=""><i class="fa fa-copy"></i></a></li>
                                                <li><a class=""><i class="fa fa-ban"></i></a></li>
                                                <li><a class=""><i class="fa fa-trash"></i></a></li>
                                                <li><a href="">|</a></li>
                                                <li><a role="button" class="chevron"
                                                       data-toggle="collapse"
                                                       data-parent="#text-slide-accordian1"
                                                       href="#text-slide1" aria-expanded="true"
                                                       aria-controls="text-slide"></a></li>
                                            </ul>
                                        </div>
                                        <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                    </div>
                                    <!-- /.card-header -->
                                    <div id="text-slide1" class="card-collapse collapse show"
                                         role="tabpanel" aria-labelledby="heading4">
                                        <div class="">
                                            <textarea data-toggle="wysiwyg" id="editor"></textarea>
                                            <div class="accordion custom p-2"
                                                 id="open-ended-question-accordian1" role="tablist"
                                                 aria-multiselectable="true">
                                                <div class="card card-outline-lms-blue light">
                                                    <div class="card-header" role="tab" id="heading4">
                                                        <div class="panel-left">
                                                            <ul class="list-inline">
                                                                <li><a class=""><i
                                                                            class="fa fa-bars"></i></a></li>
                                                                <li><a class="">|</a></li>
                                                                <li><a class="">01</a></li>
                                                                <li><a href="">|</a></li>
                                                                <li><a href="">Open Ended Question</a>
                                                                </li>

                                                            </ul>
                                                        </div>
                                                        <div class="panel-right" style="float: right">
                                                            <ul class="list-inline">
                                                                <li><a class=""><i
                                                                            class="fa fa-copy"></i></a></li>
                                                                <li><a class=""><i
                                                                            class="fa fa-ban"></i></a></li>
                                                                <li><a class=""><i
                                                                            class="fa fa-trash"></i></a>
                                                                </li>
                                                                <li><a href="">|</a></li>
                                                                <li><a role="button" class="chevron"
                                                                       data-toggle="collapse"
                                                                       data-parent="#open-ended-question-accordian1"
                                                                       href="#open-ended-question1"
                                                                       aria-expanded="true"
                                                                       aria-controls="open-ended-question"></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <!--<h6 class="card-title"><a href=""><i class="fa fa-bars"></i></a><a role="button" data-toggle="collapse" data-parent="#accordion-3" href="#collapse21" aria-expanded="true" aria-controls="collapse21">&nbsp; | 02 |&nbsp; Text Slides</a></h6>-->
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <div id="open-ended-question1"
                                                         class="card-collapse collapse show"
                                                         role="tabpanel" aria-labelledby="heading4">
                                                        <div class="card-body">
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label for="question"
                                                                           class="label">Question</label>
                                                                    <input type="text"
                                                                           class="form-control"
                                                                           name="question"/>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="answer-type"
                                                                           class="label">Answer
                                                                        Type</label>
                                                                    <div class="">
                                                                        <label for="free-for-everyone"
                                                                               class="">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Open Ended
                                                                        </label>
                                                                        <label for="free-for-everyone"
                                                                               class="ml-5">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Single Choice
                                                                        </label>
                                                                        <label for="free-for-everyone"
                                                                               class="ml-5">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Multiple Choice
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="correct-answer"
                                                                           class="label">Correct
                                                                        Answer</label>
                                                                    <input type="text"
                                                                           class="form-control"
                                                                           name="correct-answer"
                                                                           placeholder="Type your question here"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- /.card-body -->
                                                </div>
                                                <!-- /.card-collapse -->
                                            </div>
                                            <div class="accordion custom p-2"
                                                 id="single-choice-question-accordian1" role="tablist"
                                                 aria-multiselectable="true">
                                                <div class="card card-outline-lms-blue light  ">
                                                    <div class="card-header" role="tab" id="heading4">
                                                        <div class="panel-left">
                                                            <ul class="list-inline">
                                                                <li><a class=""><i
                                                                            class="fa fa-bars"></i></a></li>
                                                                <li><a class="">|</a></li>
                                                                <li><a class="">02</a></li>
                                                                <li><a href="">|</a></li>
                                                                <li><a href="">Single Choice Question</a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="panel-right" style="float: right">
                                                            <ul class="list-inline">
                                                                <li><a class=""><i
                                                                            class="fa fa-copy"></i></a></li>
                                                                <li><a class=""><i
                                                                            class="fa fa-ban"></i></a></li>
                                                                <li><a class=""><i
                                                                            class="fa fa-trash"></i></a>
                                                                </li>
                                                                <li><a href="">|</a></li>
                                                                <li><a role="button" class="chevron"
                                                                       data-toggle="collapse"
                                                                       data-parent="#single-choice-question-accordian1"
                                                                       href="#single-choice-question1"
                                                                       aria-expanded="true"
                                                                       aria-controls="single-choice-question"></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <div id="single-choice-question1"
                                                         class="card-collapse collapse show"
                                                         role="tabpanel" aria-labelledby="heading4">
                                                        <div class="card-body">
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label for="question"
                                                                           class="label">Question</label>
                                                                    <input type="text"
                                                                           class="form-control"
                                                                           name="question"/>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="answer-type"
                                                                           class="label">Answer
                                                                        Type</label>
                                                                    <div class="">
                                                                        <label for="free-for-everyone"
                                                                               class="">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Open Ended
                                                                        </label>
                                                                        <label for="free-for-everyone"
                                                                               class="ml-5">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Single Choice
                                                                        </label>
                                                                        <label for="free-for-everyone"
                                                                               class="ml-5">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Multiple Choice
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="correct-answer"
                                                                           class="label">Possible
                                                                        Answers</label>
                                                                    <div class="radio inline-radio">
                                                                        <a href="">
                                                                            <i class="fa fa-trash"></i>
                                                                        </a>
                                                                        <input id="result-value"
                                                                               class="form-control" name="value"
                                                                               type="text" value=""
                                                                               placeholder="Type your question here"/>
                                                                        <span style="line-height:34px"><input
                                                                                type="radio">&nbsp;&nbsp;Set as a correct answer</span>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <div class="radio inline-radio">
                                                                        <a href="">
                                                                            <i class="fa fa-trash"></i>
                                                                        </a>
                                                                        <input id="result-value"
                                                                               class="form-control" name="value"
                                                                               type="text" value=""
                                                                               placeholder="Type your question here"/>
                                                                        <span style="line-height:34px"><input
                                                                                type="radio">&nbsp;&nbsp;Set as a correct answer</span>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <div class="radio inline-radio">
                                                                        <a href="">
                                                                            <i class="fa fa-plus"></i>
                                                                        </a>
                                                                        <input id="result-value"
                                                                               class="form-control" name="value"
                                                                               type="text" value=""
                                                                               placeholder="Type your question here"/>
                                                                        <span style="line-height:34px"><input
                                                                                type="radio">&nbsp;&nbsp;Set as a correct answer</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- /.card-body -->
                                                </div>
                                                <!-- /.card-collapse -->
                                            </div>
                                            <div class="accordion custom p-2"
                                                 id="multiple-choice-question-accordian1" role="tablist"
                                                 aria-multiselectable="true">
                                                <div class="card card-outline-lms-blue light  ">
                                                    <div class="card-header" role="tab" id="heading4">
                                                        <div class="panel-left">
                                                            <ul class="list-inline">
                                                                <li><a class=""><i
                                                                            class="fa fa-bars"></i></a></li>
                                                                <li><a class="">|</a></li>
                                                                <li><a class="">03</a></li>
                                                                <li><a href="">|</a></li>
                                                                <li><a href="">Question with Multiple Choice</a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="panel-right" style="float: right">
                                                            <ul class="list-inline">
                                                                <li><a class=""><i
                                                                            class="fa fa-copy"></i></a></li>
                                                                <li><a class=""><i
                                                                            class="fa fa-ban"></i></a></li>
                                                                <li><a class=""><i
                                                                            class="fa fa-trash"></i></a>
                                                                </li>
                                                                <li><a href="">|</a></li>
                                                                <li><a role="button" class="chevron"
                                                                       data-toggle="collapse"
                                                                       data-parent="#multiple-choice-question-accordian1"
                                                                       href="#multiple-choice-question1"
                                                                       aria-expanded="true"
                                                                       aria-controls="single-choice-question"></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <div id="multiple-choice-question1"
                                                         class="card-collapse collapse show"
                                                         role="tabpanel" aria-labelledby="heading4">
                                                        <div class="card-body">
                                                            <div class="col-sm-12">
                                                                <div class="form-group">
                                                                    <label for="question"
                                                                           class="label">Question</label>
                                                                    <input type="text"
                                                                           class="form-control"
                                                                           name="question"/>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="answer-type"
                                                                           class="label">Answer
                                                                        Type</label>
                                                                    <div class="">
                                                                        <label for="free-for-everyone"
                                                                               class="">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Open Ended
                                                                        </label>
                                                                        <label for="free-for-everyone"
                                                                               class="ml-5">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Single Choice
                                                                        </label>
                                                                        <label for="free-for-everyone"
                                                                               class="ml-5">
                                                                            <input type="radio"
                                                                                   name="answer-type">
                                                                            &nbsp;&nbsp;Multiple Choice
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="correct-answer"
                                                                           class="label">Possible
                                                                        Answers</label>
                                                                    <div class="radio inline-radio">
                                                                        <a href="">
                                                                            <i class="fa fa-trash"></i>
                                                                        </a>
                                                                        <input id="result-value"
                                                                               class="form-control" name="value"
                                                                               type="text" value=""
                                                                               placeholder="Type your question here"/>
                                                                        <span style="line-height:34px"><input
                                                                                type="radio">&nbsp;&nbsp;Set as a correct answer</span>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <div class="radio inline-radio">
                                                                        <a href="">
                                                                            <i class="fa fa-trash"></i>
                                                                        </a>
                                                                        <input id="result-value"
                                                                               class="form-control" name="value"
                                                                               type="text" value=""
                                                                               placeholder="Type your question here"/>
                                                                        <span style="line-height:34px"><input
                                                                                type="radio">&nbsp;&nbsp;Set as a correct answer</span>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <div class="radio inline-radio">
                                                                        <a href="">
                                                                            <i class="fa fa-plus"></i>
                                                                        </a>
                                                                        <input id="result-value"
                                                                               class="form-control" name="value"
                                                                               type="text" value=""
                                                                               placeholder="Type your question here"/>
                                                                        <span style="line-height:34px"><input
                                                                                type="radio">&nbsp;&nbsp;Set as a correct answer</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- /.card-body -->
                                                </div>
                                                <!-- /.card-collapse -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card-collapse -->
                            </div>
                        </div>
                    </div>
                    <!-- /.tab-content -->
                </div>
            </div>
        </div>
    </section>
  
    </form>
</main>