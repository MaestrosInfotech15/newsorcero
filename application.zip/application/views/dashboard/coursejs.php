<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/js/bootstrap-select.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap-filestyle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-wysiwyg/0.3.3/bootstrap3-wysihtml5.all.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js" jquery></script>
 <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>
$(document).ready(function()
{
	$('input[name="image"]').click(function()
	{
		var inputValue = $(this).attr("value");
		$("#filesn").attr("style","display:"+inputValue);
	});
	
	$('input[name="_limit_time"]').click(function()
	{
		var inputValue = $(this).attr("value");
		$("#time").attr("style","display:"+inputValue);
	});
	$('input[name="marks"]').click(function()
	{
		var inputValue = $(this).attr("value");
		$("#marks").attr("style","display:"+inputValue);
	});
	$('input[name="marks1"]').click(function()
	{
		var inputValue = $(this).attr("value");
		$("#marks1").attr("style","display:"+inputValue);
	});
	$('input[name="marks2"]').click(function()
	{
		var inputValue = $(this).attr("value");
		$("#marks2").attr("style","display:"+inputValue);
	});
	$('input[name="Question_type"]').click(function()
	{
		var inputValue = $(this).attr("value");
		//alert(inputValue);
		if(inputValue=='Open Ended Question')
		{
			$("#question1").attr("style","display:block");
			$("#question2").attr("style","display:none");
			$("#question3").attr("style","display:none");
			$("#question4").attr("style","display:none");
		}
		if(inputValue=='Single Choice Question')
		{
			$("#question1").attr("style","display:none");
			$("#question2").attr("style","display:block");
			$("#question3").attr("style","display:none");
			$("#question4").attr("style","display:none");
		}
		if(inputValue=='Multiple Choice Question')
		{
			$("#question1").attr("style","display:none");
			$("#question2").attr("style","display:none");
			$("#question3").attr("style","display:block");
			$("#question4").attr("style","display:none");
		}
		if(inputValue=='Question with File  Upload')
		{
			$("#question1").attr("style","display:none");
			$("#question2").attr("style","display:none");
			$("#question3").attr("style","display:none");
			$("#question4").attr("style","display:block");
		}
	});
	
	
	 $('#usergroup').change(function()
	  {
		  
       	$('#usergroup :selected').each(function(i, selected)
	    {
       
		       var text = $(this).text();
           //alert(text);
		       var value = $(this).val();
			   var allready= $('#'+value).text();
			   if(allready=="")
			   {
		       		$('#grouptag').prepend("<li class='tag' id='"+value+"' data-id='"+value+"'><a><i class='fa fa-trash'></i></a> <span>"+text+"<span></li>")
			   }
		   });	    
	  });
	
	 $('#alluser').change(function()
	  {
		  
       	$('#alluser :selected').each(function(i, selected)
	    {
       
		       var text = $(this).text();
           //alert(text);
		       var value = $(this).val();
			   var allready= $('#'+value).text();
			   if(allready=="")
			   {
		       		$('#usertag').prepend("<li class='tag' id='"+value+"' data-id='"+value+"'><a><i class='fa fa-trash'></i></a> <span>"+text+"<span></li>")
			   }
		   });	    
	  });
	  $('body').on('click',".tag", function(){
	      var id = $(this).data("id");
        $(this).remove();
        $('#usergroup :selected').each(function(i, selected){
			
           if($(this).val() == id){
			   //$('.dropdown-menu .selected').removeAttr("class","selected");
             $("select option[value='"+id+"']").prop("selected", false);
           }
        })
          
	  });
	
});

//for text editer

tinymce.init({ selector:'textarea' });



</script>