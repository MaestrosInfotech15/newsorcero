<main class="main-wrapper clearfix p-0">
            <section class=" add-form">


                <div class="mail-inbox border-all row no-gutters" style="height: 80vh">
                    <div class="col-12 d-md-none">
                        <ul class="list-inline mobile-mail-menu">
                            <li>
                                <a href="javascript:void(0);"><span class="">Compose</span></a>
                            </li>
                            <li class="current-page ">
                                <a href="javascript:void(0);"><span class="">Inbox</span></a>

                            </li>
                            <li class=" ">
                                <a href="javascript:void(0);"><span class="">Draft</span></a>

                            </li>
                            <li class=" ">
                                <a href="javascript:void(0);"><span class="">Sent</span></a>

                            </li>
                            <li class=" ">
                                <a href="javascript:void(0);"><span class="">Trash</span></a>

                            </li>
                        </ul>
                    </div>
                    <div class="col-2 d-none d-md-flex flex-column mail-sidebar h-100">
                        <nav class="mailer-menu ">
                            <ul class="  mailer">
                                <li>
                                    <button class="btn btn-rounded custom-btn email-compose-btn ripple ">Compose</button>
                                </li>
                                <li class="current-page ">
                                    <a href="javascript:void(0);"><span class="">Inbox</span></a>

                                </li>
                                <li class=" ">
                                    <a href="javascript:void(0);"><span class="">Draft</span></a>

                                </li>
                                <li class=" ">
                                    <a href="javascript:void(0);"><span class="">Sent</span></a>

                                </li>
                                <li class=" ">
                                    <a href="javascript:void(0);"><span class="">Trash</span></a>

                                </li>
                            </ul>
                            <!-- /.side-menu -->
                        </nav>
                    </div>
                    <!-- Mail Sidebar -->
                    <div class="col-md-4 d-none d-md-flex flex-column mail-sidebar h-100">
                        <div class="mail-inbox-header">
                            <div class="mail-inbox-tools flex-1 d-flex align-items-center"><span
                                    class="checkbox checkbox-primary bw-3 heading-font-family fs-14 fw-semibold headings-color mail-inbox-select-all"><label><input
                                    type="checkbox"/> <span class="label-text">&nbsp;</span>
                                                </label>
                                                </span>
                                <span class="label-text">Today</span>
                                <div class="flex-1"></div>
                                <div class="btn-group">
                                    <a href="javascript:void(0)"
                                       class="btn btn-sm btn-link mr-2 text-muted"><i
                                            class="list-icon fs-18 feather feather-trash-2"></i></a>


                                    <!-- /.dropdown -->
                                </div>
                                <!-- /.btn-group -->
                            </div>
                            <!-- /.mail-inbox-tools -->
                        </div>
                        <!-- /.mail-inbox-header -->
                        <div class="mail-list flex-1 scrollbar-enabled pr-0">
                            <div class="mail-list-item  media">
                                <a href="#" class="pos-absolute pos-0 zi-0"></a>
                                <div class="checkbox checkbox-primary bw-3 mail-select-checkbox">
                                    <label>
                                        <input type="checkbox"/> <span class="label-text"></span>
                                    </label>
                                </div>
                                <!-- /.checkbox -->
                                <div class="media-body">
                                    <div class="d-flex">

                                        <div class="headings-font-family"><span
                                                class="mail-title headings-color d-block zi-3">Fahad Khan</span>
                                            <small class="text-muted ">What happened to my test results?
                                                Hi, I havent got any news about my test results
                                            </small>
                                        </div>
                                        <div class="flex-1"></div>
                                        <a href="" class="trash-icon"><i class="fa fa-trash"></i></a>
                                        <!--<div class="checkbox checkbox-star fs-18">-->
                                        <!--<label>-->
                                        <!--<input type="checkbox" checked="checked" /> <span class="label-text"></span>-->
                                        <!--</label>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /.d-flex -->
                                    <!--<!--<div class="d-flex align-items-center mt-3"><a href="#" class="zi-2"><i class="feather feather-message-circle fs-16 align-middle mr-1"></i> <span class="text-muted fs-12">Quick Reply</span></a>
                                        <div class="flex-1"></div><span class="text-muted fs-12">Today, 12:30 am</span>
                                    </div>-->
                                    <!-- /.d-flex -->
                                </div>
                                <!-- /.media-body -->
                            </div>
                            <!-- /.mail-list-item -->
                            <div class="mail-list-item unread media">
                                <a href="#" class="pos-absolute pos-0 zi-0"></a>
                                <div class="checkbox checkbox-primary bw-3 mail-select-checkbox">
                                    <label>
                                        <input type="checkbox"/> <span class="label-text"></span>
                                    </label>
                                </div>
                                <!-- /.checkbox -->
                                <div class="media-body">
                                    <div class="d-flex">

                                        <div class="headings-font-family"><span
                                                class="mail-title headings-color d-block zi-3">Fahad Khan</span>
                                            <small class="text-muted ">What happened to my test results?
                                                Hi, I havent got any news about my test results
                                            </small>
                                        </div>
                                        <div class="flex-1"></div>
                                        <a href="" class="trash-icon"><i class="fa fa-trash"></i></a>
                                        <!--<div class="checkbox checkbox-star fs-18">-->
                                        <!--<label>-->
                                        <!--<input type="checkbox" checked="checked" /> <span class="label-text"></span>-->
                                        <!--</label>-->
                                        <!--</div>-->
                                    </div>
                                    <!-- /.d-flex -->
                                    <!--<!--<div class="d-flex align-items-center mt-3"><a href="#" class="zi-2"><i class="feather feather-message-circle fs-16 align-middle mr-1"></i> <span class="text-muted fs-12">Quick Reply</span></a>
                                        <div class="flex-1"></div><span class="text-muted fs-12">Today, 12:30 am</span>
                                    </div>-->
                                    <!-- /.d-flex -->
                                </div>
                                <!-- /.media-body -->
                            </div>
                            <!-- /.mail-list-item -->
                            <div class="mail-list-item  media">
                                <a href="#" class="pos-absolute pos-0 zi-0"></a>
                                <div class="checkbox checkbox-primary bw-3 mail-select-checkbox">
                                    <label>
                                        <input type="checkbox"/> <span class="label-text"></span>
                                    </label>
                                </div>
                                <!-- /.checkbox -->
                                <div class="media-body">
                                    <div class="d-flex">
                                        <div class="headings-font-family"><span
                                                class="mail-title headings-color d-block zi-3">Fahad Khan</span>
                                            <small class="text-muted ">What happened to my test results?
                                                Hi, I havent got any news about my test results
                                            </small>
                                        </div>
                                        <div class="flex-1"></div>
                                        <a href="" class="trash-icon"><i class="fa fa-trash"></i></a>
                                    </div>
                                    <!-- /.d-flex -->

                                    <!-- /.d-flex -->
                                </div>
                                <!-- /.media-body -->
                            </div>
                            <!-- /.mail-list-item -->
                            <div class="mail-list-item  media">
                                <a href="#" class="pos-absolute pos-0 zi-0"></a>
                                <div class="checkbox checkbox-primary bw-3 mail-select-checkbox">
                                    <label>
                                        <input type="checkbox"/> <span class="label-text"></span>
                                    </label>
                                </div>
                                <!-- /.checkbox -->
                                <div class="media-body">
                                    <div class="d-flex">
                                        <div class="headings-font-family"><span
                                                class="mail-title headings-color d-block zi-3">Fahad Khan</span>
                                            <small class="text-muted ">What happened to my test results?
                                                Hi, I havent got any news about my test results
                                            </small>
                                        </div>
                                        <div class="flex-1"></div>
                                        <a href="" class="trash-icon"><i class="fa fa-trash"></i></a>
                                    </div>
                                    <!-- /.d-flex -->
                                    <!--<div class="d-flex align-items-center mt-3"><a href="#" class="zi-2"><i class="feather feather-message-circle fs-16 align-middle mr-1"></i> <span class="text-muted fs-12">Quick Reply</span></a>-->
                                    <!--<div class="flex-1"></div><span class="text-muted fs-12">Today, 7:22 am</span>-->
                                    <!--</div>-->
                                    <!-- /.d-flex -->
                                </div>
                                <!-- /.media-body -->
                            </div>


                        </div>
                        <!-- /.mail-inbox -->
                    </div>
                    <!-- /.mail-sidebar -->
                    <div class="col-md-6 col-12 h-100 d-flex flex-column">
                        <div class="mail-inbox-header">
                            <div class="mail-inbox-tools flex-1 d-flex align-items-center">
                                <div class="btn-group">
                                    <a href="javascript:void(0)" class="btn btn-sm btn-link mr-2 text-muted"><i
                                            class="list-icon fs-18 feather feather-trash-2"></i>
                                    </a>
                                    <a href="javascript:void(0)" class="btn btn-sm btn-link mr-2 text-muted"><i
                                            class="list-icon fs-18 feather feather-trash-2"></i>
                                    </a>
                                    <a href="javascript:void(0)" class="btn btn-sm btn-link mr-2 text-muted"><i
                                            class="list-icon fs-18 feather feather-trash-2"></i>
                                    </a>

                                    <!-- /.dropdown -->
                                </div>
                                <div class="flex-1"></div>
                                <div class="btn-group">
                                    <a href="javascript:void(0)" class="btn btn-sm btn-link mr-2 text-muted"><i
                                            class="list-icon fs-18 feather feather-trash-2"></i>
                                    </a>

                                    <!-- /.dropdown -->
                                </div>
                                <!-- /.btn-group -->
                            </div>
                            <!-- /.mail-inbox-tools -->
                        </div>
                        <!-- /.mail-inbox-header -->
                        <div class="mail-single flex-1 scrollbar-enabled pr-4">
                            <div class="border-bottom mb-4 mx-4">
                                <h2 class="my-4">What you've learnt about creating</h2>
                                <div class="media">
                                    <div class="media-body headings-font-family">
                                        <a href="" class="recipient">Fahad Khan</a>
                                        <small><a href="#">&lt;fahad@yahoo.com&gt;</a>
                                        </small>
                                    </div>
                                    <!-- /.media-body -->

                                    <span class="text-muted headings-font-family  fs-12 mr-4">Feb 16 at 11:19 PM</span>

                                </div>
                            </div>

                            <!-- /.mail-single-info -->
                            <!--<div class="border-bottom mb-4 mx-4">-->
                            <!--<h2 class="my-4">What you've learnt about creating</h2>-->
                            <!--</div>-->
                            <div class="mail-single-body  mx-4">

                                <p>Dear Sir,</p>

                                <p>I would like to express my deep interest in a position as editorial assistant for
                                    your publishing company.

                                    As a recent graduate with writing, editing, and administrative experience, I believe
                                    I am a strong candidate for a position at the 123 Publishing Company.

                                    You specify that you are looking for someone with strong writing skills. As an
                                    English major at XYZ University, a writing tutor, and an editorial intern for both a
                                    government magazine and a college marketing office, I have become a skilled writer
                                    with a variety of publication experience.

                                    My maturity, practical experience, attention to detail, and eagerness to enter the
                                    publishing business will make me an excellent editorial assistant. I would love to
                                    begin my career with your company and am confident that I would be a beneficial
                                    addition to the 123 Publishing Company.

                                    I have enclosed my resume and will call within the next week to see if we might
                                    arrange a time to speak together.</p>

                                <p>
                                    Thank you so much for your time and consideration.</p>
                                <p>
                                    Sincerely,

                                    <br/>Fahad Khan</p>

                            </div>
                            <!-- /.mail-single-body -->
                            <div class="mail-attachment border-bottom p-4 headings-font-family">
                                <div class="list-unstyled file-list">
                                    <div class="file-list-item">
                                        <a href="#"
                                           class="fw-semibold mx-2">test.pdf</a>
                                        <i class="fa fa-file-pdf-o"></i>

                                    </div>
                                    <div class="file-list-item">
                                        <a href="#"
                                           class="fw-semibold mx-2">test.pdf</a>
                                        <i class="fa fa-file-pdf-o"></i>

                                    </div>

                                    <!-- /.file-item -->
                                </div>
                                <!-- /.list-unstyled -->
                            </div>

                        </div>
                        <!-- /.mail-single -->
                    </div>
                    <!-- /.col-lg-9 -->
                </div>


            </section>
        </main>