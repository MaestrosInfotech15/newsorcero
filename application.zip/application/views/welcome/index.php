<div class="navbar-header text-center  mt-5">
    <a href="<?php echo base_url();?>">
        <img alt="" src="./assets/img/login-logo.png"/>
    </a>
</div>


<form id="loginForm" method="post" class="text-center login-center has-validation-callback" action="<?php echo base_url();?>login/check_login">
    <h2 class="mb-4 text-center login-title">Lets Learn Together</h2>
    <?php if(!empty($domain)):?>
    <div class="form-group mr-b-20">
        <a href="<?php echo base_url('login'); ?>" class="btn btn-block btn-rounded btn-md btn-color-scheme btn-login text-uppercase fw-600 ripple"
                >LOGIN
        </a>
    </div>
    <?php endif;?>
    <div class="form-group mr-b-20">
        <a href="<?php echo base_url('create'); ?>" class="btn btn-block btn-rounded btn-md btn-color-scheme btn-login text-uppercase fw-600 ripple"
                >SIGN UP
        </a>
    </div>
    
</form>
<!-- /form -->