<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"/>
    <!--<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url();?>assets/demo/favicon.png"/>-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/pace.css"/>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css"/>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Default</title>
    <!-- CSS -->
    <link href="<?php echo base_url();?>assets/vendors/material-icons/material-icons.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url();?>assets/vendors/linea-icons/styles.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url();?>assets/vendors/mono-social-icons/monosocialiconsfont.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url();?>assets/vendors/feather-icons/feather.css" rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.4/sweetalert2.css" rel="stylesheet"
          type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet"
          type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.1.3/mediaelementplayer.min.css" rel="stylesheet"
          type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.7.0/css/perfect-scrollbar.min.css"
          rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,900,900i"
          rel="stylesheet" type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
          type="text/css"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.css" rel="stylesheet"
          type="text/css"/>
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css"/>
    <!-- Head Libs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    <script data-pace-options='{ "ajax": false }'
            src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>

<body class="header-dark sidebar-light sidebar-expand">
<div id="wrapper" class="wrapper">
    <!-- HEADER & TOP NAVIGATION -->

    <nav class="navbar">

        <!-- Logo Area -->
        <div class="navbar-header">
            <a href="./index.html" class="navbar-brand">
                <img class="logo-expand" alt="" src="<?php echo base_url();?>assets/img/logo.png"/>
                <img class="logo-collapse" alt="" src="<?php echo base_url();?>assets/img/mini_logo.png"/>
                <!-- <p>BonVue</p> -->
            </a>
        </div>
        <!-- /.navbar-header -->
        <!-- Left Menu & Sidebar Toggle -->
        <ul class="nav navbar-nav">
            <li class="sidebar-toggle"><a href="javascript:void(0)" class="ripple"><i
                    class="feather feather-menu list-icon fs-20"></i></a>
            </li>
        </ul>
        <!-- /.navbar-left -->
        <!-- Search Form -->
        <form class="navbar-search d-none d-sm-block" role="search"/>
        <i class="feather feather-search list-icon"></i>
        <input type="search" class="search-query" placeholder="Search "/> <a href="javascript:void(0);"
                                                                             class="remove-focus"><i
            class="material-icons">clear</i></a>
        </form>
        <!-- /.navbar-search -->
        <div class="spacer"></div>
        <!-- Button: Create New -->
        <div class="btn-list dropdown d-none d-lg-flex mr-4"><a href="javascript:void(0);"
                                                                class="btn btn-primary dropdown-toggle ripple"
                                                                data-toggle="dropdown"> Create Course</a>
            <div class="dropdown-menu dropdown-left animated flipInY"><span
                    class="dropdown-header">Create new ...</span> <a class="dropdown-item" href="#">Projects</a> <a
                    class="dropdown-item" href="#">User Profile</a> <a class="dropdown-item" href="#"><span
                    class="d-flex align-items-end"><span class="flex-1">To-do Item</span> <span
                    class="badge badge-pill bg-primary-contrast">7</span> </span></a>
                <a class="dropdown-item" href="#"><span class="d-flex align-items-end"><span class="flex-1">Mail</span>  <span
                        class="badge badge-pill bg-color-scheme-contrast">23</span></span>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#"><span class="d-flex align-items-center"><span
                        class="flex-1">Settings</span> <i
                        class="feather feather-settings list-icon icon-muted"></i></span></a>
            </div>
        </div>
        <!-- Button: Create New -->
        <div class="btn-list dropdown d-none d-lg-flex mr-4"><a href="javascript:void(0);"
                                                                class="btn btn-primary  dropdown-toggle ripple"
                                                                data-toggle="dropdown"> Add Student</a>
            <div class="dropdown-menu dropdown-left animated flipInY"><span
                    class="dropdown-header">Create new ...</span> <a class="dropdown-item" href="#">Projects</a> <a
                    class="dropdown-item" href="#">User Profile</a> <a class="dropdown-item" href="#"><span
                    class="d-flex align-items-end"><span class="flex-1">To-do Item</span> <span
                    class="badge badge-pill bg-primary-contrast">7</span> </span></a>
                <a class="dropdown-item" href="#"><span class="d-flex align-items-end"><span class="flex-1">Mail</span>  <span
                        class="badge badge-pill bg-color-scheme-contrast">23</span></span>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#"><span class="d-flex align-items-center"><span
                        class="flex-1">Settings</span> <i
                        class="feather feather-settings list-icon icon-muted"></i></span></a>
            </div>
        </div>
        <!-- /.btn-list -->

        <!-- /.navbar-right -->
        <!-- Right Menu -->
        <ul class="nav navbar-nav  d-lg-flex ml-2">
            <li class="dropdown"><a href="javascript:void(0);" class="dropdown-toggle ripple custom-badge "
                                    data-toggle="dropdown "><i class="fa fa-bell list-icon"></i></a>
                <div class="dropdown-menu dropdown-left dropdown-card animated flipInY">
                    <div class="card">
                        <header class="card-header d-flex align-items-center mb-0"><a href="javascript:void(0);"><i
                                class="feather feather-bell color-color-scheme" aria-hidden="true"></i></a> <span
                                class="heading-font-family flex-1 text-center fw-400">Notifications</span>
                            <a href="javascript:void(0);"><i class="feather feather-settings color-content"></i></a>
                        </header>
                        <ul class="card-body list-unstyled dropdown-list-group">
                            <li><a href="#" class="media"><span class="d-flex thumb-xs"><img
                                    src="<?php echo base_url();?>assets/demo/users/user3.jpg" class="rounded-circle" alt=""/> </span><span
                                    class="media-body"><span
                                    class="heading-font-family media-heading">Dany Miles </span><span
                                    class="media-content">commented on your photo</span> <span
                                    class="user--online float-right my-auto"></span></span></a>
                            </li>
                            <li><a href="#" class="media"><span class="d-flex thumb-xs"><img
                                    src="<?php echo base_url();?>assets/demo/users/user6.jpg" class="rounded-circle" alt=""/> </span><span
                                    class="media-body"><span
                                    class="heading-font-family media-heading">Emily Woodworth </span><span
                                    class="media-content">posted a photo on your wall.</span></span></a>
                            </li>
                            <li><a href="#" class="media"><span class="d-flex thumb-xs"><img
                                    src="<?php echo base_url();?>assets/demo/users/user2.jpg" class="rounded-circle" alt=""/> </span><span
                                    class="media-body"><span
                                    class="heading-font-family media-heading">Palmer Kate </span><span
                                    class="media-content">just mentioned you in his post</span></span></a>
                            </li>
                        </ul>
                        <!-- /.dropdown-list-group -->
                        <footer class="card-footer text-center"><a href="javascript:void(0);"
                                                                   class="content-font-family text-uppercase fs-13">See
                            all activity</a>
                        </footer>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.dropdown-menu -->
            </li>
            <!-- /.dropdown -->
            <li class="dropdown"><a href="#" class="dropdown-toggle ripple " data-toggle="dropdown"><i
                    class="fa fa-comment list-icon"></i></a>
                <div class="dropdown-menu dropdown-left dropdown-card animated flipInY">
                    <div class="card">
                        <header class="card-header d-flex justify-content-between mb-0"><a href="javascript:void(0);"><i
                                class="feather feather-bell color-color-scheme" aria-hidden="true"></i></a> <span
                                class="heading-font-family flex-1 text-center fw-400">Notifications</span>
                            <a href="javascript:void(0);"><i class="feather feather-settings color-content"></i></a>
                        </header>
                        <ul class="card-body list-unstyled dropdown-list-group">
                            <li><a href="#" class="media"><span class="d-flex"><i
                                    class="material-icons list-icon">check</i> </span><span class="media-body"><span
                                    class="heading-font-family media-heading">Invitation accepted</span> <span
                                    class="media-content">Your have been Invited ...</span></span></a>
                            </li>
                            <li><a href="#" class="media"><span class="d-flex thumb-xs"><img
                                    src="<?php echo base_url();?>assets/demo/users/user3.jpg" class="rounded-circle" alt=""/> </span><span
                                    class="media-body"><span
                                    class="heading-font-family media-heading">Steve Smith</span> <span
                                    class="media-content">I slowly updated projects</span> <span
                                    class="user--online float-right"></span></span></a>
                            </li>
                            <li><a href="#" class="media"><span class="d-flex"><i class="material-icons list-icon">event_available</i> </span><span
                                    class="media-body"><span
                                    class="-heading-font-family media-heading">To Do</span> <span class="media-content">Meeting with Nathan on Friday 8 AM ...</span></span></a>
                            </li>
                        </ul>
                        <!-- /.dropdown-list-group -->
                        <footer class="card-footer text-center"><a href="javascript:void(0);"
                                                                   class="text-uppercase fs-13">See all activity</a>
                        </footer>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.dropdown-menu -->
            </li>
            <!-- /.dropdown -->
            <!-- <li><a href="javascript:void(0);" class="right-sidebar-toggle active ripple ml-3"><i class="feather feather-grid list-icon"></i></a>
                </li> -->
            <li class="dropdown"><a href="javascript:void(0);" class="dropdown-toggle ripple"
                                    data-toggle="dropdown"><span class="avatar thumb-xs2"><img
                    src="<?php echo base_url();?>assets/img/member1.png" class="rounded-circle" alt=""/> <i
                    class="feather feather-chevron-down list-icon"></i></span></a>
                <div class="dropdown-menu dropdown-left dropdown-card dropdown-card-profile animated flipInY">
                    <div class="card">
                        <!--<header class="card-header d-flex mb-0"><a href="javascript:void(0);"-->
                        <!--class="col-md-4 text-center"><i-->
                        <!--class="feather feather-user-plus align-middle"></i> </a><a href="javascript:void(0);"-->
                        <!--class="col-md-4 text-center"><i-->
                        <!--class="feather feather-settings align-middle"></i> </a>-->
                        <!--<a href="javascript:void(0);" class="col-md-4 text-center"><i-->
                        <!--class="feather feather-power align-middle"></i>-->
                        <!--</a>-->
                        <!--</header>-->
                        <ul class="list-unstyled card-body">
                            <li><a href="#"><span><span class="align-middle">Manage Accounts</span></span></a>
                            </li>
                            <li><a href="#"><span><span class="align-middle">Change Password</span></span></a>
                            </li>
                            <li><a href="#"><span><span class="align-middle">Check Inbox</span></span></a>
                            </li>
                            <li><a href="#"><span><span class="align-middle">Sign Out</span></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
        <!-- /.navbar-right -->
    </nav>


    <!-- /.navbar -->
    <div class="content-wrapper">
        <!-- SIDEBAR -->
        <aside class="site-sidebar scrollbar-enabled" data-suppress-scroll-x="true">

            <!-- /.side-user -->
            <!-- Sidebar Menu -->
            <nav class="sidebar-nav">
                <ul class="nav in side-menu">
                    <li class="current-page ">
                        <a href="javascript:void(0);"><i class="list-icon feather feather-command"></i> <span
                                class="hide-menu">Dashboard</span></a>

                    </li>
                    <li class="menu-item-has-children active">
                        <a href="javascript:void(0);"><i class="list-icon fa fa-graduation-cap"></i> <span
                                class="hide-menu">Courses</span></a>
                        <ul class="list-unstyled sub-menu">
                            <li><a href="./app-calender.html">Create Course</a>
                            </li>
                            <li><a href="./app-chat.html">Manage Courses</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="javascript:void(0);"><i class="list-icon feather feather-tag"></i> <span
                                class="hide-menu">Categories</span></a>
                        <ul class="list-unstyled sub-menu">
                            <li><a href="#">Link </a>
                            </li>
                            <li><a href="#">Link 2</a>
                            </li>

                            <!--<li class="menu-item-has-children"><a href="javascript:void(0);">Sub Menu Link2</a>-->
                            <!--<ul class="list-unstyled sub-menu">-->
                            <!--<li><a href="#">Sub Link 1</a>-->
                            <!--</li>-->
                            <!--<li><a href="#">Sub Link 1</a>-->
                            <!--</li>-->
                            <!--<li><a href="#">Sub Link 1</a>-->
                            <!--</li>-->
                            <!--<li><a href="#">Sub Link 1</a>-->
                            <!--</li>-->
                            <!--</ul>-->
                            <!--</li>-->
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="javascript:void(0);"> <i class="list-icon feather feather-user"></i><span
                                class="hide-menu">Students</span></a>
                        <ul class="list-unstyled sub-menu">
                            <li><a href="#">Link </a>
                            </li>
                            <li><a href="#">Link 2</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="javascript:void(0);"><i class="list-icon feather feather-message-square"></i> <span
                                class="hide-menu">Message Center</span></a>
                        <ul class="list-unstyled sub-menu">
                            <li><a href="#">Link </a>
                            </li>
                            <li><a href="#">Link 2</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="javascript:void(0);"><i class="list-icon fa fa-bar-chart"></i> <span class="hide-menu">Reports</span></a>
                        <ul class="list-unstyled sub-menu">
                            <li><a href="#">Link </a>
                            </li>
                            <li><a href="#">Link 2</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="javascript:void(0);"><i class="list-icon fa fa-user"></i> <span class="hide-menu">Instructors</span></a>
                        <ul class="list-unstyled sub-menu">
                            <li><a href="#">Link </a>
                            </li>
                            <li><a href="#">Link 2</a>
                            </li>
                        </ul>
                    </li>

                    <li class="">
                        <a href="javascript:void(0);"><i class="list-icon fa fa-gear"></i> <span class="hide-menu">Settings</span></a>

                    </li>

                </ul>
                <!-- /.side-menu -->
            </nav>
            <!-- /.sidebar-nav -->
        </aside>
        <!-- /.site-sidebar -->
        <main class="main-wrapper clearfix">

            <!-- =================================== -->
            <!-- Different data widgets ============ -->
            <!-- =================================== -->
            <div class="widget-list">
                <div class="row">
                    <div class="col-md-12 widget-holder">
                        <div class="">
                            <div class="widget-body clearfix">
                                <h6 class="box-title page-title-heading color-blue mr-0 mr-r-5">COURSE ACTIVITY</h6>
                                <div style="height: 230px" class="mt50">
                                    <canvas id="chartJsLineSingleGradient"></canvas>
                                </div>
                            </div>
                            <!-- /.widget-body -->
                        </div>
                        <!-- /.widget-bg -->
                    </div>
                </div>
            </div>
            <section class="counter-section">
                <div class="widget-list">
                    <div class="row">
                        <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                            <div class="">
                                <div class=" text-center">
                                    <div class="counter-custom">
                                        New Students
                                        <div class="counterBg green">
                                            <div class="counterFg">
                                                <i class="fa fa-graduation-cap"></i>
                                                <small>&nbsp;&nbsp;2960</small>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                        <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                            <div class="">
                                <div class=" text-center">
                                    <div class="counter-custom">
                                        Total Students
                                        <div class="counterBg red">
                                            <div class="counterFg">
                                                <i class="fa fa-graduation-cap"></i>
                                                <small>&nbsp;&nbsp;2960</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                        <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                            <div class="">
                                <div class=" text-center">
                                    <div class="counter-custom">
                                        course completed
                                        <div class="counterBg green">
                                            <div class="counterFg">
                                                <i class="fa fa-check"></i>
                                                <small>&nbsp;&nbsp;2960</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                        <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                            <div class="">
                                <div class=" text-center">
                                    <div class="counter-custom">
                                        Total courses
                                        <div class="counterBg red">
                                            <div class="counterFg">
                                                <i class="fa fa-book"></i>
                                                <small>&nbsp;&nbsp;2960</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                        <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                            <div class="">
                                <div class=" text-center">
                                    <div class="counter-custom">
                                        Active courses
                                        <div class="counterBg green">
                                            <div class="counterFg">
                                                <i class="fa fa-book"></i>
                                                <small>&nbsp;&nbsp;2960</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                        <div class="widget-holder col-md-6 col-lg-4 col-xl-2">
                            <div class="">
                                <div class=" text-center">
                                    <div class="counter-custom ">
                                        users online
                                        <div class="counterBg red">
                                            <div class="counterFg">
                                                <i class="fa fa-users"></i>
                                                <small>&nbsp;&nbsp;2960</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                    </div>
                    <!-- /.row -->
                </div>
            </section>
            <section class="event-calendar-section">
                <div class="widget-list">
                    <div class="row">
                        <!-- Events List -->
                        <div class="col-md-12 widget-holder widget-full-content border-all px-0">
                            <div class="widget-bg">
                                <div class="widget-body">
                                    <div class="row no-gutters">
                                        <!-- Calender Sidebar -->
                                        <div class="col-md-3 custom-fullcalendar-sidebar pos-absolute pos-left d-none d-md-block">
                                            <div class="fullcalendar-events" data-toggle="fullcalendar-events"
                                                 data-target="#fullcalendar-1">
                                                <div class="inbox-categories inbox-labels px-3">
                                                    <h5 class="pl-3 mt-4">Month Planner</h5>
                                                    <div class="fc-events">
                                                        <div class="fc-event bg-persian-blue"><i
                                                                class="feather feather-check color-white bg-persian-blue"></i>
                                                            <span class="fc-event-text">Meetings</span>
                                                        </div>
                                                        <div class="fc-event bg-cerize-red"><i
                                                                class="feather feather-check color-white bg-cerize-red"></i>
                                                            <span class="fc-event-text">Callbacks</span>
                                                        </div>
                                                        <div class="fc-event bg-mustard"><i
                                                                class="feather feather-check color-white bg-mustard"></i><span
                                                                class="fc-event-text">Tasks Pending</span>
                                                        </div>
                                                        <div class="fc-event bg-gray-light"><i
                                                                class="feather feather-check color-white bg-gray-light"></i>
                                                            <span class="fc-event-text">Travel</span>
                                                        </div>
                                                    </div>
                                                    <!-- /.fc-events -->
                                                </div>
                                                <div class="m-3 mr-t-40">
                                                    <button class="btn btn-color-scheme btn-block btn-rounded btn-xl px-4 my-0 fs-16 ripple fc-add-event fw-500">
                                                        <span>Add Event</span>
                                                    </button>
                                                </div>
                                            </div>
                                            <!-- /.fullcalendar-events -->
                                        </div>
                                        <!-- /.col-md-3 -->
                                        <!-- Calender App -->
                                        <div class="col-12 mb-0">
                                            <div class="custom-fullcalendar fullcalendar" id="fullcalendar-1"
                                                 data-toggle="fullcalendar"   data-plugin-options='{ "events" : "<?php echo base_url();?>assets/js/events-sample.json"}'    ></div>
                                            <!-- /.fullcalendar -->
                                        </div>
                                        <!-- /.col-md-9 -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                                <!-- /.widget-body -->
                            </div>
                            <!-- /.widget-bg -->
                        </div>
                        <!-- /.widget-holder -->
                    </div>
                    <!-- /.row -->
                </div>
            </section>
            <!-- /.widget-list -->
            <section class="assignment-section">
                <div class="row page-title clearfix">
                    <div class="page-title-left">
                        <h6 class="page-title-heading color-blue mr-0 mr-r-5">Latest Assignments</h6>
                        <!-- <p class="page-title-description mr-0 d-none d-md-inline-block">statistics, charts and events</p> -->
                    </div>
                    <!-- /.page-title-left -->
                    <div class="page-title-right d-inline-flex">
                        <div class="col-lg-12 ">
                            <button class="btn btn-block btn-rounded btn-pink ripple v_all">VIEW ALL</button>
                        </div>
                    </div>
                    <!-- /.page-title-right -->
                </div>

                <div class="assignment-cards eq-contain-card">
                    <div class="row">
                        <div class="col-xl-4  col-sm-6">
                            <div class="eq-card">
                                <div class="assignment-jumbotron mr-b-30 ">
                                    <div class="course_title_jumb">
                                        Microlearning Delivery
                                    </div>
                                    <div class="topic_title_jumb">
                                        Advanced Strategic Planning Workshop
                                    </div>
                                    <div class="teacher_profile_pic">
                                        <img src="assets/img/member2.png">
                                    </div>
                                    <div class="teacher_profile_name">
                                        Victor J. Kessler
                                    </div>
                                    <footer class="mr-t-30"><a href="#" class="btn btn-outline-primary btn-rounded">Review</a>
                                    </footer>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4  col-sm-6">
                            <div class="eq-card">
                                <div class="assignment-jumbotron mr-b-30 ">
                                    <div class="course_title_jumb">
                                        Microlearning Delivery
                                    </div>
                                    <div class="topic_title_jumb">
                                        Advanced Strategic Planning Workshop
                                    </div>
                                    <div class="teacher_profile_pic">
                                        <img src="assets/img/member2.png">
                                    </div>
                                    <div class="teacher_profile_name">
                                        Victor J. Kessler
                                    </div>
                                    <footer class="mr-t-30"><a href="#" class="btn btn-outline-primary btn-rounded">Review</a>
                                    </footer>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4  col-sm-6 ">
                            <div class="eq-card">
                                <div class="assignment-jumbotron mr-b-30 ">
                                    <div class="course_title_jumb">
                                        Team Engagement


                                    </div>
                                    <div class="topic_title_jumb">
                                        Extended Leadership Winter Academy
                                    </div>
                                    <div class="teacher_profile_pic">
                                        <img src="assets/img/member3.png">
                                    </div>
                                    <div class="teacher_profile_name">
                                        James J. Cruz
                                    </div>
                                    <footer class="mr-t-30"><a href="#" class="btn btn-outline-primary btn-rounded">Review</a>
                                    </footer>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="tabs-section">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="tab_container">
                            <input id="tab1" class="tab-radio" type="radio" name="tabs" checked>
                            <label class="tabs-label" for="tab1"><span>Top performers</span></label>

                            <input id="tab2" class="tab-radio" type="radio" name="tabs">
                            <label class="tabs-label" for="tab2"><span>learners online</span></label>

                            <input id="tab3" class="tab-radio" type="radio" name="tabs">
                            <label class="tabs-label" for="tab3"><span>popular courses</span></label>

                            <input id="tab4" class="tab-radio" type="radio" name="tabs">
                            <label class="tabs-label" for="tab4"><span>inactive learners</span></label>

                            <input id="tab5" class="tab-radio" type="radio" name="tabs">
                            <label class="tabs-label" for="tab5"><span>fresh enrollments</span></label>

                            <section id="content1" class="tab-content">
                                <table class="table table-striped">
                                    <thead>
                                    <th>
                                        Learners Name
                                    </th>
                                    <th class="text-center">
                                        Points Earned
                                    </th>
                                    <th class="text-center">
                                        Time Spent
                                    </th>
                                    <th class="text-center">
                                        Current Level
                                    </th>
                                    <th>
                                        Course Title
                                    </th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Lucy D. Hauer
                                        </td>
                                        <td class="text-center">
                                            800 Points
                                        </td>
                                        <td class="text-center">
                                            2 hours
                                        </td>
                                        <td class="text-center">
                                            Level 8
                                        </td>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Blake J. Pointer
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member3.png">
                                            Blake J. Pointer
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member4.png">
                                            James J. Cruz
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member5.png">
                                            James J. Cruz
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member6.png">
                                            James J. Cruz
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </section>

                            <section id="content2" class="tab-content">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </section>

                            <section id="content3" class="tab-content">
                                <table class="table table-striped">
                                    <thead>
                                    <th>
                                        Course Title
                                    </th>
                                    <th class="text-center">
                                        Total Students Enrolled
                                    </th>
                                    <th class="text-center">
                                        Time Spent
                                    </th>
                                    <th class="text-center">
                                        Certified Learners
                                    </th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>
                                            Extended Leadership Winter Academy
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Diploma of Leadership and Management
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Sustainable Leadership - Twenty Leadership Programme
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Advanced Strategic Planning Workshop
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Fundamentals of UX UI Design for Augmented Reality
                                        </td>
                                        <td class="text-center">
                                            150
                                        </td>
                                        <td class="text-center">
                                            3 hours
                                        </td>
                                        <td class="text-center">
                                            80
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </section>

                            <section id="content4" class="tab-content">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </section>

                            <section id="content5" class="tab-content">
                                <table class="table table-striped">
                                    <tbody>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                        <td>
                                            <img src="assets/img/member1.png">
                                            Blake J. Pointer
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                        <td>
                                            <img src="assets/img/member2.png">
                                            Victor J. Kessler
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </section>
                        </div>
                    </div>
                </div>
            </section>


        </main>
        <!-- /.main-wrappper -->


    </div>
    <!-- /.content-wrapper -->
    <!-- FOOTER -->
    <!-- <footer class="footer"><span class="heading-font-family">Copyright @ 2017. All rights reserved BonVue Admin by Unifato</span>
    </footer> -->
</div>
<!--/ #wrapper -->
<!-- Scripts -->
<!--/ #wrapper -->
<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.2/umd/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.7.0/metisMenu.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.7.0/js/perfect-scrollbar.jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.77/jquery.form-validator.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/countup.js/1.9.2/countUp.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/switchery/0.8.2/switchery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.4/sweetalert2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.2/circle-progress.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-sparklines/2.1.2/jquery.sparkline.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.25/daterangepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mithril/1.1.1/mithril.js"></script>
<script src="<?php echo base_url();?>assets/vendors/theme-widgets/widgets.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.matchHeight/0.7.0/jquery.matchHeight-min.js"></script>

<script src="<?php echo base_url();?>assets/js/theme.js"></script>
<script src="<?php echo base_url();?>assets/js/custom.js"></script>
</body>


</html>