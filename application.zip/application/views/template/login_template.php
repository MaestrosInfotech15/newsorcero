<!DOCTYPE html>
<html lang="en">

    <head>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js"></script>
        <meta charset="utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no"/>

        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Login2</title>
        <!-- CSS -->
        <link href="<?php echo base_url();?>assets/vendors/material-icons/material-icons.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url();?>assets/vendors/linea-icons/styles.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url();?>assets/vendors/mono-social-icons/monosocialiconsfont.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url();?>assets/vendors/feather-icons/feather.css" rel="stylesheet" type="text/css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.4/sweetalert2.css" rel="stylesheet"
              type="text/css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet"
              type="text/css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.1.3/mediaelementplayer.min.css" rel="stylesheet"
              type="text/css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.7.0/css/perfect-scrollbar.min.css"
              rel="stylesheet" type="text/css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
              type="text/css"/>
        <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css"/>
        <!-- Head Libs -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    </head>

    <body class="body-bg-full profile-page" style="background-image: url(<?php echo base_url();?>assets/img/bg-login.jpg)">
        <div id="wrapper" class="wrapper">
            <div class="row container-min-full-height">
                <div class="col-lg-12 p-3 login-left">
                    <?php echo $content; ?>
                    
                </div>

                <!-- /.login-right -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.wrapper -->
        <!-- Scripts -->
        <script type="text/javascript">
            var baseurl = '<?php echo base_url(); ?>';
        </script>
        <script
            src="http://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
        <script type="text/javascript"
        src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.77/jquery.form-validator.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/material-design.js"></script>
        <script src="<?php echo base_url();?>assets/js/custom.js"></script>

    </body>

</html>