<main class="main-wrapper clearfix">
    <!-- Page Title Area -->
    <section class="">
        <div class="row page-title clearfix">

            <div class="page-title-left">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>">Dashboard</a>
                    </li>

                </ol>
            </div>
        </div>
        <div class="row  clearfix">
            <div class="col-sm-4 col-md-6">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">Manage Students</h6>
            </div>
            <div class="col-sm-8 col-md-6 text-right">
                <a href="<?php echo base_url('student/add'); ?>" class="btn btn-rounded custom-btn BlueGrad ripple">Add Student</a>

            </div>
        </div>
    </section>
    <section class="content-section">
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive">
                    <table class="table table-striped normal-table table-hover">
                        <thead>
                        <th colspan="2">S.No.</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Username</th>
                        <th class="text-center">Status</th>
<!--                        <th class="text-center">Groups</th>-->
                        <th class="text-center">Email</th>
                        <th class="text-center">Last Visit</th>
<!--                        <th class="text-center">ID</th>-->
                        <th class="text-center">Action</th>
                        </thead>
                        <tbody>
                        <?php if (isset($arrStudent)) { ?>
                            <?php foreach($arrStudent as $intKey=>$strValue):?> 
                                <tr>
                                    <td>
                                        <div class="checkbox checkbox-primary">
                                            <label>
                                                <input type="checkbox" id="sample3checkbox"> <span class="label-text"></span>
                                            </label></div>
                                    </td>
                                    <td><?php echo ($page_no+1)?></td>
                                    <td><?php echo $strValue['student_name'];?></td>
                                    <td><?php echo $strValue['username'];?></td>
                                    <td><?php echo $strValue['status'];?></td>
<!--                                    <td>Grooup1</td>-->
                                    <td><?php echo $strValue['email'];?></td>
                                    <td>2017-12-12 07:18 AM</td>
<!--                                    <td>AB01</td>-->
                                    <td><a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>
                                        <a  href="<?php echo base_url('student/delete/'.$strValue['id']);?>">
                                        <i class="fa fa-trash list-icon"></i>
                                        </a>
                                        <a  href="<?php echo base_url('student/edit/'.$strValue['id']); ?>">
                                        <i class="fa fa-pencil list-icon"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php  $page_no++; endforeach;?>
                            <?php }
                            else { ?>
                <td colspan="10">No user(s) found.</td>
            <?php } ?>


                        </tbody>
                    </table>
                    <br/>
            <div class="clearfix">
                        <?php if (isset($links)) { ?>
                <?php echo $links ?>
            <?php } ?>
            </div>
                </div>
                <!-- /.list-group -->
            </div>
        </div>
    </section>


</main>