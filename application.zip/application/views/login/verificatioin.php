<form id="regForm" method="post"  class="  text-center login-center" action="">
    <h2 class="mb-4  login-title">Email Verification</h2>
    <p><?php echo $msg; ?></p>
    <?php if ($success == 1): ?>
        <footer class="col-sm-12 text-center">
            <hr>
            <a href="<?php echo base_url(); ?>login" class="text-primary m-l-5"><b>Log In</b></a>
            </p>
        </footer>
    <?php endif; ?>
</form>