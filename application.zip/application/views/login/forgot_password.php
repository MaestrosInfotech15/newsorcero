<div class="navbar-header text-center  mt-5">
    <a href="<?php echo base_url();?>">
        <img alt="" src="./assets/img/login-logo.png"/>
    </a>
</div>

<form id="resetForm" class="text-center login-center" method="post" action="<?php echo base_url(); ?>forgot-password">
    <h2 class="mb-4 text-center login-title">Forgot Password</h2>
    <p class="text-center">Signing up is easy. It only takes a few steps and you'll be up and running in no
        time.</p>
    <!--<p class="text-center text-muted">Enter your email address and we'll send you an email with instructions to reset your password.</p>-->
    
    <div class="form-group no-gutters">
        <label class="text-muted" for="example-email">
            <i class="fa fa-email"></i>
            <i class="icon-input-label">Email</i></label>
        <input type="email" placeholder="johndoe@site.com" class="form-control form-control-line" data-validation="email"  name="username" id="username"/>
        <span class="help-block form-error"><?php echo $this->session->flashdata('error'); ?></span>
    </div>
    
    <div class="form-group ">
        <button class="btn btn-block btn-rounded btn-md btn-color-scheme btn-login text-uppercase fw-600 ripple"
                type="submit">Submit
        </button>
    </div>
    <footer class="col-sm-12 text-center">
        <hr>
        <p>Back to <a href="<?php echo base_url();login?>" class="text-primary m-l-5"><b>Login</b></a>
        </p>
    </footer>
</form>