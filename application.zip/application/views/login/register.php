<form id="regForm" method="post"  class="  text-center login-center" action="">
                <h2 class="mb-4  login-title">Register</h2>
                <p>Signing up is easy. It only takes a few steps and you'll be up and running in no time.</p>
                <div class="form-group">
                    <label class="text-muted" for="name">
                        <i class="fa fa-user"></i>
                        <i class="icon-input-label">Domain</i></label>
                    <input type="text" placeholder="Aagha"  class="form-control form-control-line" name="domain_name" data-validation="server"  data-validation-url="<?php echo base_url();?>login/check_avialable_domain"/>
                </div>
                <div class="form-group">
                    <label class="text-muted" for="name">
                        <i class="fa fa-user"></i>
                        <i class="icon-input-label">Name</i></label>
                    <input type="text" placeholder="Aagha"
                           class="form-control form-control-line" name="fname"  data-validation="length" data-validation-length="min6"
                           />
                </div>
                <div class="form-group">
                    <label class="text-muted" for="email">
                        <i class="fa fa-envelope"></i>
                        <i class="icon-input-label">Email</i></label>
                    <input type="email" placeholder="johndoe@site.com" data-validation="email"
                           class="form-control form-control-line" name="email"
                           value=""/>
                    <span class="help-block form-error"><?php echo form_error('email');?></span>
                </div>
                <div class="form-group">
                    <label class="text-muted" for="username">
                        <i class="fa fa-user"></i>
                        <i class="icon-input-label">Username</i></label>
                    <input type="text" placeholder="johndoe" data-validation="length" data-validation-length="min5"
                           class="form-control form-control-line" name="username"
                           value=""/>
                    <span class="help-block form-error"><?php echo form_error('username');?></span>
                </div>
                <div class="form-group">
                    <label class="text-muted" for="password">
                        <i class="fa fa-lock"></i>
                        <i class="icon-input-label">Password</i></label>
                    <input type="password" placeholder="password" class="form-control form-control-line"
                           name="password" value="" data-validation="length"
                           data-validation-length="min8"/>
                </div>
                <div class="form-group">
                    <label class="text-muted" for="confirm-password">
                        <i class="fa fa-lock"></i>
                        <i class="icon-input-label">Confirm Password</i></label>
                    <input type="password" placeholder="confirm-password" class="form-control form-control-line"
                           name="confirm_password" data-validation="confirmation" data-validation-confirm="password"    />
                </div>
                <div class="form-group no-gutters mb-0 ">
                    <div class="col-md-12 d-flex">
                        <div class="checkbox checkbox-primary mr-auto ">
                            <label class="d-flex">
                                <input type="checkbox"/> <span class="label-text">I agree to all <a href="">Terms & Conditions</a></span>
                            </label>
                        </div>
                    </div>
                    <!-- /.col-md-12 -->
                </div>
                <!-- /.form-group -->
                <div class="form-group mr-b-20">
                    <button class="btn btn-block btn-rounded btn-md btn-color-scheme btn-login text-uppercase fw-600 ripple"
                            type="submit">Signup
                    </button>
                </div>
                <footer class="col-sm-12 text-center">
                    <hr>
                    <p>Already have an account? <a href="<?php echo base_url();?>login" class="text-primary m-l-5"><b>Log In</b></a>
                    </p>
                </footer>
            </form>