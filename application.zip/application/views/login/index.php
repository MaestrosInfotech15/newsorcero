<div class="navbar-header text-center  mt-5">
    <a href="<?php echo base_url();?>">
        <img alt="" src="./assets/img/login-logo.png"/>
    </a>
</div>


<form id="loginForm" method="post" class="text-center login-center has-validation-callback" action="<?php echo base_url();?>login/check_login">
    <h2 class="mb-4 text-center login-title">Lets Learn Together</h2>
    <?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-error">
        <?php echo $this->session->flashdata("error"); ?>
    </div>
    <?php endif; ?>
    <div class="form-group">
        <label class="text-muted" for="example-email">
            <i class="fa fa-user"></i>
            <i class="icon-input-label">Login</i></label>
        <input type="text" placeholder="johndoe@site.com"  class="form-control form-control-line" name="username" required="required" data-validation="length" data-validation-length="min6" />
    </div>
    <div class="form-group">
        <label class="text-muted" for="example-email">
            <i class="fa fa-lock"></i>
            <i class="icon-input-label">Password</i></label>
        <input type="password" placeholder="password" class="form-control form-control-line" name="password" value="111111" data-validation="length" data-validation-length="min8" />
    </div>
    <div class="form-group no-gutters mb-0 ">
        <div class="col-md-12 d-flex">
            <div class="checkbox checkbox-primary mr-auto ">
                <label class="d-flex">
                    <input type="checkbox"/> <span class="label-text">Remember me</span>
                </label>
            </div>
        </div>
        <!-- /.col-md-12 -->
    </div>
    <!-- /.form-group -->
    <div class="form-group mr-b-20">
        <button class="btn btn-block btn-rounded btn-md btn-color-scheme btn-login text-uppercase fw-600 ripple"
                type="submit">LOGIN
        </button>
    </div>
    <footer class="col-sm-12 text-center">
        <hr>
        <p><a href="<?php echo base_url('create'); ?>" class="text-primary m-l-5"><b>Signup</b></a> | <a
                class="text-primary m-l-5" href="<?php echo base_url('forgot-password'); ?>"><b>Forgot Password</b></a>
        </p>
    </footer>
</form>
<!-- /form -->