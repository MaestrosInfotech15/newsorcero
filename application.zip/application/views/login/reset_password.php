<div class="navbar-header text-center  mt-5">
    <a href="<?php echo base_url();?>">
        <img alt="" src="<?php echo base_url();?>/assets/img/login-logo.png"/>
    </a>
</div>

<form id="resetForm" class="text-center login-center" method="post" action="<?php echo base_url(); ?>login/reset_password/<?php echo $email;?>">
    <h2 class="mb-4 text-center login-title">Reset Password</h2>
    <p class="text-center">Signing up is easy. It only takes a few steps and you'll be up and running in no
        time.</p>
    <!--<p class="text-center text-muted">Enter your email address and we'll send you an email with instructions to reset your password.</p>-->
    <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-error">
                <?php echo $this->session->flashdata("error"); ?>
            </div>
        <?php endif; ?>    
    <div class="form-group">
        <label class="text-muted" for="pass_confirmation">
            <i class="fa fa-lock"></i>
            <i class="icon-input-label">Password</i></label>
        <input type="password" placeholder="password" class="form-control form-control-line" name="pass_confirmation"  data-validation="length" data-validation-length="min8" />
    </div>
    <div class="form-group">
        <label class="text-muted" for="passconf">
            <i class="fa fa-lock"></i>
            <i class="icon-input-label">Password</i></label>
        <input type="password" placeholder="Confirm Password" id="passconf" class="form-control form-control-line" name="pass"  data-validation="confirmation" />
    </div>
    
    <div class="form-group ">
        <button class="btn btn-block btn-rounded btn-md btn-color-scheme btn-login text-uppercase fw-600 ripple"
                type="submit">Submit
        </button>
    </div>
    <footer class="col-sm-12 text-center">
        <hr>
        <p>Back to <a href="<?php echo base_url();login?>" class="text-primary m-l-5"><b>Login</b></a>
        </p>
    </footer>
</form>