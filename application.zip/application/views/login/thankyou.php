<form id="regForm" method="post"  class="  text-center login-center" action="">
    <h2 class="mb-4  login-title">Thank you for register on Sorceo</h2>
    <p>We have sent you email please verify you email address.</p>
</form>