<main class="main-wrapper clearfix">
    <!-- Page Title Area -->
    <section class="">
        <div class="row page-title clearfix">

            <div class="page-title-left">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Manage Categories</a>
                    </li>

                </ol>
            </div>
        </div>
        <div class="row  clearfix">
            <div class="col-sm-4 col-md-6">
                <h6 class="page-title-heading color-blue mr-0 mr-r-5">Categories</h6>
            </div>
            <div class="col-sm-8 col-md-6 text-right">
                <button class="btn btn-rounded custom-btn whiteGrad ripple" data-toggle="modal" data-target=".add-category-model">Add Category</button>
                <button class="btn btn-rounded custom-btn whiteGrad ripple">Discard</button>
                <button class="btn btn-rounded custom-btn BlueGrad ripple">Save</button>
            </div>
        </div>
    </section>
    <section class="content-section">
        <div class="row">
            <div class="col-sm-12">
                <ol class="list-group sortable">
                     <?php if (isset($arrCategory)) { ?>
                            <?php foreach($arrCategory as $intKey=>$strValue):?>
                                <li class="list-group-item bg-color-scheme text-inverse d-flex">
                                    <div class="mr-auto">
                                        <div class="checkbox checkbox-primary">
                                            <label>
                                                <input type="checkbox" id="sample3checkbox"> 
                                                <span class="label-text"> 
												<?php echo $strValue['name'];?>
                                                </span>
                                              </label>
                                            </div>
                                    </div>
                                    <div class="right-icons">
                                    <a href="javascript:void(0);"><i class="fa fa-copy list-icon"></i></a>
                                    <a href="javascript:void(0);"><i class="fa fa-ban list-icon"></i></a>  
                                    <a href="<?php echo base_url('Categories/delete/'.$strValue['id']);?>"><i class="fa fa-trash list-icon"></i></a>  
                                    <a href="javascript:void(0);"><i class="fa fa-question-circle-o list-icon"></i></a>
                                    </div>
                                </li> 
                            <?php endforeach;?>    
                      <?php } ?>
                </ol>
                <div class="clearfix">
                        <?php if (isset($links)) { ?>
                <?php echo $links ?>
            <?php } ?>
            </div>
                <!-- /.list-group -->
            </div>
        </div>
    </section>


</main>
<!-- /.modal -->
<div class="modal modal-color-scheme fade add-category-model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header text-inverse">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i></button>
                <h5 class="modal-title" id="myLargeModalLabel">Add Category</h5>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo base_url('categories/add');?>">
                    <div class="form-group">
                        <input type="text" name="category_name" class="form-control" placeholder="Title goes here" required="required" data-validation="length" data-validation-length="min4">
                    </div>
                    <div class="text-right">
                        <button class="btn btn-rounded custom-btn BlueGrad ripple " >Add </button>
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->