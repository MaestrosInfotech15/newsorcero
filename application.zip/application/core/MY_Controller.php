<?php

class MY_Controller extends CI_Controller {

    public function MY_Controller() {
        parent::__construct();
        $this->data = array();
        //$this->form_validation->set_error_delimiters('<div class="alert alert-error"><a data-dismiss="alert" class="close">x</a><strong>Error!</strong> ', '</div>');
    }

}

// Required ?
class FrontendController extends CI_Controller {

    function __construct($data) {
        parent::__construct();

        $this->data = array();

        $user = $this->session->userdata('current_user');
        if (!$user) {
            redirect('login');
        } else {
            $this->data['user'] = $user[0];
        }
        $this->template->set_template('home');
        $this->template->write('pagetitle', $data['pagetitle']);
        $this->template->write_view('header', 'common/header', $this->data, true);
        $this->template->write_view('sidebar', 'common/sidebar', $this->data, true);
        //$this->template->write_view('right_sidebar', 'common/right_sidebar', $this->data, true);
        //$this->template->write_view('inner_toolbar', 'common/inner_toolbar', $this->data, true);
        //$this->template->write_view('breadcrumb', 'common/breadcrumb', $this->data, true);
        //$this->template->write_view('footer', 'common/footer', $this->data, true);
    }

}
