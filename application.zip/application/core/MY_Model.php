<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model {

    public function __construct() {
        parent::__construct();
        /*mysql> set global sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
mysql> set session sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';*/
    }

    public function createUrl($name, $tableName, $addStr = false) {
        $name = ($addStr) ? $name . random_string("alpha", 3) : $name;
        $url = url_title($name, "-", true);
        //check url with current table 
        $isUrlExist = $this->countData($tableName, array("url" => $url, "deletedBy" => 0));
        return ($isUrlExist) ? $this->createUrl($url, $tableName, true) : $url;
    }

    public function uploadImage($files, $uploadPath, $types = "png|jpeg|jpg|docx|doc|txt|ppt|pptx|xls|xlsm|xlsx|xlt|csv|pdf", $isImg = true, $size = IMG_SIZE) {
        $attachments = array();
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0644, true);
            mkdir($uploadPath . LARGE, 0644, true);
            mkdir($uploadPath . MEDIUM, 0644, true);
            mkdir($uploadPath . SMALL, 0644, true);
            mkdir($uploadPath . THUMB, 0644, true);
        }
        $config = array(
            'upload_path' => $uploadPath,
            'allowed_types' => $types,
            'overwrite' => FALSE,
            'max_size' => 51200, // Can be set to particular file size , here it is 50 MB
            'encrypt_name' => FALSE,
            'file_ext_tolower' => true
        );
        $this->load->library('upload');
        $this->upload->initialize($config);
        if (is_array($files['name'])) {
            foreach ($files['name'] as $fileKey => $fileValue) {
                if ($files['name'][$fileKey] != "") {
                    $_FILES['file']['name'] = $files['name'][$fileKey];
                    $_FILES['file']['type'] = $files['type'][$fileKey];
                    $_FILES['file']['tmp_name'] = $files['tmp_name'][$fileKey];
                    $_FILES['file']['error'] = $files['error'][$fileKey];
                    $_FILES['file']['size'] = $files['size'][$fileKey];
                    if ($this->upload->do_upload('file')) {
                        $fileData = $this->upload->data();
                        $attachments[] = $fileData['file_name'];
                    }
                }
            }
        } else {
            $_FILES['file']['name'] = $files['name'];
            $_FILES['file']['type'] = $files['type'];
            $_FILES['file']['tmp_name'] = $files['tmp_name'];
            $_FILES['file']['error'] = $files['error'];
            $_FILES['file']['size'] = $files['size'];
            if ($this->upload->do_upload('file')) {
                $fileData = $this->upload->data();
                $attachments[] = $fileData['file_name'];
            }
        }
        if (!empty($attachments) && $isImg) {
            $config2['image_library'] = 'gd2';
            $sizeArr = unserialize($size);
            $this->load->library('image_lib');
            foreach ($attachments as $resizeImage) {
                if (file_exists($uploadPath . $resizeImage) && !empty($sizeArr)) {
                    $config2['source_image'] = $uploadPath . $resizeImage;
                    list($width, $height, $type, $attr) = getimagesize($uploadPath . $resizeImage);
                    foreach ($sizeArr as $imgPath => $imgDim) {
                        $config2['width'] = ($width > $imgDim[0]) ? $imgDim[0] : $width;
                        $config2['maintain_ratio'] = ($height < $imgDim[1]) ? FALSE : TRUE;
                        $config2['height'] = (!$config2['maintain_ratio']) ? $height : "";
                        $config2['new_image'] = $uploadPath . $imgPath;
                        $this->image_lib->initialize($config2);
                        $this->image_lib->resize();
                    }
                }
            }
        }
        return $attachments;
    }

    public function uploadFile($files, $uploadPath, $types = "png|jpeg|jpg|docx|doc|txt|ppt|pptx|xls|xlsm|xlsx|xlt|csv|pdf") {
        $attachments = array();
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0644, true);
            mkdir($uploadPath . FILES, 0644, true);
        }
        if (!is_dir($uploadPath . FILES)) {
            mkdir($uploadPath . FILES, 0644, true);
        }
        $config = array(
            'upload_path' => $uploadPath . FILES,
            'allowed_types' => $types,
            'overwrite' => FALSE,
            'max_size' => 51200, // Can be set to particular file size , here it is 50 MB
            'encrypt_name' => FALSE,
            'file_ext_tolower' => true
        );
        $this->load->library('upload');
        $this->upload->initialize($config);
        if (is_array($files['name'])) {
            foreach ($files['name'] as $fileKey => $fileValue) {
                if ($files['name'][$fileKey] != "") {
                    $_FILES['file']['name'] = $files['name'][$fileKey];
                    $_FILES['file']['type'] = $files['type'][$fileKey];
                    $_FILES['file']['tmp_name'] = $files['tmp_name'][$fileKey];
                    $_FILES['file']['error'] = $files['error'][$fileKey];
                    $_FILES['file']['size'] = $files['size'][$fileKey];
                    if ($this->upload->do_upload('file')) {
                        $fileData = $this->upload->data();
                        $attachments[] = $fileData['file_name'];
                    }
                }
            }
        } else {
            $_FILES['file']['name'] = $files['name'];
            $_FILES['file']['type'] = $files['type'];
            $_FILES['file']['tmp_name'] = $files['tmp_name'];
            $_FILES['file']['error'] = $files['error'];
            $_FILES['file']['size'] = $files['size'];
            if ($this->upload->do_upload('file')) {
                $fileData = $this->upload->data();
                $attachments[] = $fileData['file_name'];
            }
        }
        return $attachments;
    }

    /**
     * listData : Select records from table
     * 
     * @access	public
     * @param	tableName string
     * @param	select string
     * @param	where array/string
     * @return	array or object
     */
    public function listData($tableName, $select, $where = "", $orderBy = "", $returnArray = FALSE) {
        $this->db->select($select)->from($tableName);
        (!empty($where)) ? $this->db->where($where) : "";
        (!empty($orderBy)) ? $this->db->order_by($orderBy) : "";
        return (!$returnArray) ? $this->db->get()->result() : $this->db->get()->result_array();
    }

    /**
     * singleData : select single row from table
     * 
     * @param	tableName string
     * @param	select string
     * @param	where array/string
     * @return	array or object
     */
    public function singleData($tableName, $select, $where = "", $orderBy = "", $returnArray = FALSE) {
        $this->db->select($select)->from($tableName);
        (!empty($where)) ? $this->db->where($where) : "";
        (!empty($orderBy)) ? $this->db->order_by($orderBy) : "";
        $this->db->limit(1);
        return (!$returnArray) ? $this->db->get()->row() : $this->db->get()->row_array();
    }

    /**
     * countData : Count records from table
     * 
     * @access	public
     * @param	tableName string
     * @param	where array/string
     * @return	Integer
     * */
    public function countData($tableName, $where = "") {
        $this->db->select("createdOn")->from($tableName);
        (!empty($where)) ? $this->db->where($where) : "";
        return $this->db->get()->num_rows();
    }

    /**
     * insertData : Insert record in table
     * 
     * @access	public
     * @param	tableName string, data array, where array
     * @param	data array
     * @param	batch Boolean
     * @return	affected rows
     */
    public function insertData($tableName, $data, $batch = FALSE) {
        $lastId = 0;
        $arrSession = $this->session->userdata('current_user');
        if (!$batch) {
            $data["createdOn"] = CURRENT_DATE;
            $data["createdBy"] = isset($arrSession[0]['id']) ? $arrSession[0]['id'] : 1;
            $this->db->insert($tableName, $data);
            return $this->db->insert_id();
        } else {
            if (count($data) > 499) {
                $_datas = array_chunk($data, 499);
                foreach ($_datas as $batchPart) {
                    $this->db->insert_batch($tableName, $batchPart, NULL, 500);
                    $lastId = $lastId + $this->db->affected_rows();
                }
            } else {
                $this->db->insert_batch($tableName, $data, NULL, 500);
                $lastId = $this->db->affected_rows();
            }
        }
        return $lastId;
    }

    /**
     * updateData : Update record in table
     * 
     * @access	public
     * @param	tableName string, data array, where array
     * @param	data array
     * @param	where array/string
     * @return	affected rows
     */
    public function updateData($tableName, $data = array(), $where = "", $isDelete = false, $batch = FALSE, $colWhere = "") {
        $lastId = 0;
        $arrSession = $this->session->userdata('current_user');
        if (!$batch) {
            if ($isDelete) {
                $data["deleted_on"] = CURRENT_DATE;
                $data["deleted_by"] = isset($arrSession[0]['id']) ? $arrSession[0]['id'] : 1;
            } else {
                $data["lastupdated_on"] = CURRENT_DATE;
                    $data["lastupdaed_by"] = isset($arrSession[0]['id']) ? $arrSession[0]['id'] : 1;
            }
            (!empty($where)) ? $this->db->where($where) : "";
            $lastId = $this->db->update($tableName, $data);
        } else if (!empty($colWhere)) {
            if (count($data) > 499) {
                $_datas = array_chunk($data, 499);
                foreach ($_datas as $batchPart) {
                    $this->db->update_batch($tableName, $batchPart, $colWhere, 500);
                    $lastId = $lastId + $this->db->affected_rows();
                }
            } else {
                $this->db->update_batch($tableName, $data, $colWhere, 500);
                $lastId = $this->db->affected_rows();
            }
        }
        return $lastId;
    }

    /**
     * deleteData : Delete records from table
     * 
     * @access	public
     * @param	tableName string
     * @param	where array/string
     * @return	affected rows
     */
    public function deleteData($tableName, $where = "") {
        (!empty($where)) ? $this->db->where($where) : "";
        $this->db->delete($tableName);
        return $this->db->affected_rows();
    }

    /**
     * Get part of search query
     *
     * @access	public
     * @param	columnSearch Array
     * @param	searchString String
     * @return	Query Object
     */
    public function _searchQuery($columnSearch, $searchString, $side = "both", $escape = NULL) {
        $column_count = count($columnSearch) - 1;
        foreach ($columnSearch as $i => $item) { // loop column
            if ($i === 0) { // first loop
                $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                $this->db->like($item, $searchString, $side, $escape);
            } else {
                $this->db->or_like($item, $searchString, $side, $escape);
            }
            if ($column_count == $i) //last loop
                $this->db->group_end(); //close bracket
        }
    }

    /**
     * Get part of having query
     *
     * @access	private
     * @param	columnHaving Array
     * @param	searchString String
     * @return	Query Object
     */
    public function _havingQuery($columnHaving, $searchString, $escape = NULL) {
        $havingLike = "";
        $column_count = count($columnHaving) - 1;
        foreach ($columnHaving as $i => $item) { // loop column
            $havingLike .= ($i === 0) ? "($item LIKE '%" . $searchString . "%'" : " OR " . $item . " LIKE '%" . $searchString . "%'";
            //last loop //close bracket
            ($column_count == $i) ? $havingLike .= ")" : "";
        }
        (!empty($havingLike)) ? $this->db->having($havingLike, NULL, $escape) : "";
    }

    /**
     * Get part of order query
     *
     * @access	public
     * @param	columnOrder Array
     * @param	postOrder Array
     * @param	defaultOrder Array
     * @return	Query Object
     */
    public function _orderQuery($columnOrder = array(), $postOrder = array(), $defaultOrder = array(), $escape = NULL) {
        if (!empty($postOrder)) { // here order processing
            $this->db->order_by($columnOrder[$postOrder['0']['column']], $postOrder['0']['dir'], $escape);
        } else if (!empty($defaultOrder)) {
            $this->db->order_by(key($defaultOrder), $defaultOrder[key($defaultOrder)]);
        }
    }

    /**
     * Forget password mail
     *
     * @access	public
     * @param	data
     * @return	boolean
     */
    public function send_forgot_password_email($email, $code) {
        $this->load->model('Users_model');
        $user_data = $this->Users_model->get_user_detail_by_email($email);
        $placeholder_array = array();
        // Update okay, send email
        $url = base_url() . "reset-password/" . $code;
        $logo_path = base_url() . "assets/images/logo.png";
        $message_data = $this->get_email_notification_detail('forgot_password');
        if (!empty($user_data) && !empty($message_data)) {
            $mail_content = $message_data->email_contents;
            $mail_subject = $message_data->email_subject;
            if (empty($placeholder_array)) {
                $placeholder_values = $this->list_data("core_placeholders", "placeholder_name,placeholder_value", array("status" => 1, "deleted_by" => 0));
                foreach ($placeholder_values as $placeholder_value) {
                    $placeholder_array[$placeholder_value->placeholder_name] = $placeholder_value->placeholder_value;
                }
            }

            //get user detail
            $this->db->select("cu.id,cu.name,cu.email,cu.salutation,cu.username");
            $this->db->from("core_users cu");
            $this->db->where(array("cu.status" => 1, "cu.deleted_by" => 0, "cu.id" => $user_data['id']));
            $member_detail = $this->db->get()->row();
            $searchArr = $replaceArr = array();

            if (array_key_exists(P_CONTACT_SALUTATION, $placeholder_array)) {
                $searchArr[] = P_CONTACT_SALUTATION;
                $replaceArr[] = ($member_detail->salutation != "") ? $member_detail->salutation : $placeholder_array[P_CONTACT_SALUTATION];
            }
            if (array_key_exists(P_CONTACT_FULL_NAME, $placeholder_array)) {
                $searchArr[] = P_CONTACT_FULL_NAME;
                $replaceArr[] = $member_detail->name;
            }
            if (array_key_exists(P_EMAIL_SIGN, $placeholder_array)) {
                $searchArr[] = P_EMAIL_SIGN;
                $replaceArr[] = $placeholder_array[P_EMAIL_SIGN];
            }
            if (array_key_exists(P_SITENAME, $placeholder_array)) {
                $searchArr[] = P_SITENAME;
                $replaceArr[] = SITE_NAME;
            }

            if (!empty($searchArr) && !empty($replaceArr)) {
                $mail_content = str_replace($searchArr, $replaceArr, $mail_content);
                $mail_subject = str_replace($searchArr, $replaceArr, $mail_subject);
            }
            $mail_content = str_replace(P_PASSWORD_RESET_LINK, $url, $mail_content);
            if ($this->send_email_to_users($message_data->email, $message_data->sender_name, $email, $mail_subject, $mail_content)) {
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * Get fotgot password detail
     *
     * @access	public
     * @param	email_notification_type
     * @return	Array
     */
    public function get_email_notification_detail($type) {
        $this->db->select('es.id,es.email_subject,es.email_contents,se.email,se.sender_name');
        $this->db->from('core_email_settings es');
        $this->db->join('core_system_emails se', 'se.id = es.from_email_id AND se.deleted_by = 0', 'left');
        $this->db->where(array('es.deleted_by' => 0, 'es.is_enabled' => 1, 'es.email_notification_type' => $type));
        return $this->db->get()->row();
    }

    /**
     * Email template detail
     *
     * @access	public
     * @param	data
     * @return	boolean
     */
    public function get_mail_tempalte_detail($id) {
        $this->db->select("et.*,es.signature,se.email,se.email as from_email,se.sender_name as from_sender");
        $this->db->from("core_email_templates et");
        $this->db->join("core_email_signature es", "es.id=et.email_signature_id and es.deleted_by=0", "left");
        $this->db->join("core_system_emails se", "se.id=et.from_email_id and se.deleted_by=0", "left");
        $this->db->where(array("et.deleted_by" => 0, "et.id" => $id));
        return $this->db->get()->row();
    }

    /**
     * Send an email
     *
     * @access	public
     * @param	email data
     * @return	boolean
     */
    public function send_email_to_users($from = array(), $from_name = "", $to = "", $subject = "", $body = "", $attachments = array(), $attachment_directory = "", $mail_config = array()) {
        $retArr = array();
        $connection_setting = $this->single_data("core_connection_settings", "*", '', '', false);
        $config['protocol'] = "smtp";
        $config['smtp_host'] = $connection_setting->smtp_host;
        $config['smtp_user'] = $connection_setting->smtp_host_username;
        $config['smtp_pass'] = $connection_setting->smtp_host_password;
        $config['smtp_port'] = $connection_setting->smtp_host_port;
        $config['charset'] = "UTF-8";
        $config['crlf'] = "\r\n";
        $config['debug'] = false;
        $this->email->initialize($config);
        if (is_array($from) && !empty($from)) {
            foreach ($from as $key => $value) {
                $this->email->set_newline("\r\n");
                $this->email->set_mailtype("html");
                $from_email = ($value["from_email"] != "") ? $value["from_email"] : ADMIN_EMAIL;
                $from_email_name = ($value["from_name"] != "") ? $value["from_name"] : ADMIN_NAME;
                $this->email->from($from_email, $from_email_name);
                $this->email->to($value["to_email"]);
                $this->email->subject($value["email_subject"]);
                $this->email->message($value["email_body"]);
                if (!empty($attachments)) {
                    foreach ($attachments as $attachment) {
                        $this->email->attach($attachment_directory . $attachment);
                    }
                }
                $retArr[$key]["sent"] = $this->email->send();
                $this->email->clear(TRUE);
            }
        } else {
            $this->email->set_newline("\r\n");
            $this->email->set_mailtype("html");
            $from_email = ($from != "") ? $from : ADMIN_EMAIL;
            $from_email_name = ($from_name != "") ? $from_name : ADMIN_NAME;
            $this->email->from($from_email, $from_email_name);
            $this->email->to($to);
            $this->email->subject($subject);
            $this->email->message($body);
            if (!empty($attachments)) {
                foreach ($attachments as $attachment) {
                    $this->email->attach($attachment_directory . $attachment);
                }
            }
            $retArr[$to]["sent"] = $this->email->send();
            $this->email->clear(TRUE);
        }
        $fileste = fopen("test_mail_sent.txt", "w+");
        fwrite($fileste, print_r($retArr, true));
        fclose($fileste);
        return $retArr;
    }

    /**
     * Get email template details by Id
     *
     * @access	public
     * @param	template id
     * @return	Array
     */
    public function get_email_template_details_by_id($id) {
        //,es.signature,es.name as signature_name
        $this->db->select('et.id,et.subject,et.content,et.from_email_id,se.name as from_email_name,se.email as from_email,et.from_sender');
        $this->db->from('core_email_templates et');
        $this->db->join('core_system_emails se', "se.id=et.from_email_id and se.deleted_by=0", "left");
        //$this->db->join('core_email_signature es', "es.id=et.email_signature_id and es.deleted_by=0", "left");
        $this->db->where(array('et.id' => $id, "et.deleted_by" => 0));
        return $this->db->get()->row();
    }

    /* update total of count in session */
    public function check_domain_user($arrPost=array(),$id=0)
    {
        $arrSession = $this->session->userdata('current_user');
        $domain_id =  $arrSession[0]['domain_id'];
        $this->db->select("*");
        $this->db->from("tbl_users tu");
        $this->db->where("tu.domain_id",$domain_id);
        $this->db->group_start();
        $this->db->where("tu.email",$arrPost['email']);
        $this->db->or_where("tu.username",$arrPost['username']);
        $this->db->group_end();
        if(!empty($id))
        {
            $this->db->where("tu.id !=",$id);
        }
        return $this->db->get()->result_array();
    }
}
